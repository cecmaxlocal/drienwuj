<?php
define('TS_EDIT',true);
require 'reality_check.php'; 
if (!isset($_GET['page'])) {include 'index.php'; exit;}
$page=strtolower($_GET['page']);
$section=strtolower($_GET['section']);
$pagepath=$section."/".$page;
$styles=$ts_utils->readStyles();
$alt=(isset($_GET['editor']))?true:false;
include ((defined('TS_RAWEDIT') && TS_RAWEDIT) === (isset($_GET['editor'])))?'rich_editor.php':'raw_editor.php';