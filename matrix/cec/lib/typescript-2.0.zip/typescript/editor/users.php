<?php
// 2009.11.12
define('TS_EDIT',true);
require 'reality_check.php'; 
$ts_utils->access($access==3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Admin: User Accounts'); ?>
	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/typescript.js"></script>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
function confirmdel(user) {
return confirm("Do you really want to delete the user '"+user+"'?");
}
// ]]>
</script>
</head>
<body id="users">
<div class="page">
<?php $ts_utils->buildMenu("users",$access); ?>
<div class="content">
<?php
$php_self=$_SERVER['PHP_SELF'];
$addusr="";
// delete a user?
	if(isset($_POST['delete'])) {
		$tsql->dropUser($_POST['delete']);
	}
// add a user?
if(isset($_POST['username'])) {
   $users=$tsql->getUsers();
   $addusr=strtolower($_POST['username']);
   // username ok/unique?, password OK?
   if (preg_match('/^[a-z0-9]+\.?[a-z0-9]+$/',$addusr)) {
   $msg="";
   } else {
   $msg="A username can contain only alphanumeric characters and (optionally) a single full stop.<br />";
   }
   if($addusr=='username') $msg.="You did not supply a username.<br />";   
		if(isset($users[$addusr])) $msg.="The username \"$addusr\" already exists.<br />";
   if (!$addusr) $msg="The username field is blank.<br />";
   if (($_POST['password']=="")||($_POST['password']=="password")) $msg.="The password field is blank.<br />";
   if (preg_match('/^[a-zA-Z0-9]{5,}$/',$_POST['password'])==0) $msg.="Passwords contain only alphanumeric characters and are at least 5 characters long.<br />";
   if(strlen($addusr)>20) $msg.="A username should be no longer than 20 characters<br />";
   if ($msg=="") {
	$tsql->addUser($addusr, $_POST['password'], $_POST['access'], $_POST['editor']);  
   } else {
  $ts_utils->report("<b>Unable to add the new user</b> because...<p>$msg</p>");
   }
}
?>
<fieldset><legend>User accounts</legend>
<table class="usertable">
<tr><th></th><th>User:</th><th>Access level:</th><th>Preferred editor:</th></tr>
<?php
$ulevel=array('1'=>'reviser','2'=>'editor','3'=>'administrator');
$edtype=array('1'=>'WYSIWYG','2'=>'HTML');
$users=$tsql->getUsers();
foreach($users as $user=>$access){
	if($usr<>$user) {
	echo '<tr><td><form action="'.$php_self."\" method=\"post\" class=\"userdel\" onsubmit=\"return confirmdel('$user');\"><div><input type=\"hidden\" name=\"delete\" value=\"$user\" /><input type=\"image\" src=\"icons/ts_usericon.png\" onmouseover=\"tsu.userHover(this,1)\" onmouseout=\"tsu.userHover(this,0)\" value=\"DELETE\" title=\"Delete this user\" /></div></form></td>";
	} else {
	echo '<tr class="cuser" title="Current user"><td><img src="icons/ts_usercurrent.png" alt="Current user" /></td>'."\n";
	}
	echo '<td>',$user,'</td><td>',$ulevel[$access['access']],'</td><td><small>',$edtype[$access['editor']],'</small></td></tr>';
}
?>
</table>
<!-- NEW USER -->
<hr />
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
<div>
	<label for="username">New user:</label>
	<input type="text" name="username" id="username" value="Username" title="Username" onclick="tsu.clearField(this);" onblur="tsu.restoreField(this);"/>
	<input type="password" name="password" id="password" value="password" title="Password" onclick="tsu.clearField(this);" onblur="tsu.restoreField(this);" />
	<select name="access" id="access" title="User access level">
	<option value="1">reviser</option>
	<option value="2">editor</option>
	<option value="3" selected="selected">administrator</option>
	</select>
	<select name="editor" id="editor" title="Preferred Editor">
	<option value="1">WYSIWYG</option>
	<option value="2">HTML</option>
	</select>
	<input type="submit" value="Create a new user" class="submit" title="Create a new user" />
</div>
</form>
</fieldset>
</div>
<?php include("./footer.inc.php"); ?>
</div> 
</body>
</html>