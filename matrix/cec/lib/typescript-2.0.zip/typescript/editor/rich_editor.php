<?php
// 2010.04.17
if((stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) || !defined('TS_EDIT')) {
		include 'index.php';
		exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Editing: '.$pagepath); ?>
	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/typescript.js"></script>
	<link rel="stylesheet" type="text/css" href="ts_styles.css" />
</head>
<body id="editor">
<div class="page" unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">
<?php $ts_utils->buildMenu("none",$access); ?>
<div id="pagemarker"><?php echo "<a href=\"./../index.php?section=$section&amp;page=$page\">".$pagepath."</a>"; ?><span id="saved_status"></span><span id="sel-element"></span></div>
<div class="content">
<div class="toolbar">
<img  id="btn_prev" src="icons/ed_preview.png" alt="Preview this page" title="Preview this page" width="25" height="25" /><img  id="btn_mode" src="icons/ed_html.png" alt="Switch editing mode" title="Switch to HTML view" width="25" height="25" /><img  id="savebutton" src="icons/ed_save.png" alt="Save" title="Save this page" width="25" height="25" /><span id="code_view">&lt;HTML&gt; view..</span><span id="buttonblock">
<select name="imgformat" title="Image formatting" id="imgformat" style="display:none;">
<option class="opttop" value="" selected="selected">&mdash; Image Styles &mdash;</option>
<optgroup label="&nbsp; Image styles" title="Image styles">
<option value="">None</option>
<?php if(isset($styles['img'])){foreach($styles['img'] as $style) {if (strpos($style, 'cp-') !== 0) echo "<option value=\"$style\">img.$style</option>\n";}} ?>
</optgroup>
</select><select  name="format" title="Text formatting" id="format">
<option class="opttop" value="" selected="selected">&mdash; Text Styles &mdash;</option>
<optgroup label="&nbsp; Headings" title="Headings">
<option value="h1">heading 1</option>
<option value="h2">heading 2</option>
<option value="h3">heading 3</option>
<option value="h4">heading 4</option>
<option value="h5">heading 5</option>
<option value="h6">heading 6</option>
<?php if(isset($styles['h'])){foreach($styles['h'] as $style) {echo "<option value=\"$style\">$style</option>\n";}} ?>
</optgroup>
<optgroup label="&nbsp; Block elements" title="Block elements">
<option value="p">paragraph</option>
<?php if(isset($styles['p'])){foreach($styles['p'] as $style) {echo "<option value=\"p.$style\">p.$style</option>\n";}} ?>
<option value="blockquote">blockquote</option>
<option value="div">div</option>
<?php if(isset($styles['div'])){foreach($styles['div'] as $style) {echo "<option value=\"div.$style\">div.$style</option>\n";}} ?>
</optgroup>
<optgroup label="&nbsp; Inline elements" title="Inline elements">
<option value="underline">underline</option>
<option value="strikethrough">strikethrough</option>
<?php if(isset($styles['span'])){foreach($styles['span'] as $style) {if (strpos($style, 'ts-') !== 0) echo "<option value=\"span.$style\">span.$style</option>\n";}} ?>
</optgroup>
</select><img id="btn_bold" src="icons/ed_bold.png" alt="Bold" title="Bold text" width="25" height="25" /><img  id="btn_italic" src="icons/ed_italic.png" alt="Italic" title="Italic text" width="25" height="25" /><img  id="btn_ljust" src="icons/ed_aleft.png" alt="Align left" title="Align left" width="25" /><img  id="btn_cjust" src="icons/ed_acentre.png" alt="Centre" title="Centre" width="25" /><img  id="btn_rjust" src="icons/ed_aright.png" alt="Align right" title="Align right" width="25" /><img  id="btn_indent" src="icons/ed_indent.png" alt="Indent" title="Increase indent" width="25" height="25" /><img  id="btn_outdent" src="icons/ed_outdent.png" alt="Outdent" title="Decrease indent" width="25" height="25" /><img  id="btn_tcol" src="icons/ed_fcolour.png" alt="Text colour" title="Text colour" width="25" height="25" /><img  id="btn_sub" src="icons/ed_sub.png" alt="Subscript text" title="Subscript text" width="25" height="25" /><img  id="btn_sup" src="icons/ed_super.png" alt="Superscript text" title="Superscript text" width="25" height="25" /><img  id="btn_hr" src="icons/ed_hrule.png" alt="Insert a horizontal rule" title="Insert a horizontal rule" width="25" height="25" /><img  id="btn_ul" src="icons/ed_ulist.png" alt="Make a bulleted list" title="Make a bulleted list" width="25" height="25" /><img  id="btn_ol" src="icons/ed_olist.png" alt="Make a numbered list" title="Make a numbered list" width="25" height="25" /><img  id="btn_link" src="icons/ed_link.png" alt="Insert a link" title="Insert a link" width="25" height="25" /><img  id="btn_table" src="icons/ed_table.png" alt="Insert a table" title="Insert a table" width="25" height="25" /><img  id="btn_char" src="icons/ed_char.png" alt="Insert a special character" title="Insert a special character" width="25" height="25" /><img  id="btn_inc" src="icons/ed_include.png" alt="Insert a script" title="Insert a script" width="25" height="25" /><img  id="btn_img" src="icons/ed_image.png" alt="Insert an image" title="Insert an image" width="25" height="25" /><img  id="btn_tools" src="icons/ed_tools.png" alt="Tools" title="Show/hide tools" width="25" height="25" /><img  id="btn_avm" src="icons/ed_avm.png" alt="Audio/video" title="Insert audio or video" width="25" height="25" />
</span>
</div>
<object id="edit_frame" type="text/html" data="../__.php?section=<?php echo $section; ?>&amp;page=<?php echo $page; ?>"></object>
<input type="hidden" id="section" name="section" value="<?php print $section; ?>" />
<input type="hidden" id="page" name="page" value="<?php print $page; ?>" />
<input type="hidden" id="theme" name="theme" value="<?php print TS_THEME; ?>" />
<input type="hidden" id="pagestyles" name="pagestyles" value="<?php echo (TS_PAGESTYLES)?'on':'off'; ?>" />
<input type="hidden" id="body_class" name="body_class" value="<?php print 'tp-'.str_replace(" ","-",strtolower($page)).' ts-'.str_replace(" ","-",strtolower($section)); ?>" />
<div id="ts_tools">
	<select  name="ts_correct" title="Editing accessories" id="ts_correct">
	<option class="opttop" value="" selected="selected">&mdash; Accessories &mdash;</option>
	<option value="undo" title="Undo the last command">Undo</option>
	<option value="redo" title="Redo the previous undo">Redo</option>
	<option value="delete" title="Delete the current selection">Delete</option>
	<option value="selectAll" title="Select all">Select all</option>
	<option value="removeFormat" title="Remove formatting">Remove format</option>
	<option value="unlink" title="Remove link">Unlink</option>
	<option value="cleanPaste" title="Paste rich text without formatting">Paste as plain text</option>
	<option id="outlines" value="outlines" title="Show/hide outlines">Show outlines</option>
	<option id="hide-styles" value="hideStyles" title="Hide/show styles">Remove styling</option>
	<option id="show-tag" value="showTag" title="Hide/show tag names on click">Show tag on click</option>
	</select>
	<select name="ts_styles_pane" title="Styles pane" id="ts_styles_pane">
	<option class="opttop" value="" selected="selected">&mdash; Styles viewer &mdash;</option>
	<option value="sp_headings" title="View heading styles">Headings</option>
	<option value="sp_paras" title="View block styles">Block styles</option>
	<option value="sp_inline" title="View inline styles">Inline styles</option>
	<option value="sp_images" title="View image styles">Images</option>
	<option value="sp_tables" title="View table styles">Tables</option>
	</select>
</div>
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body></html>