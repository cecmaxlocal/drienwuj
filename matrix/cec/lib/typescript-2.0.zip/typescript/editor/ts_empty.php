<?php 
session_start(); 
if(!defined('TS_EMPTY')) {
	require 'index.php';
	return;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="stylesheet" type="text/css" href="editor/ts_styles.css" />
<title>Typescript &nbsp; &middot;&middot;&middot; &nbsp; THIS SITE IS EMPTY &nbsp; &middot;&middot;&middot; &nbsp;</title>
</head>
<body>
<div class="page">
<div class="head_nav"></div>
<div class="content">
<div class="warning" style="border:1px solid red; margin-top:2em">
<p>
<img src="editor/icons/refused.png" alt="Error" /> <strong>This Typescript site is empty.</strong> 
<?php if(isset($_SESSION['access']) && ($_SESSION['access'] > 1)) echo '<a href="editor/pages.php">Click here to add pages.</a>'; ?>
</p>
</div>
</div>
</div>
</body>
</html>
