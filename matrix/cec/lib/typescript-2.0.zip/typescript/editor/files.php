<?php 
// 2009.08.24
define('TS_EDIT',true);
require 'reality_check.php'; 
$ts_utils->access($access==3);
error_reporting(E_ERROR);
if(isset($_GET['section'])) {
	$file=basename($_GET['file']);
	$section=basename($_GET['section']);
	switch ($section) {
	case "core":
		$file="nucleus/corefiles/$file";
		break;
	case "theme":
		$file="themes/".TS_THEME."/$file";
	break;
	case "scripts":
		$file="nucleus/scripts/$file";
		break;
	default:
		$ts_utils->access(false);
	}
} else {
	$file=$ts_utils->defaultCoreFile('nucleus/corefiles/readme.txt');
	$section="core";
}
$readOnly=!is_writable("./../$file");

function listDir($filedir,$label,$section) {
	echo "<optgroup label='$label'>";
	$d = @opendir('./../'.$filedir);	
	while (false !== ($f = readdir($d))) {
		if (is_file("./../$filedir/$f")) {
		echo '<option value="section=',$section,'&amp;file=',$f,'">',$f,'</option>';
		echo "\n";
		}
	}
	closedir($d);
	echo '</optgroup>';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Admin: Core File Editor'); ?>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/typescript.js"></script>
<script type="text/javascript">
// <![CDATA[
function fsubmit() {
  location.href="files.php?"+$F('option_selector');
}
Event.observe(window,"load",function() {   
	$("option_selector").observe("change",fsubmit);
	if($("savebutton")) {
		$("savebutton").observe("click",function() {tsu.post("<?php echo $file ?>");});
	}
	}); 
// ]]>
</script>
</head>
<body id="files">
<div class="page">
<?php $ts_utils->buildMenu("files",$access); ?>
<div class="content">
<div class="toolbar">
<select id="option_selector" title="Choose a file to edit">
<option value="" selected="selected">Files ...</option>
<?php
listDir('themes/'.TS_THEME,'Files for the '.TS_THEME.' theme','theme');
listDir('nucleus/corefiles','Typescript Core Files','core');
listDir('nucleus/scripts','Scripts','scripts');
?>
</select>
<?php if($readOnly){
echo '<img src="icons/readonly.png" title="Read only file" alt="Read only file" />[<small>This file is not writable.</small>] &nbsp;';
} else {
echo '<img src="icons/ed_save.png" title="Save file" alt="Save file" id="savebutton" />'; 
} echo $file ?><span id="saved_status"></span>
</div>
<textarea id="file_content" cols="90" rows="60" name="file_content"  <?php if($readOnly) echo 'disabled="disabled"'; ?> >
<?php $ts_utils->readContents("./../$file"); ?>
</textarea>
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body>
</html>