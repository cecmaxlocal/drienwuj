<?php 
// 2009.11.22
define('TS_EDIT',true);
require 'reality_check.php'; 
	// read  <table> styles from the style sheets
	$css=file_get_contents('./../pagestyles.css');
	$css.=file_get_contents('../themes/'.TS_THEME.'/themestyles.css');
	preg_match_all("/(^|\n) *table\.(\w+)/",$css,$matches);
	$styles=array_unique($matches[2]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Table designer</title>
<?php echo '<link rel="stylesheet" type="text/css" href="../themes/' . TS_THEME . '/themestyles.css" />' . "\nl";
if(TS_PAGESTYLES) {
	echo '<link rel="stylesheet" type="text/css" href="../pagestyles.css" />' . "\n";
}
?>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript" src="js/insert_table.js"></script>
</head>
<body id="insert_table" onload="makeTable();" onkeydown="return handleReturn(event);">
<form action="" style="-moz-user-select:none;-webkit-user-select:none;">
<div>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Width:
	<input name="width" type="text" id="width" value="100" size="4" onblur="makeTable();" />
		<select name="widthUnits" id="widthUnits" title="change units" onchange="makeTable();">
			<option value="none" selected="selected">none</option>
			<option value="px">px</option>
			<option value="%">%</option>
		</select>
		<img unselectable="on" src="icons/minus.png" alt="" title="decrease width" onmousedown="spinner('width',-5,1);" />
		<img unselectable="on" src="icons/plus.png" alt="" title="increase width" onmousedown="spinner('width',5,1);" />
	</span>
	
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Style:
	<select name="tbl_style" id="tbl_style" title="select table style" onchange="makeTable();">
			<option value="default" selected="selected">default</option>
			<?php if(is_array($styles)){foreach($styles as $style) {echo "<option value=\"$style\">$style</option>\n";}} ?>
	</select>
	</span>

	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Rows:
	<input name="rows" type="text" id="rows" value="2" size="2" onblur="makeTable();" />
		<img unselectable="on" src="icons/minus.png" alt="" title="decrease number of rows" onmousedown="spinner('rows',-1,1);" />
		<img unselectable="on" src="icons/plus.png" alt="" title="increase number of rows" onmousedown="spinner('rows',1,1);" />
	</span>
	
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Columns:
	<input name="columns" type="text" id="columns" value="2" size="2" onblur="makeTable();" />
		<img unselectable="on" src="icons/minus.png" alt="" title="decrease number of columns" onmousedown="spinner('columns',-1,1);" />
		<img unselectable="on" src="icons/plus.png" alt="" title="increase number of columns" onmousedown="spinner('columns',1,1);" />
	</span>
		
</div>

<div>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Caption:
	<select name="caption" id="caption" onchange="makeTable();">
			<option value="cptn_none" selected="selected">none</option>
			<option value="cptn_use">use caption</option>
	</select>
	</span>

	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Header:
	<select name="ts_hdr" id="ts_hdr" onchange="makeTable();">
		<option value="hdr_none" selected="selected">none</option>
		<option value="hdr_single">single</option>
		<option value="hdr_cols">columns</option>
	</select>
	</span>
	
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Footer:
	<select name="ts_ftr" id="ts_ftr" onchange="makeTable();">
		<option value="ftr_none" selected="selected">none</option>
		<option value="ftr_single">single</option>
		<option value="ftr_cols">columns</option>
	</select>
	</span>
	
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">
	<input type="checkbox" name="ts_fchd" id="ts_fchd" onclick="makeTable();" />Use 1st column for headings
	</span>
</div>

<div>
	<span>
	<input class="submit" type="button" value="Insert Table" title="Insert the table" onclick="addTable();" />
	<input class="submit" type="button" value="Cancel" title="Close this window" onclick="window.close();" />
	</span>
	
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">
	<input type="checkbox" name="ts_dtxt" id="ts_dtxt" checked="checked" onclick="makeTable();" />Insert dummy text
	</span>
</div>

</form>
<div id="ts-content"></div>
</body>
</html>