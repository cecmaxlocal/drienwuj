<?php 
// 2010.04.22
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->access($access==3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Admin: Title, Header, Footer'); ?>
<script type="text/javascript" src="js/prototype.js"></script>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
var tst = {
  saved:true,
  warning:'YOU HAVE NOT SAVED YOUR WORK.\nChanges will be lost if you refresh or leave this page.',
  init: function() {
    $('tytitle','tyhead','tyfoot').invoke('observe','keydown',
      function(obj) {
        $('submit').enable();
        tst.saved=false;
      });
    $('config').observe('submit',tst.save);
    window.onbeforeunload=tst.checkSaved;		
  },
  save: function() {
    tst.saved=true;
  },
  checkSaved: function() {
    if (!tst.saved) {
      return tst.warning;
    }
  }
}

document.observe('dom:loaded', tst.init);
// ]]>
</script>
</head>
<body id="titles">
<div class="page">
<?php
$ts_utils->buildMenu("titles",$access);
if (isset($_POST['tytitle'])) {
	$tsql->updatePageTitles($_POST['tytitle'],$_POST['tyhead'],$_POST['tyfoot']);
}
$cf=$tsql->getConfig();
?>
<div class="content">
<form action="" id="config" method="post">
<fieldset>
<legend>Site Title, Page Header &amp; Page Footer</legend>
<label for="tytitle">Site title..</label>
<input type="text" value="<?php echo $cf['title']; ?>" size="180" maxlength="180" name="tytitle" id="tytitle" /><br />
<label for="tyhead">Page Header..<br /><span>text/html</span></label>
<?php 
$cfHead = stripslashes($cf['header']); 
?>
<textarea cols="60" rows="5" name="tyhead" id="tyhead"><?php echo $cfHead; ?></textarea><br />
<label for="tyfoot">Page Footer..<br /><span>text/html</span></label>
<?php 
$cfFoot = stripslashes($cf['footer']); 
?>
<textarea cols="60" rows="5" name="tyfoot" id="tyfoot"><?php echo $cfFoot; ?></textarea><br />
<input type="submit" id="submit" disabled="disabled" value="Save page titles" /> 
</fieldset>
</form>
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body>
</html>
