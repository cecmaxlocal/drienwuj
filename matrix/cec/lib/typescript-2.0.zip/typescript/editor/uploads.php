<?php 
// 091004-100309
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->no_cache();
$ts_utils->access($access>1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Uploaded File Management'); ?>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/typescript.js"></script>
<!--[if IE]><style type="text/css">
.ip {filter:alpha(opacity=0);} 
</style><![endif]-->
</head>
<body id="uploads">
<div class="page">
<?php $ts_utils->buildMenu("uploads",$access); ?>
<div class="content">
<?php
$imgtypes = array("png", "gif", "jpg", "jpeg");
$bannedtypes = array("php", "exe", "bat");
$imgfolder="";
$imagedir="../images";
$upl_imgdir=$imagedir;
  if(isset($_POST['imgfolder'])) {
    $imgfolder=$_POST['imgfolder'];
    if($imgfolder) $upl_imgdir.="/$imgfolder";
    }
  $filedir="../resources"; 
  $hidden="style=\"display:none\"";
  $checked="checked=\"checked\"";
//-----delete folder -------
if(isset($_POST['imgfolderdel'])) {
$imgfolderdel=$_POST['imgfolderdel'];
if(is_dir($imgfolderdel)) {
 if(rmdir($imgfolderdel)) {
 $report_msg="";
 $imgfolder="images";
 } else {
 $report_msg="<p>Unable to delete the folder \"<b>".substr(strrchr($imgfolderdel, "/"), 1)."</b>\"</p>";
 }
 if($report_msg) {$ts_utils->report($report_msg);}
 }
}

//-----make newfolder -------
if(isset($_POST['newfolder'])) {
$newfolder=strtolower($_POST['newfolder']);
if(strrchr($newfolder,"/")) $newfolder=strrchr($newfolder,"/");
$newfolder=trim($newfolder);
$newfolder=ltrim($newfolder,'/');
$report_msg="<b>Invalid image folder name:</b> Begin folder names with a letter followed by any combination of letters, numbers and underscores. <br />Do not include spaces.";
$imgfolder="images";
if(preg_match('/^[a-z]\w*$/',$newfolder)) {
mkdir("./../images/".$newfolder);
$report_msg="";
$imgfolder=$newfolder;
}
if($report_msg) {$ts_utils->report($report_msg);}
}
// file upload
if (isset($_POST['upload']) && isset($_FILES['f1'])) {
  $msg='';
  foreach($_FILES as $file) {
    if (!$fname=$file['name']) {
		break;
    }
	$ftype=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
	if(!in_array($ftype,$bannedtypes)) {
		if(in_array($ftype,$imgtypes)) {
			$loc=$upl_imgdir;
		} else {
			$loc=$filedir;
		}
			$ul_path = $loc.'/'.basename($fname);
			move_uploaded_file($file['tmp_name'], $ul_path);
			if($file['error'] !== 0) {
				$msg.= '<li><b>FAILED TO UPLOAD: '.$file['name'].' </b>(max upload size: '.$ts_utils->getMaxUploadSize().' bytes)</li>';
			}
		} else {
			$msg.= '<li><b>FAILED TO UPLOAD: '.$file['name'].' </b>(Not an appropriate type of file.)</li>';
		}
	}
	if($msg) {$ts_utils->report("</ul>$msg</ul>");}
}
//-----image deletion --------
if (isset($_POST['img_num'])) 
	{
	$img_num=$_POST['img_num'];
	$deletedi=false;
	for ($n=0;$n<=$img_num;$n++) 
		{
		if (isset($_POST["img".$n]))
			{
			$image = $_POST["img".$n];
			if(file_exists('./'.$imagedir.'/'.$image)) {
			unlink('./'.$imagedir.'/'.$image);
			}
			$deletedi=true;
			}
		}
	unset($img_num);
	}
//-----resource deletion --------
if (isset($_POST['res_num'])) 
	{
	$res_num=$_POST['res_num'];
	$deletedr=false;
	for ($n=0;$n<=$res_num;$n++) 
		{
		if (isset($_POST["res".$n]))
			{
			$resource = $_POST["res".$n];
			if(file_exists('./'.$filedir.'/'.$resource)) {
			unlink('./'.$filedir.'/'.$resource);
			}
			$deletedr=true;
			}
		}
	unset($res_num);
	if ((!$deletedi) and (!$deletedr)) {
        $ts_utils->report("<b>Nothing deleted:</b> No files were selected.");
        } 
	}

// make sure the image directory exists and open for listing
$d = opendir('./'.$imagedir) or die();
$s=0;
echo '<h4>File uploads</h4>';
	echo "<form action=\"\" method=\"post\" id=\"fdel\" >\n<div>\n";
        echo "<img class=\"root\" src=\"icons/folder.png\" value=\"$s\" alt=\"open/close\" title=\"open/close\" /> &nbsp; images\n";
        echo "<div id=\"collapse$s\" class=\"indent\" style=\"display:none;\">";
	$n = 0;
	while (false !== ($f = readdir($d))) 
		{
		if (($f<>".") and ($f<>"..")) 
			{
			if(is_file('./'.$imagedir.'/'.$f)) {
                          $n++;
                          $ftime=strftime('%a %b %d %Y',filemtime('./'.$imagedir.'/'.$f)).' - ';
                          $fsize=filesize('./'.$imagedir.'/'.$f);
                          $fsize=($fsize>1024) ? round($fsize/1024,1).' kB' : $fsize.' B';
                          echo "<img src=\"icons/file.png\" class=\"file\" alt=\"select/deselect\" title=\"select/deselect\" /><input type=\"checkbox\" name=\"img$n\" value=\"$f\" />&nbsp; <a href=\"./$imagedir/$f\">$f</a> &nbsp;<small>$ftime $fsize</small><br />\n";
                         } elseif(is_dir('./'.$imagedir.'/'.$f)) {
                         $sub_dir[]=$f;
                         }
			}
		}
        if ($n==0) {echo "<i>&nbsp; &middot; <small>This folder contains no images</small></i>\n";}
closedir($d);        

// image sub directories (if any)...
if(isset($sub_dir)) {
 foreach($sub_dir as $x) {
 $img_dir="./".$imagedir."/".$x;
 $m=0;$s+=1;
 $d = opendir($img_dir) or die($e_noimg);
 echo "<div><img src=\"icons/folder.png\" class=\"folder\" value=\"$s\" alt=\"open/close\" title=\"open/close\" /> &nbsp; images/".$x."</div>\n";
 echo "<div id=\"collapse$s\" class=\"indent\" style=\"display:none;\">";
	while (false !== ($f = readdir($d))) 
		{
		if (($f<>".") and ($f<>"..")) 
			{
			if(is_file('./'.$imagedir.'/'.$x.'/'.$f)) {
                          $n++;	
                          $m++;
                          $ftime=strftime('%a %b %d %Y',filemtime($img_dir.'/'.$f)).' - ';
                          $fsize=filesize($img_dir.'/'.$f);
                          $fsize=($fsize>1024) ? round($fsize/1024,1).' kB' : $fsize.' B';
			 echo "<img src=\"icons/file.png\" class=\"file\" alt=\"select/deselect\" title=\"select/deselect\" /><input type=\"checkbox\" name=\"img$n\" value=\"$x/$f\" />&nbsp; <a href=\"$img_dir/$f\">$f</a> &nbsp;<small>$ftime $fsize</small><br />\n";
			}
		}
                }
 if ($m==0) {
 $del_forms[]="<form id=\"del$s\" action=\"\" method=\"post\"><input type=\"hidden\" name=\"imgfolderdel\" value=\"$img_dir\" /></form>";
 echo "<div value=\"$s\" class=\"delfolder\" >Delete this empty folder</div>\n";
 }
 echo "</div>";
 closedir($d);        
 }
}
echo '<div id="new-folder" class="nufolder" title="Create a new image sub-folder" >Click here to make a new image sub-folder</div>';
echo '</div>';
echo  "<input type=\"hidden\" name=\"img_num\" value=\"$n\" />\n";
      

?>
<!-- RESOURCES -->
<?php
$s+=1;
// make sure the resource directory exists and open it for listing
$d = opendir('./'.$filedir) or exit;
	
        echo "<div><img class=\"root\" src=\"icons/folder.png\" value=\"$s\" alt=\"open/close\" title=\"open/close\" /> &nbsp; resources</div>\n";
        echo "<div id=\"collapse$s\" class=\"indent\" style=\"display:none;\">";
	$n = 0;
	while (false !== ($f = readdir($d))) 
		{
		if (($f<>".") and ($f<>"..")) 
			{
			$n++;
                        $ftime=strftime('%a %b %d %Y',filemtime('./'.$filedir.'/'.$f)).' - ';
                        $fsize=filesize('./'.$filedir.'/'.$f);
                        $fsize=($fsize>1024) ? round($fsize/1024,1).' kB' : $fsize.' B';
			echo "<img src=\"icons/file.png\" class=\"file\" alt=\"select/deselect\" title=\"select/deselect\" /><input type=\"checkbox\" name=\"res$n\" value=\"$f\" />&nbsp; ";
			if(strtolower(substr($f,-4)) == '.php') {
				echo '<span class="nolink">' . $f . '</span>';
				} else {
				echo "<a href=\"./$filedir/$f\">$f</a>";
			}
			echo " &nbsp;<small>$ftime $fsize</small><br />\n";
			}
		}
	if ($n==0) {echo " &nbsp; &middot; <i><small>The resources folder is empty</small></i><br />\n";}
        echo "</div>\n";
        echo "<hr />\n";
        echo "<input type=\"hidden\" name=\"res_num\" value=\"$n\" />\n<input type=\"submit\" id=\"delfiles\" title=\"Delete selected files\" value=\"Delete selected files\" />\n</div>\n</form>\n";
	
closedir($d);
?>
<form id="createimgfolder" action="" method="post">
<div>
<input type="hidden" name="imgfolder" value="" />
<input type="text" name="newfolder" id="newfolder" value="new folder name" /><input type="submit" class="submit" value="Create Folder" />
</div>
</form>

<form id="uld" enctype="multipart/form-data" action="" method = "post">
<div>
  <div id="dummy"><img src="icons/browse.png" alt="Browse for files" />Browse...</div>
  <?php for($id=1;$id<9;$id++) {
  echo "<input id=\"id$id\" class=\"ip\" type=\"file\" size=\"1\" name=\"f$id\" title=\"Browse for files to upload\" />\n";
  }?>
<div id="qwrapper"><span id="imgfldrs">
<?php 
  if (isset($sub_dir)) {
    echo 'Image subfolder:';
    echo '<input type="radio" name="imgfolder" value="" ';
      if($imgfolder=="") echo $checked;
    echo ' />NONE';
      foreach($sub_dir as $x) {
      $chkd="";
      if($imgfolder==$x) $chkd=$checked;
      echo '<input type="radio" name="imgfolder" value="',$x,'" ',$chkd,' />',$x;
      }
  }
?>
    </span><br /><i>Files to upload</i>:
    <ol id="queue"></ol> <!-- won't validate because child elements filled in by js -->
    <button id="upload" name="upload">Upload</button>
</div>
</div>
</form>

<?php
if(isset($del_forms)) {
	foreach($del_forms as $form) echo $form."\n";
}
?>
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body>
</html>
