<?php 
// 2010.02.04
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->no_cache();
$resFolder='../resources/';
$vidTypes=array('flv','FLV','mp4','MP4');
$mediaFiles=glob("$resFolder*.{flv,FLV,mp4,MP4,mp3,MP3}",GLOB_BRACE);
$file=(array_key_exists('file', $_GET))?$resFolder.$_GET['file']:'';
$mediaType=pathinfo($file, PATHINFO_EXTENSION);
$startImg=(array_key_exists('startimage', $_GET))?'&amp;startimage='.$_GET['startimage']:'';
$configFile=($mediaType)?'../themes/'.TS_THEME.'/'. $mediaType . '_config.txt':'';
$config=file_exists($configFile)?'&amp;config=' . $configFile:'';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Audio-video media</title>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
  	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/effects.js"></script>
	<script type="text/javascript" src="js/dragdrop.js"></script>
	<script type="text/javascript" src="js/typescript.js"></script>
</head>
<body id="avmedia">
<?php
if(!count($mediaFiles)) {
	echo "
<div id='newsflash'>No media files are available.<br />
Use 'Uploads' to add flv (video), mp4 (video) or mp3 (audio) files to your site.</div>
</body>
</html>";
	return;
}
?>
<form action="" id="avm" style="-moz-user-select:none;-webkit-user-select:none;">
<div>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">
		File name:<select name="mediaFile" id="mediaFile" title="Choose a video or sound file" onchange="avm.setFile()">
		<option value=''>Choose media file</option>
		<?php
			foreach($mediaFiles as $f) {
				$val=basename($f);
				$s=($f==$file)?' selected="selected"':'';
			echo "<option value='$val'$s>$val</option>\n";
			}
		?>
		</select>
	</span>
	
	<?php if(in_array($mediaType,$vidTypes)): ?>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;">Size:
		<select name="presetSize" id="presetSize" title="Change video size" onchange="avm.presetSize()">
			<optgroup label="Unrestricted">
			<option value="none">Resize freely</option>
			<?php if($startImg): ?>
			<option value="startimage">Start image size</option>
			<?php endif; ?>
			</optgroup>
			<optgroup label="Aspect 4:3">
			<option value="640:480">640 x 480</option>
			<option value="576:432">576 x 432</option>
			<option value="512:384">512 x 384</option>
			<option value="448:336">448 x 336</option>
			<option value="384:288">384 x 288</option>
			<option value="320:240" selected="selected">320 x 240</option>
			<option value="256:192">256 x 192</option>
			<option value="192:144">192 x 144</option>
			</optgroup>
			<optgroup label="Aspect 16:9">
			<option value="768:432">768 x 432</option>
			<option value="640:360">640 x 360</option>
			<option value="512:288">512 x 288</option>
			<option value="384:216">384 x 216</option>
			<option value="256:144">256 x 144</option>
			</optgroup>
		</select>
	</span>
	<span id='startimg'></span>
</div>
<div id="unrestricted">
	<span>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;"><b>Width</b>:<span id="width">320px</span></span>
	<span unselectable="on" style="-moz-user-select:none;-webkit-user-select:none;"><b>Height</b>:<span id="height">240px</span></span>
	Drag the red outline to resize.</span>
	<?php endif; ?>
</div>
<?php if($file): ?>
<div>
	<span>
	<input class="submit" type="button" value="Insert <?php echo basename($file); ?>" title="Insert the media object" onclick="avm.addMedia();" />
	<input class="submit" type="button" value="Cancel" title="Close this window" onclick="window.close();" />
	</span>
</div>
<?php endif; ?>
</form>
<?php if($file): ?>
<div id="container" style="left:10px;top:10px;width:100px;height:100px;position:relative;">
	<?php if(in_array($mediaType,$vidTypes)): ?>
	<object id="placeholder" type="application/x-shockwave-flash" data="../avmedia/player_flv_maxi.swf" width="320" height="240">
		<param name="movie" value="../avmedia/player_flv_maxi.swf" />
		<param name="flashvars" value="flv=<?php echo $file.$startImg.$config; ?>" />
	</object>
	<div id="grabRight" style="width:10px;height:240px;position:absolute;left:320px;top:0px;cursor:e-resize;border-right:2px solid red"></div>
	<div id="grabCorner" style="width:10px;left:320px;top:240px;height:10px;position:absolute;cursor:se-resize;border-right:2px solid red;border-bottom:2px solid red"></div>
	<div id="grabBottom" style="width:320px;height:10px;position:absolute;left:0px;top:240px;cursor:s-resize;border-bottom:2px solid red"></div>
	<?php else: ?>
	<object id="placeholder" type="application/x-shockwave-flash" data="../avmedia/player_mp3_maxi.swf" width="200" height="20">
		<param name="wmode" value="transparent" />
		<param name="movie" value="../avmedia/player_mp3_maxi.swf" />
		<param name="FlashVars" value="mp3=<?php echo $file.$config; ?>" />
	</object>
	<?php endif; ?>
</div>
<?php endif; ?>
<input type="hidden" id="media-type" name="media-type" value="<?php echo in_array($mediaType,$vidTypes)?'flv':'mp3'; ?>" />
</body>
</html>