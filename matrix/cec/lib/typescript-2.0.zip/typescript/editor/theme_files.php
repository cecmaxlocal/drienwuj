<?php
// 2009.11.10
define('TS_EDIT',true); 
require 'reality_check.php'; 
$ts_utils->access($access==3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Admin: Theme File Management'); ?>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/typescript.js"></script>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
function fnconfirm() {
if (confirm("Are you sure you want to delete the selected file(s)?")) {
document.getElementById("fdel").submit(); }
}
// ]]>
</script>
</head>
<body id="theme_files">
<div class="page">
<?php
$ts_utils->buildMenu("none",$access);
$php_self=$_SERVER['PHP_SELF'];
$report_msg="";
echo "<div class=\"content\">\n";
  $imagedir="./../themes/".TS_THEME."/images";
  $filedir="./../themes/".TS_THEME; 
error_reporting(E_ERROR);
//-----file upload --------
if (isset($_FILES['fupload'])) 
	{
	if (strpos($_FILES['fupload']['type'],"image") === 0)
		{
		$target_path = "./".$imagedir."/".basename($_FILES['fupload']['name']);
		$report_msg = "<p>Image uploaded: <b>" . basename($_FILES['fupload']['name']) . "</b> &nbsp; file size: " . $_FILES['fupload']['size']  . "bytes</p>"; 
		}
		else
		{
		$target_path = "./$filedir/" . basename($_FILES['fupload']['name']);
		$report_msg = "<p>File uploaded: <b>" . basename($_FILES['fupload']['name']) . "</b> &nbsp; file size: " . $_FILES['fupload']['size']  . "bytes</p>"; 
		}

if(!move_uploaded_file($_FILES['fupload']['tmp_name'], $target_path)) {
    $report_msg="<p><b>Unable to upload the file</b></p><p>Check the filename and try again. &nbsp;</p>";
} 

	echo "$report";
	}
//-----image deletion --------
// img_num will only be set if the form has been submitted (i.e we wish to delete files)
if (isset($_REQUEST['img_num'])) 
	{
	$img_num=$_REQUEST['img_num'];
	$deletedi=false;
	for ($n=0;$n<=$img_num;$n++) 
		{
		if (isset($_REQUEST["img".$n]))
			{
			$image = $_REQUEST["img".$n];
			unlink('./'.$imagedir.'/'.$image);
			$fgone[]=$image;
			$deletedi=true;
			}
		}
	unset($img_num);
	}
//-----core file deletion --------
if (isset($_REQUEST['res_num'])) 
	{
	$res_num=$_REQUEST['res_num'];
	$deletedr=false;
	for ($n=0;$n<=$res_num;$n++) 
		{
		if (isset($_REQUEST["res".$n]))
			{
			$resource = $_REQUEST["res".$n];
			unlink('./'.$filedir.'/'.$resource);
			$fgone[]=$resource;
			$deletedr=true;
			}
		}
	unset($res_num);
	if ((!$deletedi) and (!$deletedr)) {
			 $report_msg="<p><b>Nothing deleted:</b></p><p>No files were selected</p>";
        } else {
        $report_msg="<p><b>Deleted:</b></p><p><ul>";
					foreach($fgone as $x) {
						$report_msg=$report_msg."<li>".$x."</li>";
          }
				$report_msg.="</ul></p>";
				}
	}
				if($report_msg) {$ts_utils->report($report_msg);}
// make sure the image directory exists and open for listing
$d = opendir('./'.$imagedir) or exit;
	echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\" id=\"fdel\" >\n<fieldset>\n<legend>Files available to the '".TS_THEME."' theme</legend><table><tr><th>&nbsp;</th><th>File name</th><th><small>Uploaded/modified</small></th><th><small>Size</small></th></tr>";
        echo "<tr><td colspan=\"3\">Images..</td></tr>";
	$n = 0;
	while (false !== ($f = readdir($d))) 
		{
		if (($f<>".") and ($f<>"..")) 
			{
			$n++;
                        $fsize=filesize('./'.$imagedir.'/'.$f);
                        $fsize=($fsize>1024) ? round($fsize/1024,1).' kB' : $fsize.' B';
			echo "<tr><td><input type=\"checkbox\" name=\"img$n\" value=\"$f\" /></td><td>&nbsp; <a href=\"./$imagedir/$f\">$f</a> &nbsp;</td><td><small>&nbsp; ".strftime('%a %b %d %H:%M %Y',filemtime('./'.$imagedir.'/'.$f))." &nbsp;</small></td><td><small>&nbsp; $fsize &nbsp;</small></td></tr>\n";
			}
		}
        echo  "<tr><td colspan=\"4\"><input type=\"hidden\" name=\"img_num\" value=\"$n\" /></td></tr>";
        if ($n==0) {echo "<tr><td colspan=\"4\"><small>The images folder is empty</small></td></tr>";}
      
closedir($d);
?>
<!-- THEME FILES -->
<?php
// make sure the directory exists and open it for listing
$disabled = 'disabled="disabled"';
$requiredFiles = array('template.php','printstyles.css','themestyles.css','notes.txt','theme.inc.php');
$d = opendir('./'.$filedir) or die($e_nores);
	
        echo "<tr><td colspan=\"3\">Other files..</td></tr>";
	$n = 0;
	while (false !== ($f = readdir($d))) 
		{
		if (is_file("./$filedir/$f")) 
			{
			$n++;
                        $fsize=filesize('./'.$filedir.'/'.$f);
                        $fsize=($fsize>1024) ? round($fsize/1024,1).' kB' : $fsize.' B';
						$status=(in_array($f,$requiredFiles))?$disabled:'';
			echo "<tr><td><input type=\"checkbox\" name=\"res$n\" value=\"$f\" $status /></td><td>&nbsp; ";
			if(strtolower(substr($f,-4)) == '.php') {
				echo '<span class="nolink">' . $f . '</span>';
				} else {
				echo "<a href=\"./$filedir/$f\">$f</a>";
			}
			echo " &nbsp;</td><td><small>&nbsp; ".strftime('%a %b %d %H:%M %Y',filemtime('./'.$filedir.'/'.$f))." &nbsp;</small></td><td><small>&nbsp; $fsize &nbsp;</small></td></tr>\n";
			}
		}
	if ($n==0) {echo "<tr><td colspan=\"4\"><small>This folder is empty</small></td></tr>\n";}
	echo "</table>\n<input type=\"hidden\" name=\"res_num\" value=\"$n\" /><br />\n<input type=\"button\" class=\"submit\" value=\"Delete selected files\" onclick=\"fnconfirm();\" />\n";	
closedir($d);
?>
</fieldset>
</form>
<!-- UPLOADS -->
<hr />
  <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
  <fieldset>
  <input type="hidden" name="MAX_FILE_SIZE" value="1024000" />
  <label for="fupload">Upload a file:</label><input type="file" id="fupload" name="fupload" class="submit" />
  <input type="submit" value="Upload" class="submit" />
  </fieldset>
  </form>
 </div>
 <?php include("./footer.inc.php"); ?>
</div> 
</body>
</html>