<?php 
// 2009.11.20
if(stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) {
	include 'index.php';
	exit;
}

class TS_Utils
{
   var $version = array(
      "major" => 2, 
      "minor" => 0, 
      "revision" => 0, 
      "date" => "1 November 2009",
      "team" => array("Ray Middleton","Ben Briggs"),
      );
      
   function writeLogEntry ($log_entry,$path='nucleus/corefiles/access.log') 
   {
      if (file_exists($path) && ($fh = @fopen($path, 'a')) && flock($fh, LOCK_EX)) {
         $ret=fwrite($fh, $log_entry."\n");
         flock($fh, LOCK_UN);
         fclose($fh);
         return $ret;
      } else {
         return false;
      }
   }

   function writeContents($fname,$data) 
   {
      if(($fp=@fopen($fname,'w')) && flock($fp, LOCK_EX)) {
				if(!$data) $data=" "; // don't allow empty files
				$ret=fwrite($fp,$data);
				flock($fp, LOCK_UN);
				fclose($fp);
				return $ret;
      } else {
				return false;
      }
   }
   
   function readContents($fname)
   {
    if(file_exists($fname)) {
     $path_parts = pathinfo($fname);
	if($path_parts['extension']=='css') {
		readfile($fname);
	} else {
		$fh = fopen($fname, 'r') or die($e_openf); 
			if (filesize($fname)>0) {
			$contents = fread($fh, filesize($fname)) or die($e_readf);
			}
		fclose($fh);	
		echo htmlentities($contents, ENT_COMPAT, "UTF-8");
	}
    }
   }
   
	function access($permit) {
		if(!$permit) {
			include "index.php";
			die;
		}
	}
   
	function readStyles() {
		global $tsql;
		$config=$tsql->getConfig();
		if(!defined('TS_THEME')) {
			define('TS_THEME',$config['theme']);
		}
		$styles = array();
		// read  <h>, <p>, <div> , <span> and <table> styles from the style sheets
		if(TS_PAGESTYLES) {
			$css=file_get_contents('./../pagestyles.css');
		} else {
			$css='';
		}
		$css.=file_get_contents('../themes/'.TS_THEME.'/themestyles.css');
		preg_match_all("/(^|\n) *h\d\.[-_\w]+/",$css,$matches);
		$styles['h']=array_unique($matches[0]);
		preg_match_all("/(^|\n) *p\.([-_\w]+)/",$css,$matches);
		$styles['p']=array_unique($matches[2]);
		preg_match_all("/(^|\n) *div\.([-_\w]+)/",$css,$matches);
		$styles['div']=array_unique($matches[2]);		
		preg_match_all("/(^|\n) *span\.([-_\w]+)/",$css,$matches);
		$styles['span']=array_unique($matches[2]);
		preg_match_all("/(^|\n) *img\.([-_\w]+)/",$css,$matches);
		$styles['img']=array_unique($matches[2]);
		preg_match_all("/(^|\n) *table\.([-_\w]+)/",$css,$matches);
		$styles['table']=array_unique($matches[2]);
		return $styles;
	}
   
	function writeHTMLTitle($section)
	{
		echo '<title>Typescript '.$this->version['major'].'.'.$this->version['minor'];
		echo " &nbsp; &middot;&middot;&middot; &nbsp; $section &nbsp; &middot;&middot;&middot; &nbsp;</title>\n";
	}

	function loginUser($username, $password)
	{
		if(headers_sent()) { 
			return; 
		}
		global $tsql;
		if ($access = $tsql->validateUser($username, $password))
		{
			session_start();
			$_SESSION['user']=$username;
			$_SESSION['access']=$access;
			$this->writeLogEntry('- ' . $username . ' : ' . @date('l dS F Y h.i A') . ' : ' . $_SERVER['REMOTE_ADDR']);
			return $access;
		}
		else
		{
			$this->writeLogEntry('! FAILED : ' . $username . ' : '. @date('l dS F Y h:i:s A') . ' : ' . $_SERVER['REMOTE_ADDR']);
			return false;
		}
	}
	
	function userLevel() 
	{
		session_start(); 
		return (!isset($_SESSION['access']))?false:$_SESSION['access'];
	}
	
	function defaultCoreFile($fname)
	{
		if(file_exists('./../'.$fname))
		{
			return $fname;
		}
		else
		{
			if ($handle = opendir('./../corefiles')) {
				while (false !== ($file = readdir($handle))) {
					if ($file != "." && $file != "..") {
					$fname = $file;
					break;
					}
				}
			closedir($handle);
			}
			return "corefiles/$fname";
		}
	}
	
	function delete_folder($folder)  // an identical function also exists in ts_pages
	{
	// cope with trailing slashes
		if(substr($folder,-1) == '/') {
			$folder = substr($folder,0,-1);
		}
		if(!file_exists($folder) || !is_dir($folder)) {
			return false;
		} elseif(!is_readable($folder)) {
			return false;
		} else {
			$fh = opendir($folder);
				while (false !== ($item = readdir($fh)))
				{
					if($item != '.' && $item != '..') {
						$path = $folder.'/'.$item;
						if(is_dir($path)) {
							$this->delete_folder($path);
						} else {
						unlink($path);
						}
					}
				}
			closedir($fh);
		if(!rmdir($folder)) {
			return false;
		}
		return true;
		}
	}
	
	function no_cache() {
		header("Expires: 0");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("cache-control: no-store, no-cache, must-revalidate");
		header("Pragma: no-cache");
	}

	function report($message) {
		echo "<div id=\"newsflash\"><p>$message<a href=\"#\">close</a></p></div>\n";
	}

	function getMaxUploadSize() {
		return trim(ini_get('upload_max_filesize'));
	}

	function buildMenu($page,$level) {
		function addLink($page,$link,$title) {
			if(!TS_PAGESTYLES && $link=='styles') {
				return;
			}
			$class=($page==$link)?' class="sel"':'';
			echo "<li$class><a href=\"$link.php\">$title</a></li>\n";
		}
		echo "<div class=\"head_nav\">\n<ul>\n";
		if($level==1) {
			echo "<li>&nbsp;</li>";
		}
		if($level>1) {
			addLink($page,'pages','Pages');
			addLink($page,'uploads','Uploads');
			addLink($page,'styles','Styles');
		} 
		if($level=='3') {
			addLink($page,'titles','Titles');
			addLink($page,'themes','Themes');
			addLink($page,'files','Files');
			addLink($page,'users','Users');
		}
		echo "</ul>\n</div>\n";		
	}
}
$ts_utils = new TS_Utils();
?>
