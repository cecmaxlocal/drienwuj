<?php
// 2010.04.20
header('Content-type: text/html');
define('TS_EDIT',true);
require 'reality_check.php'; 
if( isset( $_POST['content'] ) ) {
	if($tsql->updatePage($_POST['section'], $_POST['page'], $_POST['content'] )) {
		echo "OK";
	} else {
		echo 'WARNING: Typescript was unable to update this page. Please try again.';
	}
}