<?php 
// 2009.08.03
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->access($access==3);
require 'ts_themes.php';
$theme_choice=(isset($_POST['theme_choice']))?$_POST['theme_choice']:'';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Admin: Themes'); ?>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/typescript.js"></script>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
function confirmdel(theme) {
return confirm('Do you really want to delete the "'+theme+'" theme?');
}
function theme_show() {
document.getElementById('option_selector').submit();
}
// ]]>
</script>
</head>
<body id="themes">
<div class="page">
<?php $ts_utils->buildMenu("themes",$access); ?>
<div class="content">
<?php

if(isset($_POST['new_theme'])) {
   $new_theme=$_POST['new_theme'];
   if($tsql->updateTheme($new_theme)) {
		$ts_utils->report("The <b>$new_theme</b> theme has been applied to your site.");
		$config=$tsql->getConfig();
		$theme_choice=$config['theme'];
   }
}

define('CURRENT_THEME',$config['theme']);
$ts_themes = new TS_Themes();
$themes_dir = $ts_themes->themes_dir;

if(isset($_POST['copy_theme'])) {
   $copy_theme=$_POST['copy_theme'];
   $theme_name = strtolower($_POST['theme_name']);
      if(!preg_match("/^[a-z0-9_]+$/", $theme_name)) {
         $ts_utils->report('<b>Error:</b> Illegal characters. You may use A-Z, 0-9 and underscores (_). Spaces are not allowed.');
      } else {
   $ts_themes->copyDirectory("$themes_dir/$copy_theme","$themes_dir/$theme_name");
   $ts_utils->report('The <b>'.$theme_name.'</b> theme was successfully created by copying the '.$copy_theme.' theme.');
	 $theme_choice=$theme_name;
	 }
}

if(isset($_POST['delete_theme'])) {
   $delete_theme=$_POST['delete_theme'];
		if($ts_themes->deleteTheme("$themes_dir/$delete_theme")) {
			$ts_utils->report('The <b>'.$delete_theme.'</b> theme has been deleted.');
		}
}

if($theme_choice) {
 $ts_themes->displayTheme($theme_choice,(CURRENT_THEME==$theme_choice));
 } else {
 $ts_themes->displayCurrentTheme($config['theme']);
}

?>
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body>
</html>
