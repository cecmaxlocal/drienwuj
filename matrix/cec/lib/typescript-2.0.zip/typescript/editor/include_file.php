<?php
// 2009.11.26
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->no_cache();
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Insert a script</title>
  
<link rel="stylesheet" type="text/css" href="ts_styles.css" />

<script type="text/javascript">
// <![CDATA[
function returnSelected() {
	var obj=document.getElementById("textPulldown");
	var idx=obj.selectedIndex;
	var text=obj.options[idx].value;
	if (window.name != 'rawincludes') {
		opener.tse.insertHTML(text);
		} else {
		opener.rawtse.replaceSelection(text);
	}
	window.close();
}
// ]]>
</script>
</head>
<body id="dialog">
<div  style="margin:8px 0 0 11px;">
<span style="font-size:small;">Select a script to include...</span><br />
<select name="textPulldown" id="textPulldown" style="margin-bottom:8px;">
<?php
$d = opendir('./../nucleus/scripts') or die();	
while (false !== ($f = readdir($d))) {
  if (is_file("./../nucleus/scripts/$f")) {
  echo "<option value=\"&lt;ins class='ts_include'&gt;$f&lt;/ins&gt;\">",$f,'</option>';
  echo "\n";
  }
}
closedir($d);
?>
</select><br />
 <input type="button" value=" Insert script  " onclick="returnSelected();" />
</div>
</body></html>