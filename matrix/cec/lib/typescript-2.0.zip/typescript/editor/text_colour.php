<?php
// 2009.10.21
define('TS_EDIT',true);
require "reality_check.php";
$ts_utils->no_cache();
if(TS_PAGESTYLES) { 
	$css = implode('',file('./../pagestyles.css'));
} else {
	$css='';
}
$css_theme = implode('',file('../themes/'.TS_THEME.'/themestyles.css'));
function showUserColours($cssfile)
{
	$cols = Array();
	$regexp = "/((?<!-)color ?:) ?(#([A-F0-9]{3})([A-F0-9]{3})?|[A-Z]{3,})/i";
	preg_match_all($regexp,$cssfile,$matches);
	foreach ($matches[0] as $match)
	{
		if ($match) // make sure match is not false
		{
			// avoid UPPERCASE duplication (f.ex - #FFF + #fff)
			$match = strtolower($match);
			// remove the color: prefix
			$match = preg_replace('/color ?: ?/', '', $match);
			// avoid SHORTHAND duplication (f.ex - #000 + #000000)
			$cols[] = preg_replace('/^#([a-f0-9]){1}(\1){1}([a-f0-9]){1}(\3){1}([a-f0-9]){1}(\5){1}$/', '#$1$3$5', $match);
		}
	}
	// avoid MATCH duplication (several instances of one colour in the css)
	$cols = array_unique($cols);
	// this helps to group colours together. (eyecandy, mostly!)
	asort($cols);
	foreach ($cols as $c)
	{
		echo "<td onclick=\"fnCol(this);\" style=\"background:$c\" title=\"$c\"></td>\n";
		//echo '<p>Match: <span style="color:' . $c . ';">' . $c . "</span></p>\n";
	}
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<title>Select Text Colour</title>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
function fnCol(obj) {
var colour=obj.style.backgroundColor;
	if(window.name != 'rawtextColour' ) {
		opener.tse.execCmd("forecolor",colour);
		} else {
		opener.rawtse.encloseSelection('<span style="color:' + colour + '">','</span>');
	}
window.close();
}
// ]]>
</script>
</head>
<body id="textcol">
<table class="ts_dlg_coltab">
<?php
$colourList = './../nucleus/corefiles/colours.txt';
if(!file_exists($colourList)) {
	die("<span style='color:#fff'>I cannot find the file 'colours.txt'</span></body></html>");
}
$contents=file($colourList);
$n=0;
$rows = array('','','','','','');
foreach ($contents as $x) {
	$colour=explode(';',$x);
	// ignore lines that don't begin with '#'
	if (substr($colour[0],0,1)=="#") {
		$colValue = trim($colour[0]);
		$colName = (trim($colour[1]))?trim($colour[1]):$colValue;
		$rows[$n].='<td onclick="fnCol(this);" style="background:'.$colValue.'" title="'.$colName.'"></td>'."\n";
		$n++;
		if($n==6) $n=0;
	}
}
// finish off table markup if we need empty cells
while($n>0) {
	$rows[$n].="<td></td>";
	$n++;
	if($n==6) $n=0;
}
foreach($rows as $row) {
echo "<tr>$row</tr>\n";
}
?> 
</table>
<hr />
<table class="ts_dlg_coltab"><tr>
<?php 
	// already-used colours
	showUserColours($css_theme);
	showUserColours($css);
?>
</tr></table>
</body>
</html>
