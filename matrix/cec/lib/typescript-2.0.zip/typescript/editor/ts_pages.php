<?php
// 2009.08.05
define('TS_EDIT',true);
require 'reality_check.php';

class TS_Pages {
 
	var $db_handler;

	function renameFolder($old,$name) {
		if($old==$name) {return;}
		return $this->db_handler->renameSection($old,$name);
	}

	function newFolder($name) {
		return $this->db_handler->newSection($name);
	}
	
	function deleteFolder($sect) {
		return $this->db_handler->dropSection($sect);
	}

	function renameFile($sect,$old,$name) {
		$sect=strtolower($sect);
		if($old==$name) {return;}
		return $this->db_handler->renamePage($sect,$old,$name);
	}

	function newFile($sect,$name) {
		$sect=strtolower($sect);
		return $this->db_handler->newPage($sect,$name);
	}

	function deleteFile($sect,$old) {
		$old=strtolower($old);
		$sect=strtolower($sect);
		return $this->db_handler->deletePage($sect,$old);		
	}
	
	function reorder($structure) {
		$count=0;
		foreach($structure as $section=>$pages) {
			$sect_id=$this->db_handler->fetchSectionID($section);
			$this->db_handler->repositionSection($sect_id,$count++);
			foreach($pages as $order=>$page) {
				$this->db_handler->repositionPage($sect_id,$page,$order);
			}
		}
	}
	
	function processRequest($tsql) {

		$this->db_handler=$tsql;
			
		if(isset($_POST['save_structure'])) {
			unset($_POST['save_structure']);

			$action="OK";

		// begin with sections
			foreach($_POST['s'] as $section=>$name) {
				$test=each($name);
				if($test[0]==$test[1]) {
					$sections[$test[1]]=$section;
					continue;
				}
				if(($test[0]=='~new') && ($test[1]=='~deleted')) {
					$action="REFRESH";
					continue;
				}		
				if($test[0]=='~new') {
					if($this->newFolder($test[1])) {
					}
					$sections[$test[1]]=$section;
					continue;
				}
				if($test[1]=='~deleted') {
					$old=strtolower($test[0]);
					if($this->deleteFolder($old)) {
						$action="REFRESH";
					}
					continue;
				}
				if($this->renameFolder($test[0],$test[1])) {
						$action="REFRESH";
					}
					$sections[$test[1]]=$section;
				}
			if(!isset($sections)) {
				// do no more if site is empty
				echo $action;
				return;
			}		
		// then into pages
			foreach($sections as $section=>$id) {
				if(isset($_POST[$id])) {
					foreach($_POST[$id] as $key=>$name) {
						$test=each($name);
						if($test[0]==$test[1]) {
							$pages[$section][]=$test[1];
							continue;
						}
						if(($test[0]=='~new') && ($test[1]=='~deleted')) {
							$action="REFRESH";
							continue;
						}
						if($test[0]=='~new') {
							if($this->newFile($section,$test[1])) {
							}
							$pages[$section][]=$test[1];
							continue;
						}
						if($test[1]=='~deleted') {
							if($this->deleteFile($section,$test[0])) {
							$action="REFRESH";
						}
							continue;
						}
					if($this->renameFile($section,$test[0],$test[1])) {
					}
					$pages[$section][]=$test[1];
					}
				}
				if(!isset($pages[$section])) {
					// section is empty - make a blank page
					if($this->newFile($section,'new page')) {
						$action="PLEASE NOTE:\nA page 'new page' has been created in Section '$section'\nwhich would otherwise contain no pages.";
					}
				$pages[$section][]='new page';
				}
			}		
			$this->reorder($pages);	
			echo $action;	
		}
	}
}
$ts_pages = new TS_Pages;
$ts_pages->processRequest($tsql);
?>