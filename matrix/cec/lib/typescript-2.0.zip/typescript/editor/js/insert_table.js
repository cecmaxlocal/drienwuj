// 2009.11.22
var ts_table={
	columns:2,
	rows:2,
	width:100,
	header:'hdr_none',
	footer:'ftr_none',
	caption:'cptn_none',
	style:'default',
	dummy:false,
	fcheader:false
}
function makeTable() {
	function getVal(id) {
		return document.getElementById(id).value;
	}
	var div=document.getElementById("ts-content");
	div.innerHTML="";
	var th, td, tr, i, j, tf, cptn, contentsNode;
	ts_table.header=getVal("ts_hdr");
	ts_table.rows=getVal("rows");
	ts_table.columns=getVal("columns");
	ts_table.footer=getVal("ts_ftr");
	ts_table.caption=getVal("caption");
	ts_table.style=getVal("tbl_style");
	ts_table.fcheader=(document.getElementById("ts_fchd").checked)?true:false;
	ts_table.dummy=(document.getElementById("ts_dtxt").checked)?true:false;
	var table=document.createElement("table");
	if (getVal('widthUnits')!='none') {
		ts_table.width=getVal("width") + getVal("widthUnits");
		table.setAttribute("width",ts_table.width);
	} else {
		ts_table.width=0;
	}
	if (ts_table.style!="default") {
		table.setAttribute("class",ts_table.style);
	}
	if (ts_table.caption == "cptn_use") {
		cptn=document.createElement("caption");
		contentsNode=document.createTextNode("caption");
		cptn.appendChild(contentsNode);
		table.appendChild(cptn);
	}
	if (ts_table.header == "hdr_single") {
		th=document.createElement("thead");
		td=document.createElement("th");
		contentsNode=document.createTextNode("heading");
		tr=document.createElement("tr");
		th.appendChild(tr);
		td.appendChild(contentsNode);
		td.setAttribute("colSpan",ts_table.columns);
		tr.appendChild(td);
		table.appendChild(th);
	}
	if (ts_table.header == "hdr_cols") {
		th=document.createElement("thead");
		tr=document.createElement("tr");
			for (j=0;j<ts_table.columns;j++) {
				td=document.createElement("th");
				contentsNode=document.createTextNode("heading");
				td.appendChild(contentsNode);
				tr.appendChild(td);
			}
		th.appendChild(tr); 
		table.appendChild(th);
	}
	var tb=document.createElement("tbody");
	for (i=0;i<ts_table.rows;i++) {
		tr=document.createElement("tr");
			for (j=0;j<ts_table.columns;j++) {
				if(j==0 && ts_table.fcheader) {
				td=document.createElement("th");
				contentsNode=document.createTextNode("heading");
				} else {
				td=document.createElement("td");
				contentsNode=document.createTextNode("cell");				
				}
				td.appendChild(contentsNode);
				tr.appendChild(td);
			}  
		tb.appendChild(tr);
		table.appendChild(tb);
	}
	if (ts_table.footer == "ftr_single") {
		tf=document.createElement("tfoot");
		td=document.createElement("td");
		contentsNode=document.createTextNode("footer");
		tr=document.createElement("tr");
		tf.appendChild(tr);
		td.appendChild(contentsNode);
		td.setAttribute("colSpan",ts_table.columns);
		tr.appendChild(td);
		table.appendChild(tf);
	}
	if (ts_table.footer == "ftr_cols") {
		tf=document.createElement("tfoot");
		tr=document.createElement("tr");
			for (j=0;j<ts_table.columns;j++) {
				td=document.createElement("td");
				contentsNode=document.createTextNode("footer");
				td.appendChild(contentsNode);
				tr.appendChild(td);
			}
		tf.appendChild(tr); 
		table.appendChild(tf);
	}
	div.appendChild(table)
}

function handleReturn(e) {
	var key;
	if(window.event) { // IE
		key = e.keyCode;
	}
	else if(e.which) { // Safari/Firefox/Opera...
		key = e.which;
	}
	if(key==13) { 
		makeTable();
		return false;
	}
}

function spinner(objName,interval,minval) {
	oControl=document.getElementById(objName);
	iValue=parseInt(oControl.value);
	iValue+=interval;
	if (iValue>=minval) {
		oControl.value=iValue;
		makeTable();
	}
}

function addTable() {
	window.opener.tse.makeTable(ts_table);
	window.close();
}
