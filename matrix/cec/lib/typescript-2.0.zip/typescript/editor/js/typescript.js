// 2010.05.03
var tsu = {
	zone:'',
	newsflashInterval: 6000, // number of milliseconds to display a 'newsflash' (returned message) 
	saved: true,
	unloadWarning: "YOU HAVE NOT SAVED YOUR WORK.\nChanges will be lost if you refresh or leave this page.",
	hideNewsflash: function(evnt) {
		$('newsflash').hide();
		try {
			evnt.stop();
			} catch(e) {
				// do nothing
		}
	},
	clearField: function(obj) {
		if(obj.value==obj.defaultValue) obj.value="";
	},
	restoreField: function(obj) {
		if (obj.value=="") obj.value = obj.defaultValue;
	},
		go: function(url) {
		location.href=(url);
	},
	userHover: function(obj,x) {
		obj.src=(x)?'icons/ts_userdelete.png':'icons/ts_usericon.png';
	},
	post: function(fname) {  // to save from text editors
		try {
			tse.sendRequest('save',fname,$("file_content").value,tse.handleResponse);
		} catch(e) {
			// do nothing
		}
	},
	interceptTab: function(evnt) { //  used by the plain text editors to insert tabs
		evnt=Event.extend(evnt);
		var target=evnt.element();
		if(evnt.keyCode==Event.KEY_TAB) {
			evnt.stop();
			if(target.setSelectionRange) { // not IE
				var scrollY = target.scrollTop
				var ss=target.selectionStart;
				var se=target.selectionEnd;
					if(ss==se) {
					target.value=target.value.slice(0,ss)+"\t"+target.value.slice(ss,target.value.length);
					target.setSelectionRange(ss+1,ss+1);
					}
				target.scrollTop=scrollY;
			}
		}
		tse.unsetSaved();
	},
	unload: function() {
		if(tsu.saved) {
			return;
		}
		return tsu.unloadWarning;
	},
	initialise: function() {
		tsu.zone=document.body.id;
		if($('newsflash')) {
			setTimeout(tsu.hideNewsflash,tsu.newsflashInterval);
			$('newsflash').observe('click',tsu.hideNewsflash);
		}
		switch(tsu.zone){
			case 'editor':
				tse.initialise();
				break;
			case 'styles':
				if($('savebutton')){
					$('savebutton').observe('click',function(){tsu.post('./pagestyles.css');});
				}
			case 'files':
					$('file_content').observe('keydown',tsu.interceptTab);
				break;
			case 'raw-editor':
				rawtse.initialise();
				break;
			case 'uploads':
				tsup.initialise();
				break;
			case 'pages':
				tsp.initialise();
				break;
			case 'avmedia':
				avm.initialise();
		}
		window.onbeforeunload=tsu.unload;
	}
}

var tse = {
	doc:'', // the editable document
	theme:'',
	bodyClass:'',
	pad:"\u200B", // zero width space
	rePad:'',
	viewSource:false,
	outlineDepth:0,
	showStyles:true,
	httpReqObj:null,
	selElement:null,
	showTag:false,
	badBrowserWarning: "IMPORTANT: This editor will not work with your web browser.\n\n\
	Please choose another browser.", 
	halt:false, // halt if browser incompatabilities
	attachStyleSheet: function(href) {
		var linkNode = tse.doc.createElement("link");
		linkNode.setAttribute("rel","stylesheet");
		linkNode.setAttribute("type","text/css");
		linkNode.setAttribute("href",href);
		tse.doc.getElementsByTagName("head")[0].appendChild(linkNode);	
	},
	writeInitialContent: function() {
				tse.doc.body.className=tse.bodyClass;
				tse.attachStyleSheet("themes/"+tse.theme+"/themestyles.css");
				if ($('pagestyles').value == 'on' ) {
					tse.attachStyleSheet("./pagestyles.css");
				}
				$('savebutton').src='icons/ed_save.png';
				if(!tse.doc.getElementById('ts-content').isContentEditable) {
					try {
						if (typeof(document.isContentEditable) != 'undefined') { // FF 3.6 isContentEditable not implemented 
							tse.doc.designMode="on";  // FF2 + FF3 Beta<=5
						}
						} catch (e) {
						tse.halt=true; 
					}
				}
				tse.doc.body.innerHTML=tse.fetchContent();
				tse.insertHTML(' '); // (ignored) leading space - fix for FF initial BS/Del behaviour
				tsu.saved=true; 
				tse.rePad=new RegExp(tse.pad,'g');
	},
	setContentDoc: function() {
		try {
			if(document.edit_frame.object) {
				tse.doc=edit_frame.object;	// IE
				} else {
				tse.doc=$('edit_frame').contentDocument; // FF - Safari
			}
		} catch(e) {
			try {
				tse.doc=$('edit_frame').contentWindow.document; // Opera
			} catch(e) {
				tse.halt=true;
			}
		}
	},
	fetchContent: function() {
		if(tse.viewSource) {
			var html;
			try {
				if(html=tse.doc.body.innerText) {
					// IE
				return html;
				} else {
				html = tse.doc.body.ownerDocument.createRange();
				html.selectNodeContents(tse.doc.body);
				return html.toString();
				}
			} catch(e) {
			return ''; // = IE and the page is empty.
			}
		}
		return tse.tidyHTML(tse.doc.body.innerHTML);
	},
	getRangeAtSelection: function() {
		var rng=false;
		try {
			if(window.getSelection) {
				rng=window.frames[0].getSelection().getRangeAt(0); // FF Safari
			}
			else if (document.selection) { // IE
				rng=tse.doc.selection.createRange();
			}
		} catch(e) {
			try {
			rng=$('edit_frame').contentWindow.getSelection().getRangeAt(0); // Opera
			} catch(e) {
				// do nothing
			}
		}
		return rng;
	},
	replaceAtSelection: function(obj) {
		try {
			rng.deleteContents();  // this won't work in IE
			rng.insertNode(obj); // nor this
		} catch(e) {
			try { // IE
			tse.insertHTML('<span id="_ie_"></span>');
			var op=tse.doc.getElementById('_ie_')
			op.parentNode.replaceChild(obj,op); // test for this !!!!!!
			} catch(e) {
				// do nothing
			}
		}
	},
	formatBlock: function(tag, cssClass) {
		tag = tag.strip();
		if(cssClass) {
			cssClass = cssClass.strip();
		}
		tse.doc.execCommand('formatBlock', false, '<' + tag + '>');
		var rng = tse.getRangeAtSelection();
		var pn = (rng.startContainer)?rng.startContainer.parentNode:rng.parentElement();
		try {
			while(tag != pn.tagName.toLowerCase()) {
				pn = pn.parentNode;
			}
			if(cssClass) {
				pn.setAttribute('class',cssClass);
				} else {
				pn.removeAttribute('class');
			}
			tse.doc.body.innerHTML += tse.pad; // temporary thin space (Not IE - lets cursor be positioned after the last block)
		} catch(e) {
			// unable to set or clear class attribute - do nothing
		}
	},
	execCmd: function() {
		if (arguments.length == 1) { 
			tse.doc.execCommand(arguments[0],false,null);
		} else {
			tse.doc.execCommand(arguments[0],false,arguments[1]);
		}
		tse.unsetSaved();
	},
	setStyle: function(obj) {
		var index=obj.selectedIndex;
		var command=obj.options[index].value;
		var style="preset";
		if (command.indexOf("span.")!=-1) {
			style="inline";
		} else if (command.indexOf(".")!=-1) {
				style="block";
		}
		if (style=="block") {
			var aCmnd=command.split(".");
			tse.formatBlock(aCmnd[0],aCmnd[1]);
		} else if (style=="inline") {
			command=command.replace(/span\./,"");
			tse.formatBlock('span',command);
		} else {
			if(command=="underline"||command=="strikethrough") {
				tse.execCmd(command);
			} else {
				tse.formatBlock(command,false);
			}
		}
		obj.selectedIndex = 0;
		tse.doc.body.innerHTML=tse.fetchContent();
		tse.unsetSaved();
	},
	showStylesPane: function(obj) {
		var choice=obj.options[obj.selectedIndex].value;
		tse.openWindow('styles_pane.php',choice,860,400,'yes',200,200);
		obj.selectedIndex = 0;
	},
	setImgStyle: function(obj) {
		if(tse.selElement.tagName=='IMG') {
			var iClass=obj.options[obj.selectedIndex].value;
			tse.selElement.className=iClass;
			var rng=tse.getRangeAtSelection();
			if(!rng.collapsed) {
				tse.replaceAtSelection(tse.selElement);
				window.frames[0].getSelection().collapse(tse.doc.body,0);
				tse.doc.execCommand('removeFormat',false,true); // clears the selection outine
			}
		}
		$('imgformat').selectedIndex=0;
	},
	setTools: function(obj) {
		var cmd=obj.options[obj.selectedIndex].value;
		if (cmd == 'cleanPaste') {
			tse.cleanPaste(); 
			}
		else if (cmd == 'outlines') {
			tse.showOutlines();
		}
		else if (cmd == 'hideStyles') {
			tse.toggleStyles();
		}
		else if (cmd == 'showTag') {
			tse.toggleShowTag();
		}		
		else {
			try {
				tse.execCmd(cmd);
				} catch(e) {
				// do nothing
				}
		}
		obj.selectedIndex=0;
	},
	primeTools: function() {
		var s,on={dbl:false,col:'#000'},off={dbl:true,col:'#ccc'};
		$A($('ts_correct').options).each(function(opt){
			s=on;
			switch(opt.value) {
			case'':
			case 'hideStyles':
			case 'showTag':
			break;
			case 'cleanPaste': 
				s=(window.clipboardData)?on:off; // IE only
				break;
			case 'outlines':
				s=(tse.doc.styleSheets)?on:off;
				break;
			default: 
				try {
					s=(tse.doc.queryCommandEnabled(opt.value))?on:off;
				} catch(e) {
					s=off;
				}
			}
			opt.disabled=s.dbl;
			opt.style.color=s.col;
		});
	},
	insertHTML: function(html) {
		html+=tse.pad;
		try {
			tse.execCmd('inserthtml',html);
		} catch(e) {
			var rng=tse.getRangeAtSelection();
			if(rng.pasteHTML) { // IE  only (could this lead to invalid HTML?)
				rng.pasteHTML(html);
			}
		}
	},
	cleanPaste: function() {
		try {
			var text = window.clipboardData.getData("Text");
			tse.insertHTML(text);
			tse.unsetSaved();
		} catch(e) {
			//do nothing (not IE)
		}
	},
	toggleStyles: function() {
		$A(tse.doc.getElementsByTagName('link')).each(function(lnk){lnk.disabled = tse.showStyles;});
		tse.showStyles = !tse.showStyles;
		$('hide-styles').update( (tse.showStyles)?'Remove styling':'Restore styling' );
	},
	toggleShowTag: function() {
		if(tse.showTag) {
			$('sel-element').update('');
		}
		$('show-tag').update( (tse.showTag)?'Show tag on click':'Stop tags on click' );
		$('show-tag').writeAttribute('title', value=(tse.showTag)?'Show tag names on click':'Stop showing tag names on click' )
		tse.showTag = !tse.showTag;
	},
	makeTable: function(tbl) {
		function makeRows(block,rows,cols,text) {
			var td, dummyText;
			var th_txt=(text)?'heading':' ';
			var td_txt=(text)?'cell':' ';
			for (var i=0;i<rows;i++) {
				var tr=tse.doc.createElement("tr");
				for(var j=0;j<cols;j++) {
					if(j==0 && tbl.fcheader) {
						td=tse.doc.createElement("th");
						dummyText=tse.doc.createTextNode(th_txt);
					} else {
						td=tse.doc.createElement("td");
						dummyText=tse.doc.createTextNode(td_txt);						
					}
					if (text) {
						td.appendChild(dummyText);
					}
					tr.appendChild(td);
				}
				block.appendChild(tr);
			}
		}
		function makeHFRow(block,cols,text,type) {
			var el=(type=='ftr_single' || type=='ftr_cols')?'td':'th';
			var cells=(type=='ftr_single' || type=='hdr_single')?1:cols;
			var txt=(el=='td')?'footer':'heading';
			var tr=tse.doc.createElement("tr");
			for(var j=0;j<cells;j++) {
				var td=tse.doc.createElement(el);
				if(cells==1){td.setAttribute("colSpan",cols)};
					if (text) {
						var dummyText=tse.doc.createTextNode(txt);
						td.appendChild(dummyText);
					}
					tr.appendChild(td);
				}
			block.appendChild(tr);	
		}
		var rng,table,tbody,tr,td,tx,txt;
		table=tse.doc.createElement("table");
		if(tbl.caption=="cptn_use") {
			var cptn=tse.doc.createElement("caption");
			if(tbl.dummy) {
				var captionText=tse.doc.createTextNode("caption");
				cptn.appendChild(captionText);
			}
			table.appendChild(cptn);
		}
		if(tbl.width!='0') {
			table.setAttribute("width",tbl.width);
		}
		if(tbl.style!='default') {
			table.setAttribute("class",tbl.style);
		}
		if(tbl.header!="hdr_none") {
			tx=tse.doc.createElement("thead");
			makeHFRow(tx,tbl.columns,tbl.dummy,tbl.header);
			table.appendChild(tx);
		}
		if(tbl.footer!="ftr_none") {
			tx=tse.doc.createElement("tfoot");
			makeHFRow(tx,tbl.columns,tbl.dummy,tbl.footer);
			table.appendChild(tx);
		}
		tbody=tse.doc.createElement("tbody");
		makeRows(tbody,tbl.rows,tbl.columns,tbl.dummy);
		table.appendChild(tbody);
		tse.replaceAtSelection(table);
	},
	textColour: function() {
		tse.openWindow('text_colour.php','textColour',390,170,'yes',200,200);
	},
	insertImage: function() {
		tse.openWindow("insert_image.php","images",550,400,"no",200,200);
	},
	insertLink: function() {
		tse.openWindow("insert_link.php","links",480,130,"no",200,200);
	},
	insertTable: function() {
		tse.openWindow("insert_table.php",'',915,580,100,100);
	},
	insertAVM: function() {
		tse.openWindow("avmedia.php",'',915,580,100,100);
	},
	insertChar: function() {
		tse.openWindow('insert_char.php','characters',290,160,'yes',200,200);
	},
	includeFile: function(pagepath) {
		tse.openWindow("include_file.php?path="+pagepath,"includes",250,100,"no",280,220);
	},
	openWindow: function(url,name,w,h,scroll,x,y) {
		var features="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars="+scroll+",resizable=no,width="+w+",height="+h+",top="+y+",left="+x;
		var win=window.open(url,name,features);
		win.focus();
	},
	preview: function() {
		window.open("preview.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1000,height=600,top=20,left=20");
	},
	help: function() {
		tse.openWindow("helpindex.php","help",720,640,"yes",50,50);
	},
	showTools: function() {
		var toolbox=$("ts_tools");
		toolbox.style.display=(toolbox.style.display=='block')?'none':'block';
	},
	showOutlines: function() {
		var ss=tse.doc.styleSheets[0]; // the <style> tag 
		try {
			switch(tse.outlineDepth) {
				case 0:
				if(ss.insertRule) {
					ss.insertRule("#ts-content > * {outline: 1px dotted blue;}", 0);
					} else {  // IE
					ss.addRule('#ts-content > *', 'outline: 1px dotted blue', 0);
				}
				tse.outlineDepth = 1;
				$('outlines').update('Extended outlines');
				break;
				case 1:
				if(ss.insertRule) {
					ss.insertRule("#ts-content > * * {outline: 1px dotted red;}", 1);
					} else {  // IE
					ss.addRule('#ts-content > * *', 'outline: 1px dotted red', 1);
				}
				tse.outlineDepth = 2;
				$('outlines').update('Remove outlines');
				break;
				default:
				if(ss.deleteRule) {
					ss.deleteRule(0);
					ss.deleteRule(0);
					} else {  // IE
					ss.removeRule(0);
					ss.removeRule(0);
				}
				tse.outlineDepth = 0;
				$('outlines').update('Show outlines');
			}
		} catch(e) {
			// do nothing
		}
	},
	go: function(url) {
		location.href=(url);
	},
	switchView: function() {
		var tn, k, s, wysiwyg_btns="visible";
		var src=tse.fetchContent();
		if(tse.viewSource) {			
			src=tse.tidyHTML(src);
			tse.doc.body.innerHTML=src;
			tse.showStyles = false;
			tse.toggleStyles();
			tse.doc.body.removeAttribute("style");
			$("btn_mode").setAttribute("title","Switch to HTML view");
			tse.viewSource=false;
			$("code_view").style.display='none';
			$('ts_correct').style.visibility='visible';
		} else {
			// Firefox 3: text nodes created in one document cannot be placed into another
			src = src.replace(tse.rePad, '');
			tn = tse.doc.createTextNode(src);
			tse.doc.body.innerHTML='';
			tse.doc.body.appendChild(tn);
			src = tse.doc.body.innerHTML;
			// highlight tags
			s = /(&lt;\/?\w+((\s+\w+(\s*=\s*(?:".*?"|'.*?'|[^'">\s]+))?)+\s*|\s*)\/?&gt;)/g;
			src = src.replace(s,'<span style="color:#058;font-style:italic">$1</span>');			
			// display common block elements on a new line
			k = /(&lt;(?:\/?(?:form|textarea|table|tbody|tfoot|thead|blockquote|ol|ul|dl)|label|input|tr|caption|h[1-6]|p|div|br|hr|li|dt|dd))/g;
			tse.doc.body.innerHTML=src.replace(k,'<br />$1');
			tse.showStyles = true;
			tse.toggleStyles();
			tse.doc.body.setAttribute("style","font-family:monospace;font-size:13px;line-height:1.4;font-weight:normal;");
			$("btn_mode").setAttribute("title","Switch to normal view");
			tse.viewSource=true;
			wysiwyg_btns="hidden";
			$("code_view").style.display='inline';
			$('ts_correct').style.visibility='hidden';
			$('sel-element').innerHTML='';
		}
		$("buttonblock").style.visibility=wysiwyg_btns;
	},
	getReqObj: function() {
		return (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
	},
	sendRequest: function(command,fname,content,response) {
		tse.httpReqObj=tse.getReqObj(); 
		$("savebutton").src="icons/ed_saving.gif";		
		tse.httpReqObj.onreadystatechange = response;
		tse.httpReqObj.open("POST","post_request.php");
		tse.httpReqObj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		tse.httpReqObj.send("command="+command+"&fname="+fname+"&content="+encodeURIComponent(content));
	},
	handleResponse: function() {
		if(tse.httpReqObj.readyState == 4) {
			if(tse.httpReqObj.responseText == "OK") {
			$("savebutton").src="icons/ed_save.png";
			$("saved_status").innerHTML="";
			tsu.saved=true;
			} else {
			alert(tse.httpReqObj.responseText);
			}
		}
	},
	setBtnHandlers: function() { 
		$('btn_mode').observe('click',tse.switchView);
		$('savebutton').observe('click',tse.save);
		$('format').observe('change',function(){tse.setStyle(this);});
		$('imgformat').observe('change',function(){tse.setImgStyle(this);});
		$('btn_bold').observe('click',function(){tse.execCmd('bold');});
		$('btn_italic').observe('click',function(){tse.execCmd('italic');});
		$('btn_ljust').observe('click',function(){tse.execCmd('justifyleft');});
		$('btn_cjust').observe('click',function(){tse.execCmd('justifycenter');});
		$('btn_rjust').observe('click',function(){tse.execCmd('justifyright');});
		$('btn_hr').observe('click',function(){tse.execCmd('inserthorizontalrule');});
		$('btn_ul').observe('click',function(){tse.execCmd('insertunorderedlist');});
		$('btn_ol').observe('click',function(){tse.execCmd('insertorderedlist');});
		$('btn_tcol').observe('click',tse.textColour); 
		$('btn_img').observe('click',tse.insertImage);
		$('btn_link').observe('click',tse.insertLink);
		$('btn_table').observe('click',tse.insertTable);
		$('btn_char').observe('click',tse.insertChar);
		$('btn_indent').observe('click',function() {tse.execCmd('indent');});
		$('btn_outdent').observe('click',function() {tse.execCmd('outdent');});
		$('btn_tools').observe('click',tse.showTools);
		$('btn_sub').observe('click',function(){tse.execCmd('subscript');});
		var pagepath=$("pagemarker").firstChild.innerHTML;
		$('btn_inc').observe('click',function(){tse.includeFile(pagepath);});
		$('btn_sup').observe('click',function(){tse.execCmd('superscript');});
		$('btn_prev').observe('click',tse.preview);
		$('ts_correct').observe('change',function(){tse.setTools(this);});
		$('ts_styles_pane').observe('change',function(){tse.showStylesPane(this);});
		$('btn_avm').observe('click',tse.insertAVM);
		tse.primeTools();
	},
	save: function() {
		var content=tse.fetchContent();
		fname=$('section').value+"|"+$('page').value;
		// remove '\' before escaped quotes
		content=content.replace("\\\"","\"");
		content=content.replace("\\'","'");
		// remove question mark from any xml tags - else problem with pastes from Word etc. **** THIS NEEDS SORTING TO REMOVE ALL TAGS FROM PASTES ******
		content=content.replace("<?xml","<xml");
		// clear out pad characters
		content=content.replace(tse.rePad, '');
		tse.sendRequest('update',fname,content,tse.handleResponse);
	},
	unsetSaved: function(event) {
		tsu.saved=false;
		$("saved_status").innerHTML=" *";
		if ( $("sel-element") ) {
			$("sel-element").innerHTML="";
		}
	},
	tidyHTML: function(html) { 
		// tidy up just some of the quirky html inserted by various browsers (NOT correct  user added mistakes!)
		html=html.replace(/<(?:.|\s)*?>/g, function(m){ // looking only at tags...
			m=m.replace(/\s{2,}/g, ' '); // clear multiple spaces
			m=m.replace(/<\s/g, '<'); // remove any space between start of tags and tag name
			m=m.replace(/\s>/g, '>'); // remove space at end of tag name
			m=m.replace(/class="Apple-style-span" /g,''); // clear Safari/Chrome 'Apple-style-spans' 
			m=m.replace(/<(\/ *)?(\w+)/g, function(m){return m.toLowerCase()}); // lowercase tag names
			m=m.replace(/^<(br|hr|img|input|param|area|col)([^>]*[^\/]|\s?)>$/g,'<$1$2 />'); // fix unclosed empty elements 
			//if(m.substr(1,5) == 'param'){return m;}
			//m=m.replace(/(\s[^\s]+)\s?=\s?([^\s'">]+)/g, '$1="$2"'); // add missing quotes to attribute values
			return m.replace(/(\w+)=["']/g, function(m){return m.toLowerCase()}); // lowercase attribute names
		});
		// replace font tags inserted by Safari and IE simply to colour text
		html=html.replace(/<font color="?(#\w{6})"?>([\s\S]+?)<\/font>/g, '<span style="color:$1">$2</span>');
		// remove all other font tags (usually inserted by Safari)
		html=html.replace(/<font[\s\S]*?>([\s\S]+?)<\/font>/g, '$1');
		// clear out unwanted leading break tags inserted by FF
		html=html.replace(/^ *<br \/>/,'');
		// clear out all leading white space
		html=html.replace(/^\s+/m,'');
		// add zero width text node to allow positioning of cursor after last block
		return html + tse.pad;
	},
	querySelection:function(event) {
		if(!tse.viewSource) {
			tse.selElement=event.element();
			var cl=event.element().className;
			var el=event.element().tagName.toLowerCase();
			var slctd = (el=='img')?{img:'inline',text:'none'}:{img:'none',text:'inline'};
			slctd = (cl=='ts-avmedia')?{img:'none',text:'none'}:slctd;
			$('imgformat').style.display=slctd.img;
			$('format').style.display=slctd.text;
			tse.primeTools();
			if(tse.showTag) {
				var pel=tse.selElement.parentNode.tagName.toLowerCase();
				var pcl=(pel=='body' || pel=='html')?'':tse.selElement.parentNode.className;
				cl=(cl && el!='body')?'.'+cl:'';
				pcl=(pcl)?'.'+pcl:'';
				$('sel-element').innerHTML=(!el || el=='HTML')?'':'['+pel+pcl+' &gt; '+el.toLowerCase()+cl+']';
			}
		}
	},
	initialise: function() {
			tse.setContentDoc();
			if(tse.halt) {
				alert(tse.badBrowserWarning);
				return;
			}
			tse.setBtnHandlers();
			tse.theme=$F('theme');
			tse.bodyClass=$F('body_class');
			if(!tse.doc.getElementById('ts-content')) {
				setTimeout(window.location.reload(),500);
				} else {
				tse.writeInitialContent();
			}
			Event.observe(tse.doc,'keydown',tse.unsetSaved);
			Event.observe(tse.doc,'mousedown',tse.querySelection);				
		$('saved_status').innerHTML="";
	}
}

var rawtse = {
	slctn: {},	
	page: null,	
	savedPage: '',		
	undoOn: false,	
	initialise: function() {
		rawtse.setHandlers();
		rawtse.page = $('edit_frame');
		Event.observe(rawtse.page,'keyup',function(){
			rawtse.querySaved();
			rawtse.setUndo(false);
		});
		rawtse.savedPage = rawtse.page.value;
	},	
	setHandlers: function() {
		$('btn_prev').observe('click',rawtse.preview);
		$('savebutton').observe('click',rawtse.save);
		$('format').observe('change',function(){rawtse.setStyle(this);});
		$('btn_undo').observe('click',rawtse.undo);
		$('btn_bold').observe('click',function(){rawtse.insertTag('strong');});
		$('btn_italic').observe('click',function(){rawtse.insertTag('em');});
		$('btn_tcol').observe('click',rawtse.textColour);
		$('btn_sub').observe('click',function(){rawtse.insertTag('sub');});
		$('btn_sup').observe('click',function(){rawtse.insertTag('sup');});
		$('btn_hr').observe('click',function(){rawtse.replaceSelection('<hr />');});
		$('btn_ul').observe('click',function(){rawtse.makeList('ul');});
		$('btn_ol').observe('click',function(){rawtse.makeList('ol');});
		$('btn_link').observe('click',rawtse.insertLink);
		$('btn_char').observe('click',rawtse.insertChar);
		$('btn_inc').observe('click',rawtse.includeScript);
		$('btn_img').observe('click',rawtse.insertImage);
		$('btn_tools').observe('click',rawtse.showStylesPane);
		$('btn_avm').observe('click',rawtse.insertAVM);
	},	
	setSaved: function(cnd) {
		tsu.saved = cnd;
		$("saved_status").innerHTML = cnd?'':' *';
	},	
	querySaved: function() {
		rawtse.setSaved(rawtse.savedPage == rawtse.page.value);
	},	
	preview: function() {
		window.open("raw_preview.php","",
	"toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1000,height=600,top=20,left=20");
	},	
	save: function() {
		$("savebutton").src="icons/ed_saving.gif";	
		var params = {};
		params.section = $('section').value;
		params.page = $('page').value;
		params.content = rawtse.page.value;
		new Ajax.Request('post_request2.php', {
			parameters: params,
			onSuccess: function(transport) {
				if( transport.responseText != 'OK' ) {
				alert ( transport.responseText );
				};
				$("savebutton").src="icons/ed_save.png";
				rawtse.savedPage = params.content;
				rawtse.setSaved(true);
			}
		});
	},	
	splitOnSelection: function() {
		rawtse.page.focus();
		if(!document.selection) {
			var startPos = rawtse.page.selectionStart;
			var endPos = rawtse.page.selectionEnd;
			rawtse.slctn.start = rawtse.page.value.substring(0,startPos); 
			rawtse.slctn.middle = rawtse.page.value.substring(startPos, endPos);
			rawtse.slctn.end = rawtse.page.value.substring(endPos);
		} else { // IE
			var slcn = document.selection.createRange();
			rawtse.slctn.middle = slcn.text;
			slcn.text = "\u200B";
			var prts = rawtse.page.value.split("\u200B");
			rawtse.slctn.start = prts[0]?prts[0]:'';
			rawtse.slctn.end = prts[1]?prts[1]:'';
		}
	},	
	selectedText: function() {
		rawtse.page.focus();
		if(!document.selection) {
			return rawtse.page.value.substring(rawtse.page.selectionStart, rawtse.page.selectionEnd);
		} else { // IE
			return document.selection.createRange().text;
		}
	},	
	setCaretPosition: function(caretPos) {
        if(rawtse.page.createTextRange) {
            var range = rawtse.page.createTextRange();
            range.move('character', caretPos);
            range.select();
        } else {
            if(rawtse.page.selectionStart) {
                rawtse.page.focus();
                rawtse.page.setSelectionRange(caretPos, caretPos);
            }
        }
	},	
	replaceSelection: function(text) {
		var scrollPos = rawtse.page.scrollTop;
		rawtse.splitOnSelection();
		rawtse.page.value = rawtse.slctn.start + text + rawtse.slctn.end;
		rawtse.page.scrollTop = scrollPos;
		rawtse.querySaved();
		rawtse.setUndo(true);
		rawtse.setCaretPosition( (rawtse.slctn.start + text).length );
	},	
	encloseSelection: function(start, end) {
		var scrollPos = rawtse.page.scrollTop;
   		rawtse.splitOnSelection();
		rawtse.page.value = rawtse.slctn.start + start + rawtse.slctn.middle + end + rawtse.slctn.end;
		rawtse.page.scrollTop = scrollPos;
		rawtse.querySaved();
		rawtse.setUndo(true);
		rawtse.setCaretPosition( rawtse.page.value.length - rawtse.slctn.end.length );
	},	
	setUndo: function(cnd) {
		if(rawtse.undoOn != cnd) {
			$('btn_undo').src = cnd?'icons/ed_undo.png':'icons/ed_undo_off.png';
			$('btn_undo').title = cnd?'Undo the last action':'Undo not available';
		}
		rawtse.undoOn = cnd;
	},	
	undo:function() {
		if(rawtse.undoOn) {
			var scrollPos = rawtse.page.scrollTop;
			rawtse.page.value = rawtse.slctn.start + rawtse.slctn.middle + rawtse.slctn.end;
			rawtse.page.scrollTop = scrollPos;			
			rawtse.setUndo(false);
			rawtse.querySaved();
			rawtse.setCaretPosition( rawtse.slctn.start.length );
		}
	},	
	insertTag: function(tag) {
		rawtse.encloseSelection('<' + tag + '>' , '</' + tag + '>');
	},	
	textColour: function() {
		tse.openWindow('text_colour.php','rawtextColour',390,170,'yes',200,200);
	},	
	insertChar: function() {
		tse.openWindow('insert_char.php','rawcharacters',290,160,'yes',200,200);
	},	
	insertLink: function() {
		tse.openWindow("insert_link.php","rawlinks",480,130,"no",200,200);
	},	
	includeScript: function() {
		tse.openWindow("include_file.php","rawincludes",250,100,"no",280,220);
	},	
	insertImage: function() {
		tse.openWindow("insert_image.php","rawimages",550,400,"no",200,200);
	},	
	showStylesPane: function() {
		tse.openWindow('styles_pane.php','',860,400,'yes',200,200);
	},	
	insertAVM: function() {
		tse.openWindow("avmedia.php",'rawinsertAVM',915,580,100,100);
	},	
	makeList: function(tag) {
		var html = '<' + tag + '>\n';
		var list = new Array();
		list = rawtse.selectedText().split('\n');
		html += '<li>' + list.join('</li>\n<li>') + '</li>\n</' + tag + '>';
		rawtse.replaceSelection(html);
	},	
	setStyle: function(obj) {
		var tag = obj.value.split('.',2);
		if(tag[1]) {
			rawtse.encloseSelection('<'+tag[0]+' class="'+tag[1]+'">','</'+tag[0]+'>');
		} else {
			rawtse.insertTag(tag[0]);
		}
		obj.selectedIndex = 0;
	}			
}

var tsup = {

  confirmDelete: function(e) {
    if (!confirm("Are you sure you want to delete the selected file(s)?")) {
	  e.stop();
	};	
  },  
  initialise: function() {
    $('fdel').observe('submit',tsup.confirmDelete);
	$$('img.file').invoke('observe','click',tsup.selectFile);
    $$('input[type=checkbox]').each(function(obj) { 
      obj.checked='';
      obj.style.display='none';
	});  
    tsup.hideInputs();
    tsup.showInput(1);
	$$('div.delfolder').invoke('observe','click',function(evnt) {
	  var n=Event.element(evnt).readAttribute('value');
	  $('del'+n).submit();
	});
	$$('input.ip').invoke('observe','mouseover',function() {
	  tsup.hoverEye(1);
	});
	$$('input.ip').invoke('observe','mouseout',function() {
	  tsup.hoverEye(0);
	});
	$$('input.ip').invoke('observe','change',tsup.incQueue);
    $('newfolder').observe('click',function() {
	  if(this.value==this.defaultValue) this.value="";  
	});
    $('newfolder').observe('blur',function() {
	  if(this.value=='') this.value=this.defaultValue;  
	});
    $$('img.root, img.folder').invoke('observe','click',tsup.toggle); 
	$('new-folder').observe('click',tsup.showCreateFolderForm);
  },  
  selectFile: function() {
    if(this.src.indexOf('file.png') > -1) {
      this.src=this.src.replace('file.png','file_del.png');
      this.nextSibling.checked='checked';
      $('delfiles').style.visibility='visible';
    } else {
      this.src=this.src.replace('file_del.png','file.png');
      this.nextSibling.checked='';
    }
  },  
  hideInputs: function() {
    $$('input[type=file]').each(function(obj) {
	  obj.style.visibility='hidden';
	 });
  },  
  showInput: function(n) {
    try {
	  $('id'+n).style.visibility='visible';
	} catch(e) {
	  // do nothing
	}
  },  
  hoverEye: function(x) {
    var col=(x==1)?'black':'gray';
    var img=(x==1)?'browse_hover.png':'browse.png';
    $('dummy').style.color=col;
    $('dummy').firstChild.src='icons/'+img;
  },  
  showQueue: function(ext) {
    if((ext=='.gif')||(ext=='.jpg')||(ext=='.png')) {
    $('imgfldrs').style.display='inline';
    }
    $('qwrapper').style.visibility='visible';
  }, 
  incQueue: function(evnt) {
    var obj=Event.element(evnt);
    var n=Number(obj.name.replace('f',''));
    var fn=obj.value
    tsup.hideInputs()
    $('queue').innerHTML+='<li>'+fn+'</li>';
    tsup.showInput(n+1);
    tsup.showQueue(fn.substring(fn.lastIndexOf('.')));
  },  
  toggle: function() {
    var id='collapse'+this.readAttribute('value');
    var imgsrc=this.src;
    $(id).style.display = ($(id).style.display=="block") ? "none" : "block";
    imgsrc = (imgsrc.indexOf("open") >-1) ? imgsrc.replace("openfolder","folder") : imgsrc.replace("folder","openfolder");
    this.src=imgsrc;
    $('createimgfolder').style.display='none';
  },  
  showCreateFolderForm: function() {
    if($('createimgfolder').style.display=='block') {
      $('createimgfolder').style.display='none';
    } else {
      var top=0;
	  var obj=this;
      if (obj.offsetParent) {
        top=obj.offsetTop;
          while(obj=obj.offsetParent) {
            top+=obj.offsetTop
          }
      }
      top=top+2;
      $('createimgfolder').style.left='65px';
      $('createimgfolder').style.top=top+'px';
      $('createimgfolder').style.display='block';
    }
  }
}

var tsp = {
	_selectedPage:null,
	_selectedPageName:'',
	_selectedSection:null,
	_selectedSectionName:'',
	_visiblePageList:'',
	_pageHeight:'',
	_menuChars:20,
	_empty:false,
	_errorLog:new Array(),
	_warnings: [	'The new name is too long and will be truncated.\n[Maximum length: \'%\' characters]\n',
					'Invalid characters will be replaced by underscores.\n[Permitted: letters, digits, space and underscore]\n',
					'Multiple spaces will be reduced to a single space\n',
					'WARNING!\n You are about to delete the page\n\'%\'',
					'WARNING!\nSection: \'%\'\nYOU ARE ABOUT TO DELETE THIS SECTION\nAND EVERY PAGE WITHIN IT.',
					'ERROR\nThis would duplicate section number %.\nPlease choose another name.',
					'ERROR\nThis would duplicate page number % in this section.\nPlease choose another name.'],
	initialise: function() {
		if($('no_delete')) {tsp._empty=true;}
		tsp.makeSortable('sections');
		$('save_structure').disable();
		$('sect_panel','page_panel').invoke('hide');
		$$('li.plist').invoke('observe','click', tsp.selectPage);
		$$('li.slist').invoke('observe','click', tsp.selectSection);
		$('edit_page').observe('click', tsp.editPage);
		$('edit-page-alt').observe('click', tsp.editPageAlt);
		$('rename_page').observe('click', tsp.renamePage);
		$('delete_page').observe('click', tsp.deletePage);
		$('restore_page').observe('click', tsp.restorePage);
		$('new_page').observe('click', tsp.makeNewPage);
		$('rename_section').observe('click', tsp.renameSection);
		$('delete_section').observe('click', tsp.deleteSection);
		$('restore_section').observe('click', tsp.restoreSection);
		$('new_section').observe('click', tsp.makeNewSection);
		$('tsp_frm').observe('submit', tsp.processForm);
		tsp._menuChars=$F('maxchars');
		tsp.resizeContent();
	},
	showList:function() {
		var id=$(tsp._visiblePageList);
		$$('ul.pagelist').invoke('hide');
		if(tsp._selectedSectionName!='~deleted') {
			tsp.resizeContent();
			id.down('h4').update('Pages in "'+tsp._selectedSectionName+'"');
			id.setStyle({display: 'block', zIndex: 1000});
			tsp.makeSortable(id);
		}
	},
	resizeContent: function() {
		var pgy,sty;
		pgy=(tsp._visiblePageList=='')?0:$(tsp._visiblePageList).getHeight();
		sty=$('sections').getHeight();
		pgy=(pgy>sty)?pgy:sty;
		pgy=(pgy>500)?(50+pgy):550;
		tsp._pageHeight=(80+pgy)+'px';
		$$('div.content').invoke('setStyle',{height:pgy+'px'});
	},
	setUnsaved: function() {
		$('save_structure').enable();
		$('edit_page').disable();
		tsu.saved=false;
	},
	makeSortable: function(list) {
		Sortable.create(list, { tag: 'li', only: ['plist','slist'], onChange: function() {tsp.setUnsaved();}});
	},
	clearPageSelection: function() {
		try {
			tsp._selectedPage.setStyle({color: 'black'});
		} catch(e) {
			// do nothing
		}
	},
	clearSectionSelection: function() {
		try {
			tsp._selectedSection.setStyle({color: 'black'});
		} catch(e) {
			// do nothing
		}	
	},
	selectPage: function() {
		tsp.clearPageSelection();
		tsp._selectedPage=this;
		tsp._selectedPageName=this.down().readAttribute('value');
		this.setStyle({color: '#e36d3f'});
		tsp.showPagePanel();
	},
	selectSection: function() {
		tsp.clearPageSelection();
		tsp.clearSectionSelection();
		tsp._selectedSection=this;
		tsp._selectedSectionName=this.down().getValue();
		this.setStyle({color: '#e36d3f'});	
		tsp.showSectionPanel();
		tsp.hidePanel('page_panel');
		var sectid=this.down().getAttribute('name');
		tsp._visiblePageList=sectid.match(/^s\[(s\d+)\]\[.+\]/).last();
		tsp.showList();
	},
	showPagePanel: function() {
		$('page_name').update('<img src="icons/file.png" alt="page" />Page: <em>'+tsp._selectedPageName+'</em>');
		if(tsp._selectedPageName=='~deleted') {
			$('delete_page').hide();
			$('rename_page').hide();
			$('restore_page').show();
		} else {
			$('delete_page').show();
			$('rename_page').show();
			$('restore_page').hide();		
		}
		$('page_panel').appear();
	},
	showSectionPanel: function() {
		$('sect_name').update('<img src="icons/folder.png" alt="section" />Section: <em>'+tsp._selectedSectionName+'</em>');
		if(tsp._selectedSectionName=='~deleted') {
			$('delete_section').hide();
			$('rename_section').hide();
			$('new_page').hide();
			$('restore_section').show();
		} else {
			$('delete_section').show();
			$('rename_section').show();
			$('new_page').show();
			$('restore_section').hide();
		}
		$('sect_panel').appear();
	},
	hidePanel: function(id) {
		$(id).fade();
	},
	editPage: function() {
		var qstr=$H({ section: tsp._selectedSectionName, page: tsp._selectedPageName}).toQueryString();
		qstr=qstr.toLowerCase();
		document.location.href='editor.php?'+qstr;
	},
	editPageAlt: function() {
		var qstr=$H({ editor: 'alt', section: tsp._selectedSectionName, page: tsp._selectedPageName}).toQueryString();
		qstr=qstr.toLowerCase();
		document.location.href='editor.php?'+qstr;
	},
	renamePage: function() {
		var action=prompt('Rename the page \''+tsp._selectedPageName+'\'', tsp._selectedPageName);
		action=tsp.validate(action);
		if(tsp.findDuplicatedPage(action)) {
			return;
		}
		if(action) {
			tsp._selectedPage.down().setValue(action);
			tsp._selectedPage.down().next(1).update(action);
			tsp.setUnsaved();
			tsp._selectedPageName=action;
			tsp.showPagePanel();
		}
	},
	deletePage: function() {
		var action=confirm(tsp._warnings[3].sub('%',tsp._selectedPageName));
		if(action) {
			tsp._selectedPage.down().setValue('~deleted');
			tsp._selectedPageName='~deleted';
			tsp._selectedPage.down().next(1).setStyle({textDecoration:'line-through'});
			tsp.setUnsaved();
			tsp.showPagePanel();
		}
	},
	restorePage: function() {
		var nom=tsp._selectedPage.down().next(1).innerHTML;
		if(tsp.findDuplicatedPage(nom)) {
			return;
		}
		tsp._selectedPage.down().next(1).setStyle({textDecoration:'none'});
		tsp._selectedPage.down().setValue(nom);
		tsp._selectedPageName=nom;
		tsp.showPagePanel();
	},
	makeNewPage: function() {
		var action=prompt('Make a new page in the \''+tsp._selectedSectionName+'\' section','page name');
		action=tsp.validate(action);
		if(tsp.findDuplicatedPage(action)) {
			return;
		}
		if(action) {
			var sectid=tsp._selectedSection.down().getAttribute('name');
			sectid=sectid.match(/^s\[(s\d+)\]\[.+\]/).last();
			$(sectid).insert('<li class="plist"><input type="hidden" name="'+sectid+'[][~new]" value="'+action+'" /><img src="icons/file.png" class="folder" alt="Drag to reorder"  title="Drag to reorder" /><span>'+action+'</span></li>');
			tsp.makeSortable(sectid);
			$(sectid).childElements().last().observe('click', tsp.selectPage);
			tsp.setUnsaved();
			tsp.resizeContent();
		}
	},
	renameSection: function() {
		var action=prompt('Rename the section \''+tsp._selectedSectionName+'\'', tsp._selectedSectionName);
		action=tsp.validate(action);
		if(tsp.findDuplicatedSection(action)) {
			return;
		}
		if(action) {
			tsp._selectedSection.down().setValue(action);
			tsp._selectedSection.down().next(1).update(action);
			tsp.setUnsaved();
			tsp._selectedSectionName=action;
			tsp.showSectionPanel();
			tsp.showList();
		}
	},
	deleteSection: function() {
		var action=confirm(tsp._warnings[4].sub('%',tsp._selectedSectionName));
		if(action) {
			tsp._selectedSection.down().setValue('~deleted');
			tsp._selectedSectionName='~deleted';
			tsp._selectedSection.down().next(1).setStyle({textDecoration:'line-through'});
			tsp.setUnsaved();
			tsp.showSectionPanel();
			tsp.showList();
		}
	},
	restoreSection: function() {
		var nom=tsp._selectedSection.down().next(1).innerHTML;
		if(tsp.findDuplicatedSection(nom)) {
			return;
		}
		tsp._selectedSection.down().next(1).setStyle({textDecoration:'none'});
		tsp._selectedSection.down().setValue(nom);
		tsp._selectedSectionName=nom;
		tsp.showSectionPanel();
		tsp.showList();
	},
	makeNewSection: function() {
		var action=prompt('Make a new section','section name');	
		action=tsp.validate(action);
		if(tsp.findDuplicatedSection(action)) {
			return;
		}
		if(action) {
			var sectid=$('sections').childElements().last().down().getAttribute('name');
			if(sectid == null) {
				$('sections').insert('<li class="slist"><input type="hidden" name="s[s1][~new]" value="'+action+'" /><img src="icons/folder.png" class="folder" alt="Click to open this section"  title="Click to open this section" /><span>'+action+'</span></li>');
				$$('div.content form').first().insert('<ul class="pagelist" id="s1"><li><h4>'+action+' pages</h4></li></ul>');
				$('sections').childElements().last().observe('click', tsp.selectSection);
				tsp.setUnsaved();
				return;
			} else {
			sectid=sectid.match(/^s\[s(\d+)\]\[.+\]/).last();
			sectid="s"+(1+parseInt(sectid));
			$('sections').insert('<li class="slist"><input type="hidden" name="s['+sectid+'][~new]" value="'+action+'" /><img src="icons/folder.png" class="folder" alt="Click to open this section"  title="Click to open this section" /><span>'+action+'</span></li>');
			$$('div.content form').first().insert('<ul class="pagelist" id="'+sectid+'"><li><h4>'+action+' pages</h4></li></ul>');
			tsp.makeSortable($('sections'));
			$('sections').childElements().last().observe('click', tsp.selectSection);
			tsp.setUnsaved();
			tsp.resizeContent();
			}
		}
	},
	validate: function(value) {
		value=value.strip();
		var test=value.replace(/\s{2,}/g, ' ');
		if(test!=value) {
			value=test;
			tsp._errorLog.push(2);			
		}
		if(value.length>tsp._menuChars) {
			tsp._errorLog.push(0);
			value=value.truncate(tsp._menuChars, '_');
		}
		test=value.replace(/[^A-Za-z0-9_ ]/g, '_');
		if(test!=value) {
			value=test;
			tsp._errorLog.push(1);			
		}
		if(tsp._errorLog.length>0) {value=tsp.listErrors(value);}
		return value;
	},
	listErrors: function(value) {
		var msg='WARNING:\n';
		while(tsp._errorLog.length>0) {
			msg+='\n'+tsp._warnings[tsp._errorLog.pop()].sub('%',tsp._menuChars);
		}
		msg+='\nRESULT: \''+value+'\'\n';
		var action=confirm(msg);
		if(!action) return false;
		return value;
	},
	findDuplicates: function(els,nom,warning) {
		nom=nom.toLowerCase();
		var names=els.inject([], function(arr, el) {
			arr.push(el.down().getValue().toLowerCase());
			return arr;
		});
		var dup=1+names.indexOf(nom);
		if(dup>0) {
			alert(tsp._warnings[warning].sub('%',dup));
			return true;
			}
		return false;	
	},
	findDuplicatedSection: function(nom) {
		return tsp.findDuplicates($$('li.slist'),nom,5);
	},
	findDuplicatedPage: function(nom) {
		return tsp.findDuplicates($(tsp._visiblePageList).select('li.plist'),nom,6);
	},
	processForm: function(e) {
		e.stop();
		$('tsp_frm').request({onComplete: function(transport){
				var rsp=transport.responseText;
				if(rsp=="OK") {
					$('save_structure').disable();
					$('edit_page').enable();
					tsu.saved=true;
				} else if(rsp=="REFRESH"){
					$('save_structure').disable();
					$('edit_page').enable();
					tsu.saved=true;
					window.location.reload();
				} else {
					alert(rsp);
					window.location.reload();
				}
			}
		});
	}
}

var avm={
	file:null,
	mediaType:'flv',
	offsetX:0,
	offsetY:0,
	startImg:null,
	startWidth:300,
	startHeight:240,
	initialise: function() {
		avm.file=$('mediaFile').value;
		if ($('media-type').value == 'flv') {
			avm.initialiseFLV();
			} else {
			avm.mediaType='mp3';
		}
		avm.getStartImage();
	},
	initialiseFLV:function() {
		$('unrestricted').hide();
		new Draggable('grabRight', {constraint:'horizontal', snap:function(x,y) {
				x=(x<100)?100:x;
				$('grabBottom').setStyle({width:x+'px'});
				$('grabCorner').setStyle({left:x+'px'});
				return[x,y];
			},
			onDrag:avm.resize,
			onEnd:avm.clearPresetValue
		});
		new Draggable('grabBottom', {constraint:'vertical', snap:function(x,y) {
				y=(y<100)?100:y;
				$('grabRight').setStyle({height:y+'px'});
				$('grabCorner').setStyle({top:y+'px'});
				return[x,y];
			},
			onDrag:avm.resize,
			onEnd:avm.clearPresetValue
		});
		new Draggable('grabCorner', {snap:function(x,y) {
				x=(x<100)?100:x;
				y=(y<100)?100:y
				$('grabRight').setStyle({height:y+'px',left:x+'px'});
				$('grabBottom').setStyle({width:x+'px',top:y+'px'});
				return[x,y];
			},
			onDrag:avm.resize,
			onEnd:avm.clearPresetValue
		});	
	},
	getStartImage: function() {
		if(opener.tsu.zone == 'raw-editor') {
			return;
		};
		var selctn=opener.tse.getRangeAtSelection(), selObj;
		try {
			selObj=selctn.cloneContents().firstChild; // FF and Opera
			} catch(e) {
			selObj=selctn.item(0); // IE
		}
		if(selObj && selObj.tagName=='IMG') {
			try {
			avm.startImg=selObj.src;
			var y=selObj.height;
			var x=selObj.width;
			if(avm.mediaType=='flv') {
				avm.setSize(x,y);
			}
			avm.startImg.replace(/([^\/]+)?$/, function(m){$('startimg').update('Start image: '+m+' ('+x+' x '+y+' px)');});
			//avm.clearPresetValue();
			avm.startWidth=x;
			avm.startHeight=y;
			avm.useStartImageSize();
			} catch(e) {
				// do nothing
			}
		}
	},
	resize: function() {
		$('placeholder').setStyle({width:$('grabRight').getStyle('left'),height:$('grabBottom').getStyle('top')});
		$('width').innerHTML=$('grabRight').getStyle('left');
		var height=parseInt($('grabBottom').getStyle('top'))-avm.offsetY;
		$('height').innerHTML=height+'px';
	},
	presetSize: function() {
		var sz=$('presetSize').value;
		if(sz=='none') {
			avm.resize();
			$('unrestricted').show();
		} else if(sz=='startimage') {
			avm.useStartImageSize();
		} else {
		sz=sz.split(':');
		avm.setSize(sz[0],sz[1]);
		$('unrestricted').hide();
		}
	},
	setSize: function(x,y) {
		var height=(avm.offsetY+parseInt(y)+'px'), width=avm.offsetX+parseInt(x)+'px';
		$('placeholder').setStyle({width:width,height:height});
		$('grabRight').setStyle({left:width,height:height});
		$('grabBottom').setStyle({top:height,width:width});
		$('grabCorner').setStyle({top:height,left:width});
	},
	clearPresetValue: function() {
		$('presetSize').options[0].selected=true;
		avm.presetSize();
	},
	useStartImageSize: function() {
		avm.setSize(avm.startWidth,avm.startHeight);
		$('unrestricted').hide();
		$('presetSize').options[1].selected=true;
	},
	setFile: function() {
		avm.file=$('mediaFile').value;
		var startimage=(avm.startImg)?'&startimage='+avm.startImg:'';
		window.location = '?file='+avm.file+startimage;
	},
	addMedia: function() {
		var width = $('placeholder').getWidth();
		var height = $('placeholder').getHeight();
		var src=(avm.startImg && (avm.mediaType!=='mp3'))?avm.startImg:'avmedia/'+avm.mediaType+'_blank.png';
		var avo = '<img src="'+src+'" class="ts-avmedia" title="'+avm.file+'" alt="'+avm.file+'" width="'+width+'" height="'+height+'" />';
		if(window.name != 'rawinsertAVM') { 
			window.opener.tse.insertHTML(avo);
		} else {
			window.opener.rawtse.replaceSelection(avo);
		}
		window.close();
	}
}

Event.observe(window,'load',tsu.initialise);