<?php
// 2009.08.03
define('TS_EDIT',true);
require 'reality_check.php';
$ts_utils->no_cache();
$ts_utils->access($access>1);
$sections=array();
$readOnly=(TS_DBTYPE == 'sqlite') && !is_writable('../nucleus/typescript.sqlite');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="robots" content="noindex,nofollow" />
	<meta name="author" content="Ray Middleton" />
	<link rel="shortcut icon" href="icons/ts_icon.ico"/>
	<link rel="icon" type="image/png" href="icons/ts_icon.png" />
	<?php $ts_utils->writeHTMLTitle('Page Management'); ?>
	<link rel="stylesheet" type="text/css" href="ts_styles.css" />
	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/effects.js"></script>
	<script type="text/javascript" src="js/dragdrop.js"></script>
	<script type="text/javascript" src="js/typescript.js"></script>
</head>
<body id="pages">
<div class="page">
<?php $ts_utils->buildMenu("pages",$access); ?>
<div class="content">
<h4><?php echo ($readOnly)?'<span style="color:red">WARNING</span>: The database is "read only". You will not be able to make any changes.':'Page Management'; ?></h4>
<form id="tsp_frm" action="ts_pages.php" method="post">
<?php
$menuChars = (defined('TS_MENUCHARS') && TS_MENUCHARS > 15 && TS_MENUCHARS < 129)?floor(TS_MENUCHARS):20;
echo '<input type="hidden" id="maxchars" name="maxchars" value="' . $menuChars . '" />' . "\n";
function ffield($keys,$val) {
return sprintf('<input type="hidden" name="%s" value="%s" />',$keys,$val);
}
$s_img='<img src="icons/folder.png" height="24" width="24" class="folder" alt="Click to open this section"  title="Click to open this section" />';
$p_img='<img src="icons/file.png" height="16" width="16" class="folder" alt="Click to select"  title="Click to select" />';
if(!isset($structure)) {$structure=$tsql->getStructure();}
if(is_array($structure)){
foreach($structure as $section => $pages) {
	$sections[]=$section;
	$id="s".count($sections);
		printf('<ul class="pagelist" id="%s"><li>%s<h4>%s pages</h4></li>%s',$id,"\n",$section,"\n");
	foreach($pages as $page) {
		echo '<li class="plist">'.ffield($id."[][$page]",$page)."$p_img<span title=\"Drag to move\">$page</span></li>\n";
	}
		echo "</ul>\n";
}
echo "<ul id=\"sections\">\n<li><h4>Sections</h4></li>\n";
$count=0;
foreach($sections as $section) {
	$count++;
	echo "<li class=\"slist\">".ffield("s[s$count][$section]","$section")."$s_img<span title=\"Drag to move\">$section</span></li>\n";
}
echo "</ul>\n";
}
if(count($structure)<2) {
echo '<input type="hidden" id="no_delete" value="" />';
}
?>
<div id="save_panel" <?php echo ($readOnly)?'style="display:none"':''; ?>>
<input type="submit" id="save_structure" name="save_structure" value="Save changes" />
</div>
</form>
<div id="newsect_panel">
<h4><img src="icons/folder.png" alt="folder" />Make a new section</h4>
<input type="button" id="new_section" value="New Section" title="Make a new section" />
</div>
<div id="sect_panel">
	<h4 id="sect_name"> </h4>
	<input type="button" id="rename_section" value="Rename" title="Rename this section" />
	<input type="button" id="delete_section" value="Delete" title="Remove this section" />
	<input type="button" id="restore_section" value="Restore" title="Restore this section" />
	<input type="button" id="new_page" value="New page" title="Make a new page in this section" />
</div>
<div id="page_panel">
	<h4 id="page_name"> </h4>
	<input type="button" id="edit_page" value="Edit" title="Edit this page" />
	<input type="button" id="rename_page" value="Rename" title="Rename this page" />
	<input type="button" id="delete_page" value="Delete" title="Remove this page" />
	<input type="button" id="restore_page" value="Restore" title="Restore this page" />
	<input style="visibility:hidden" type="button" accesskey="e" id="edit-page-alt" />
</div>
</div>

<?php include("./footer.inc.php"); ?>
</div>
</body>
</html>
