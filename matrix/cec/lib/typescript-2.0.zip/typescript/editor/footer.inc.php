<?php 
if(!defined('TS_EDIT')) {
	include('index.php');
	exit;
}
?>
<div id="ts_footer">&middot; <a href="../index.php">View Site</a> &middot; <a href="http://www.typescript.org">typescript.org</a> &middot; <a href="../index.php?ts_logout">Log Out</a> &middot;</div>