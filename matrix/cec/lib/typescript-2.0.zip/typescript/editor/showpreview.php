<?php
// 2009.08.03
define('TS_EDIT',true);
require 'reality_check.php';
function pageURL() {
$host  = $_SERVER['HTTP_HOST'];
$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
return "http://$host$uri/";
}
// remove '\' before escaped quotes
$content = str_replace("\\\"","\"",$_POST['buffer']);
$bc = $_POST['body_class'];
$content = str_replace("\\'","'",$content);
// remove question mark from any xml tags - else problem with pastes from Word etc.
$content = str_replace("<?xml","<xml",$content);

if($tsql->preparePreview($content)) {
	$dir = dirname(pageURL());
	header("Location:$dir/index.php?section=ts_preview&page=$bc");
}
?>