<?php
// 2010.07.09
define('TS_EDIT',true);
require "reality_check.php";
$ts_utils->no_cache();
$css = implode('',file('./../pagestyles.css'));
$css.= implode('',file('../themes/'.TS_THEME.'/themestyles.css'));
$uploadFile='';
if(isset($_FILES['file'])) {
  $uploadFile = basename($_FILES['file']['name']);
  $uploadPath = './../images/';
  $uploadStatus = $_FILES['file']['error'];
  @move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath.$uploadFile);
  sleep(1); // ensures the uploading message is visible for at least a second
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Insert an image</title>
<?php echo '<link rel="stylesheet" type="text/css" href="../themes/'.TS_THEME.'/themestyles.css" />' . "\n";
if(TS_PAGESTYLES) {
  echo '<link rel="stylesheet" type="text/css" href="../pagestyles.css" />' . "\n";
}
?>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />

<script type="text/javascript">
// <![CDATA[
var tsi = {
	style:'none',
	image:'',
	title:'',
	getValues:function() {
			tsi.image=tsi.getValue("selimg");
			tsi.style=tsi.getValue("istyle");
			tsi.title=document.getElementById("title").value;
	},
	getValue:function(id) {
		var obj=document.getElementById(id);
		var index=obj.selectedIndex;
		return obj.options[index].value;		
	},
	changeFolder:function() {
		var folder=document.getElementById("folder").value;
		location.replace("insert_image.php?fldr="+folder);
	},
	suggestTitle:function(path) {
		return path.substring(path.lastIndexOf('/')+1,path.lastIndexOf('.'));
	},
	upload:function(field) {
		if(!/(\.png|\.gif|\.jpg|\.jpeg)$/i.test(field.value)) {
			alert("Error: This is not a valid file.\nImages must be 'png', 'jpg' or 'gif'.");
			return;
		}
		document.getElementById('dyngraphic').innerHTML = '<p><img style="vertical-align:middle" src="icons/ed_saving.gif" /> Please wait while your image is uploaded</p>';
		document.getElementById('imgform').submit(); 
	},
	showGraphic:function(status) {
		tsi.getValues();
		if(status>0) {
			if(status<3) {
				alert("Warning: Cannot uploaded this image\n because it exceeds the maximum file size of 100kB.");
				} else {
				alert("Error: File transfer problem.\nUnable to upload your image.");
			}
		}
		try {
			if(tsi.style.indexOf('cp-') == 0) {
				document.getElementById("dyngraphic").innerHTML = '<div class="'+tsi.style+'"><img '+tsi.image+' /><p>'+tsi.title+'</p></div>';
				} else {
				document.getElementById("dyngraphic").innerHTML = '<img '+tsi.image+' class="'+tsi.style+'" />';
			}						
		} catch(e) {
			// an empty image folder - disable the submit button
			document.getElementById('submit').disabled=true;
		}
	},
	submit:function() {
		var image=tsi.image;
		var iclass=tsi.style;
		image=image.replace("./../","");
		var title=document.getElementById("title").value;
		if(iclass.indexOf('cp-') == 0) {  // cp- modifier generates an image with a caption
			image='<div class="'+iclass+'"><img '+image+' class="'+iclass+'" alt="'+title+'" title="'+title+'" /><p>'+title+'</p></div>';
			} else {
			iclass=(iclass=='none')?'':' class="'+iclass+'"';
			image='<img '+image+iclass+' alt="'+title+'" title="'+title+'" />';
		}
		if(window.name != 'rawimages') {
			opener.tse.insertHTML(image);
		} else {
			opener.rawtse.replaceSelection(image);
		}
		window.close();
	},
	imgNew:function(x) {
		var disp=(x)?{old:'none',nu:'block'}:{old:'block',nu:'none'};
		document.getElementById('img_old').style.display=disp.old;
		document.getElementById('img_new').style.display=disp.nu;
	}
}
// ]]>
</script>
</head>
<body onload="tsi.showGraphic(<?php echo($uploadFile)?$uploadStatus:0; ?>)" id="insimage">
<div>
<div id="img_old">
<div class="img_nav">
<ul>
<li class="sel"><a href="#">Use an existing image</a></li>
<li><a href="#" onclick="tsi.imgNew(true);">Upload an image from my computer</a></li>
</ul>
</div>
<?php
$fldr="";
if(isset($_REQUEST['fldr'])) $fldr=$_REQUEST['fldr'];
$imgdir="./../images";
// all image folders
$folders[]="";
$d = opendir($imgdir) or die($e_noimg);
    while (false !== ($f = readdir($d))) 
        if (($f<>".") and ($f<>"..")) 
		{
                $fn = $imgdir."/".$f;
                 if (is_dir($fn)) {
                 $folders[]=$f;
                 }
                }
closedir($d);
if($fldr) $imgdir.="/".$fldr;
// folders drop down menu
if(count($folders)>1) {
print "<select name=\"folder\" id=\"folder\" style=\"width:120px;\" onchange=\"tsi.changeFolder()\" title=\"Select an image folder\">\n";
print "<option value=\"\">default folder</option>\n";
foreach($folders as $option) {
  if($option) {
   $sltd="";
   if ($option==$fldr) $sltd="selected=\"selected\"";
   print "<option value=\"$option\" $sltd>$option</option>\n";
   }
}
print "</select> &nbsp; \n";
}
print '<select name="selimg" id="selimg" style="width:200px;" onchange="tsi.showGraphic(0)" title="Choose an image">' . "\n";
// all files in requested folder
$d = opendir($imgdir) or die($e_noimg);
    while (false !== ($f = readdir($d))) 
        if (is_file("$imgdir/$f")) 
		{
                $fn = $imgdir."/".$f;
                $selected=($f==$uploadFile)?'selected="selected"':'';
                list($width,$height,$type,$attr) = getimagesize($fn);
                print "<option value=\"width='$width' height='$height' src='$fn'\" $selected>$f</option>\n";
                }
closedir($d)
?>
</select>
</div>
<div id="img_new">
<div class="img_nav">
<ul>
<li><a href="#" onclick="tsi.imgNew(false);">Use an existing image</a></li>
<li class="sel"><a href="#">Upload an image from my computer</a></li>
</ul>
</div>
<form id="imgform" method="post" enctype="multipart/form-data" action="">
	<div>
		<input type="hidden" name="MAX_FILE_SIZE" value="102400" />
		<input name="file" id="file" size="27" type="file" onchange="tsi.upload(this)" title="Choose an image from my computer" />
	</div>
</form>
</div>
<input type="button" id="submit" value="Insert this image" onclick="tsi.submit()" />
<label for="title">alt/title:</label>
<input type="text" size="20" id="title" value="" onkeyup="tsi.showGraphic()" title="Give the image a title" />
<label for="istyle">style:</label>
<select name="istyle" id="istyle" onchange="tsi.showGraphic(0)" style="width:120px;" title="Select a style for the image">
<option value="none" selected="selected">None</option>
<?php
preg_match_all("/(^|\n)img\.[-_\w]+/",$css,$matches);
for ($i=0,$j=count($matches[0]);$i<$j;$i++) {
print "<option value=\"".substr($matches[0][$i],5)."\">".$matches[0][$i]."</option>\n";
} 
?>
</select>
<hr />
</div>
<div id="dyngraphic"></div>
</body>
</html>