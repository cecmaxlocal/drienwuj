<?php
// 2009.08.03
header('Content-type: text/html');
define('TS_EDIT',true);
require 'reality_check.php'; 
if(isset($_POST['command'])) {
	if($_POST['command']=='save') {
		// *raw*urldecode preserves "+" characters
		if($ts_utils->writeContents('../'.$_POST['fname'],rawurldecode($_POST['content']))) {
			echo "OK";
		} else{
			echo "WARNING: Typescript was unable to save the file. Please try again.";
		}	
	} elseif($_POST['command']=='fetch') {
		readfile('../'.$_POST['fname']);
	} elseif($_POST['command']=='update') {
		$target=explode("|",$_POST['fname']);
		if($tsql->updatePage($target[0],$target[1],$_POST['content'])) {
			echo "OK";
		} else {
			echo 'WARNING: Typescript was unable to update this page. Please try again.';
		}
	}
}
