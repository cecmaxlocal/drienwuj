<?php 
// 2010.03.08
if(stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) {
	include 'index.php';
	exit;
}

class TS_TEMPLATE {
	public $structure;
	public $navigation;
	protected $location;
	protected $search;
	protected $db_handler;
	public function __construct($tsql) {
		if(!headers_sent() && isset($_REQUEST['ts_logout'])){
			session_start();
			session_destroy();
		}
		$this->db_handler=$tsql;
		// theme, title and header
		$config=$tsql->getConfig();
		define("TS_HEADER",$config['header']);
		define("TS_FOOTER",$config['footer']);
		define("TS_THEME",$config['theme']);
		define("TS_THEMEPATH","themes/{$config['theme']}/");
		define("TS_SITETITLE",$config['title']);
		
		// site structure (all sections and pages)
		$this->structure=$tsql->getStructure();
		// if the site has no pages
		if(count($this->structure) === 0) {
			define("TS_EMPTY", true);
			return;
		}
		// menu structure (only primary sections and pages)
		$this->navigation=$this->_filter_menu($this->structure);
		// get section and page if in query string
		$section=(isset($_GET['section']))?$_GET['section']:'';
		$page=(isset($_GET['page']))?$_GET['page']:'';
		// if not in query string read 'tidy' URL
		if(!($page && $section)) {
			$target=$this->_decodeURL();
			$section=$target['section'];
			$page=$target['page'];
		}
		$section=strtolower($section);
		$page=strtolower($page);

		// set the location (original case)
		$this->_setLocation($section,$page);	
		define("TS_SECTION", $this->location['section']);
		define("TS_PAGE", $this->location['page']);
		
		$this->search=(isset($_GET['find']))?preg_replace('/[^\w \"\']/i', '', trim($_GET['find'])):'';

		if ($section == '') {
			$title = $config['title'];
		} else {
			$page_title = ($section == $page) ? TS_SECTION : TS_SECTION . ' - ' . TS_PAGE;
			$title = ($section!="ts_preview") ? "{$config['title']} - $page_title" : "PAGE PREVIEW: {$config['title']}";
		}
		if ($section!="ts_preview") {
			if(!$tsql->pageExists($section,$page)) {
				$index=$tsql->getIndexPage();
				$page=$index['page'];
				$section=$index['section'];				
			}
			$body_class='tp-'.str_replace(" ","-",$page).' ts-'.str_replace(" ","-",$section);
			} else {
				$body_class=$page;
				$page=preg_replace('/^(tp-)([-\w]+?) (ts-)([-\w]+?)$/', '$2', $page);
			}
		$page = basename($page);
		define("TS_LCSECTION",strtolower($section));
		define("TS_LCPAGE",strtolower($page));
		define("TS_TITLE",$title);
		define("TS_BODYCLASS",strtolower($body_class));
		define("TS_BASE",$this->_baseURL());
		define("TS_PAGEREF",$_SERVER['REQUEST_URI']);
		define("TS_EMPTY", false);
	}
	private function _decodeURL() {
		$path = explode('/',$_SERVER['REQUEST_URI']);
		$page = array_pop($path);
		$page = ($page)?$page:array_pop($path);
		$section = str_replace('-',' ',array_pop($path));
		$page = str_replace('-',' ',$page);
		return array('section' => rawurldecode($section), 'page' => rawurldecode($page));
	}
	private function _baseURL() {
		$base = str_replace('\\','','http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['SCRIPT_NAME']));
		return (substr($base,-1) == '/')?$base:$base.'/';
	}
	private function _setLocation($section,$page) {
		$this->location = array();
		$section = $this->_inArray(array_keys($this->structure),$section);
		if($section && $page) {
			$this->location['section'] = $section;
		} else { 
			$this->location=$this->db_handler->getIndexPage();
			return;
		}
		$page = $this->_inArray($this->structure[$section],$page);
		if($page) {
			$this->location['page'] = $page;		
		} else {
			$this->location=$this->db_handler->getIndexPage();
		}
	}
	private function _inArray($arr,$val) {
		$arr = array_change_key_case(array_combine($arr, $arr));
		$val = (array_key_exists($val, $arr))?$arr[$val]:'';
		return $val;
	}
	public function link_stylesheet($stylesheet,$media='all',$theme=true) {
		$href=($theme)?TS_THEMEPATH.$stylesheet:$stylesheet;
		if (file_exists($href)) {
		echo "<link rel=\"stylesheet\" href=\"$href\" type=\"text/css\" media=\"$media\" />\n";
		}
	}
	private function _filter_menu($menu) {
		$st = array();
		if(!function_exists('filter')) {
			function filter($s) {
				return ($s{0}<>'_');
			}
		}
		foreach($menu as $sect => $pages) {
			$pages=array_filter($pages,'filter');
			if((filter($sect))&&(count($pages))) $st[$sect]=array_values($pages);
		}
		return $st;
	}
	private function _search() {
		function frag_start($fragment) {
			if(strlen($fragment)>50) {
				$start=substr("$fragment",0,50);
				$pos = strrpos($start, " ");
			return ' '.substr("$fragment",0,$pos);
		}
			return $fragment;
		}
		function frag_end($fragment) {
			if(strlen($fragment)>50) {
				$end=substr("$fragment",-50);
				$pos=strpos($end, " ");
			return ' ... '.substr($end,$pos);
			}
			return $fragment;
		}
		echo "<div id=\"ts-search-results\">Search Results:\n";
		$input=$this->search;
		preg_match_all('/"(.[^"]+)"|([\w]+)/i', $input, $terms);
		$terms=array_unique($terms[0]);  // scrub duplicate search terms
		$found=$this->db_handler->find($terms);
		$i=0;
		foreach($terms as $term) {
			echo "<span class=\"ts-highlight",++$i,"\">$term</span> ";
		}
		if(is_array($found)) {
			$html= "<ul>";
				foreach($found as $section=>$pages) {
				if($section && ($section[0] != '_')) {
					$html.= "\n <li>$section\n  <ul>";
					foreach ($pages as $page=>$content) {
						$x=explode('<',$content);
						$html.="\n   <li><a href=\"index.php?section=$section&page=$page\">$page</a>\n    <ul>\n     <li>";
						if(count($x)>1) {
							$highlight=false;
							// first fragment
							$html.=frag_end(array_shift($x));
							// last fragment
							$last_frag=frag_start(array_pop($x));
							// inner fragments
							foreach($x as $fragment) {
								$highlight=!$highlight;
									if(strlen($fragment)>100) {
										$fragment=frag_start($fragment).frag_end($fragment);
									}
								$html.=($highlight)?"<span class='ts-highlight$fragment</span>":$fragment;
							}
							$html.="$last_frag ... ";
						} else {
							$html.="Your search is relevant to this page, but not included in the text.";
						}
					$html.="\n     </li>\n    </ul>\n   </li>";
					}						
				$html .="\n  </ul>\n </li>\n";
				}
				}
			echo "$html\n</ul>\n";
		} else {
			echo "<div>No results found.</div>";
		}
		echo "</div>\n";
	}
	private function _embedSWF($elmnt) {
		$found = preg_match_all('#([^\s=]+)\s*=\s*(\'[^<\']*\'|"[^<"]*"|[^\s<\'"]*)#', $elmnt, $matches, PREG_SET_ORDER);
		if($found) {
			foreach ($matches as $val) { 
				$atts[$val[1]]=$val[2];
			}
			$title = 'resources/' . trim($atts['title'], "'\"");
			$mtype = strtolower(substr($title, -3));
			$ftype = ($mtype=='mp4')?'flv':$mtype;
			if($ftype == 'mp3') {
				$player = '"avmedia/player_mp3_maxi.swf"';
				} elseif($ftype == 'flv') {
				$player = '"avmedia/player_flv_maxi.swf"';
				} else {
				return false;
			}
			$simg = trim($atts['src'], "'\"");
			$fv = $ftype . '=' . TS_BASE . $title;
			$fv .= ($ftype=='flv')?'&amp;startimage='.$simg:'';
			$fv .= '&amp;config=avmedia/' . $ftype . '_config.txt';
			$style = (isset($atts['style']))?' style=' . $atts['style']:' ';
			$style .= (isset($atts['width']))?' width=' . $atts['width']:'';
			$style .= (isset($atts['height']))?' height=' . $atts['height']:'';
			$ie = (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE ') !== FALSE);
			$webkit = (strpos($_SERVER['HTTP_USER_AGENT'], 'WebKit') !== FALSE);
			$vidtag = ($mtype=='mp4') && $webkit;
			$audtag = ($mtype=='mp3') && $webkit;
			$embed = "\n" . '<div class="ts-avmedia">' . "\n";
			if($ie) {
				$embed .= '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"' . $style . ' >';
				$embed .= "\n".'<param name="movie" value=' . $player . ' />';
				} else {
				$embed .= '<object type="application/x-shockwave-flash" data=' . $player . $style . ' >';
			}
			$embed .= "\n".'<param name="flashvars" value="' . $fv . '" />';
			if($vidtag) {
				$embed .= "\n".'<video' . $style .' controls="controls">';
				$embed .= "\n".'<source src="' . TS_BASE . $title .'" type="video/mp4" />'."\n</video>";
			} else if($audtag) {
				$embed .= "\n".'<audio' . $style . ' src="' . TS_BASE . $title .'" controls="controls"></audio>';			
			}
			if( !($vidtag || $audtag) ) {
				$embed .= "\n<img src=\"$simg\" alt=\"Unable to play\" title=\"Unable to play this media file\" /><div>Unable to play {$atts['title']}: " . '<a href="' . TS_BASE . $title . '" title="' . $title .'">Download</a></div>'; 
			}
			$embed .= "\n</object>\n</div>";
		return $embed;
		} else {
			return false;
		}
	}
	private function _buildContent($section, $page) {
		$content=$this->db_handler->getContent($section, $page);
		if(strpos($content, 'ts-avmedia')) {
			if(preg_match_all('#<img[^>]+class="?ts-avmedia"?[^>]*>#', $content, $matches)) {
				foreach ($matches[0] as $el) {
					if($embed = $this->_embedSWF($el)) {
						$content = str_replace($el, $embed, $content);
					}
				}
			}
		}
		if(strpos($content, 'ts_include') === false) {
			echo $content;
			} else {
			$content=preg_replace('/<ins class=[\'"]?ts_include[\'"]?> *([-\w\.]+?) *<\/ins>/', '<?php include "./nucleus/scripts/$1"; ?>', $content);
			eval(" global \$template; ?>$content<?php ");
			}
	}
	public function content() {
		echo "<div id=\"ts-content\">\n";
		if($this->search) {
			$this->_search();
		} else {
			$this->_buildContent(TS_LCSECTION,TS_LCPAGE);
		echo "\n</div>\n";
		}
	}
	public function insert($section,$page) {
		if($this->db_handler->pageExists($section,$page)) {
			$this->_buildContent($section,$page);
		}
	}
	public function editLink($html='') {
		@session_start();
		$permit=(isset($_SESSION['access']))?1:0;
		if(TS_LCSECTION=="ts_preview")$permit=0;
		if ((!isset($_GET['ts_logout'])) and ($permit==1)) { 
			if(!$html) {
			echo "\n<ul id=\"ts-editlinks\">"; 
			if($_SESSION['access'] > 1) echo "\n <li><a href=\"editor/pages.php\">Admin</a></li>";
			echo "\n <li><a href=\"editor/editor.php?section=".TS_LCSECTION."&amp;page=".TS_LCPAGE."\">Edit this page</a></li>";
			echo "\n <li><a href=\"index.php?ts_logout\">Log Out</a></li>\n</ul>";
			echo "\n <a href=\"editor/editor.php?editor=alt&amp;section=".TS_LCSECTION."&amp;page=".TS_LCPAGE."\" accesskey=\"e\"></a>\n";
			} else {
			echo $html;
			}
		}
	}
	public function searchForm($buttonText="Search") {
		echo '<form action="index.php" method="get">';
		echo "\n".'<input type="text" name="find" value="" />';
		echo "\n".'<input type="hidden" name="section" value="'.TS_LCSECTION.'" />';
		echo "\n".'<input type="hidden" name="page" value="'.TS_LCPAGE.'" />';
		echo "\n<input type=\"submit\" value=\"$buttonText\" />";
		echo "\n</form>";
	}
	public function header() {
		echo stripslashes(str_replace("&#039;","'",TS_HEADER));
	}
	public function footer() {
		echo stripslashes(str_replace("&#039;","'",TS_FOOTER));
	}
	public function menu($ts_menu=1, $ts_opt1='<', $ts_opt2='>') {
		if(!function_exists('addSubmenuItem')) {
			function toQueryString($section,$page) {
				if(TS_TIDYURL) {
				return strtolower(str_replace(" ","-",$section))."/".strtolower(str_replace(" ","-",$page));
				} else {
				return "section=".strtolower(str_replace(" ","+",$section))."&amp;page=".strtolower(str_replace(" ","+",$page));
				}
			}
			function addSubmenuItem($page,$key,$section) {
				$ps=(($page==TS_PAGE)&&($section==TS_SECTION))?' class="ts-current"':'';
				echo " <li$ps>".addMenuItem($section,$page,$page)."</li>\n";
			}
			function addMenuItem($section,$page,$body,$title=false) {
				$title=($title)?' title="'. $page .'"':'';
				if(TS_TIDYURL) {
				return "<a$title href=\"".TS_BASE.toQueryString($section,$page)."\">$body</a>";
				} else {
				return "<a$title href=\"index.php?".toQueryString($section,$page)."\">$body</a>";
				}
			}
		}
		if(is_array($this->structure)) {
			if(is_string($ts_menu)) {
				// produce breadcrumbs using $ts_menu as the separator
				echo '<ul class="ts-crumbs">' . "\n";
				$ts_menu = htmlspecialchars($ts_menu);
				$home_section = key($this->structure);
				$home_page = $this->structure[$home_section][0];
				$first_page = $this->structure[TS_SECTION][0];
				echo '<li>' . addMenuItem($home_section,$home_page,$home_section) . "</li>\n";
				if($home_section != TS_SECTION) {
					echo '<li>' . $ts_menu . ' ';
					echo addMenuItem(TS_SECTION,$first_page,TS_SECTION) . "</li>\n";
				}
				echo '<li>' . $ts_menu . ' ';
				echo TS_PAGE . "</li>\n</ul>\n";
			} else {

		echo ($ts_menu<5)?"<ul class=\"ts-menu\">\n":"\n";
		
				switch($ts_menu) {

				case(0):
					// sections only
					foreach($this->navigation as $sect => $pages) {
						$crnt=(TS_SECTION==$sect)?' class="ts-current"':'';
						echo "<li$crnt>".addMenuItem($sect,$pages[0],$sect)."</li>\n";
					}
				break;
				
				case(1):
					// sections and all pages
					foreach($this->navigation as $sect=>$pages) {
						$crnt=(TS_SECTION==$sect)?' class="ts-current"':'';
						echo "<li$crnt>".addMenuItem($sect,$pages[0],$sect);
						echo "\n <ul>\n";
						array_walk($pages,'addSubmenuItem',$sect);          
						echo " </ul>\n</li>\n";					
					}
				break;
			
				case(2):
					// sections and all pages unless only there is only one page in the section 
					foreach($this->navigation as $sect=>$pages) {
						$crnt=(TS_SECTION==$sect)?' class="ts-current"':'';
						echo "<li$crnt>".addMenuItem($sect,$pages[0],$sect);
						if(count($pages)>1) {
							echo "\n <ul>\n";
							array_walk($pages,'addSubmenuItem',$sect);          
							echo " </ul>\n</li>\n";
						} else {
							echo "</li>\n";
						}
					}
				break;
			
				case(3):
					// all pages but sections are not links
					foreach($this->navigation as $sect=>$pages) {
						$crnt=(TS_SECTION==$sect)?' class="ts-current"':'';
						echo "<li$crnt>$sect";
						echo "\n <ul>\n";
						array_walk($pages,'addSubmenuItem',$sect);          
						echo " </ul>\n</li>\n";					
					}			
				break;
			
				case(4):
					// pages only
					if($pages = $this->navigation[TS_SECTION]) {
						array_walk($pages,'addSubmenuItem',TS_SECTION); 
					}
				break;
			
				case(5):
					// pages without the first page
					if($pages = $this->navigation[TS_SECTION]) {
						if(count($pages)>1) {
							echo "<ul>\n";
							unset($pages[0]);
							array_walk($pages,'addSubmenuItem',TS_SECTION);
							echo "</ul>\n";
						}
					}					
				break;
			
				case(6): 
				case(7):
					// pagination
					if($p = $this->structure[TS_SECTION]) {
						$ts_opt1 = htmlspecialchars($ts_opt1);
						$ts_opt2 = htmlspecialchars($ts_opt2);						
						$nn = count($p);
						$nc = array_search(TS_PAGE, $p);
						$pagination='';
						$start = ($nc!=0)?addMenuItem(TS_SECTION, $p[$nc-1], $ts_opt1, true):$ts_opt1;
						$start = '<li class="ts-previous">' . $start . "</li>\n";
						if($ts_menu==6) {
							for($n=0; $n<$nn; $n++) {
								$ps=($p[$n]==TS_PAGE)?' class="ts-current"':'';
								$pagination .= "<li$ps>" . addMenuItem(TS_SECTION, $p[$n], $n+1, true) . "</li>\n";
							}
						}
						$end = ($nc==($nn-1))?$ts_opt2:addMenuItem(TS_SECTION, $p[$nc+1], $ts_opt2, true);
						$end = '<li class="ts-next">' . $end . "</li>\n";
						if($nn>1) {
							echo '<ul class="ts-pagination">' ."\n" . $start, $pagination, $end . "</ul>\n";
						}
					}
				}
				
		echo ($ts_menu<5)?"</ul>\n":"\n";
			
			}
		}
	}
	public function importPage($section="_imports") {
			if(TS_SECTION == $section) {
				return true;
			}
			$page="";
		if($this->db_handler->pageExists($section,TS_LCPAGE)) {
			$page=TS_LCPAGE;
		} elseif($this->db_handler->pageExists($section,TS_LCSECTION)) {
			$page=TS_LCSECTION;
		} elseif($this->db_handler->pageExists($section,"default")) {
			$page="default";	
		}
		if($page) {
			$this->insert($section,$page);
		}
	}
}
$template=new TS_TEMPLATE($tsql);