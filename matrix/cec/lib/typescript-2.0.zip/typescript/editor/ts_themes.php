<?php
// 2009,11,10

class TS_Themes
{
   var $themes_dir="../themes";
   
   function readThemes()
   {
      $theme_dir=$this->themes_dir;
      $d = @opendir($theme_dir);
      while (false !== ($f = readdir($d))) 
      {
         if (($f<>".") and ($f<>"..") and (is_dir("$theme_dir/$f"))) $themes[]=$f;
      }
      closedir($d);
      asort($themes);
      return $themes;
   }

   function copyDirectory($src, $dest)
   { 
      $ignore = array('.', '..' ); 
      $dh = @opendir($src);     
         if (!file_exists($dest)) {
            mkdir($dest);
         }	    
      while(false !== ($file = readdir($dh)))
      { 
         if( !in_array($file, $ignore)) {              
            if( is_dir("$src/$file")) { 
               $this->copyDirectory("$src/$file","$dest/$file"); 
         } else { 
               copy("$src/$file","$dest/$file");
         }          
         } 
      }      
      closedir($dh); 
   }

   function deleteTheme($theme_dir) 
   {
			if (is_dir($theme_dir)) {
      $ignore = array('.', '..', 'images' );
      $td = "$theme_dir/images";
      $dh = @opendir($td);
      while(false !== ($file = readdir($dh))) {
         if( !in_array($file, $ignore)) {
            unlink("$td/$file");
         }
      }
      closedir($dh);
      $dh = @opendir($theme_dir); 
      while(false !== ($file = readdir($dh))) {
         if( !in_array($file, $ignore)) {
            unlink("$theme_dir/$file");
         }
      }
      closedir($dh);
      rmdir($td);
      rmdir($theme_dir);
			return true;
			} else {
			return false;
			}
}
   
   function displayTheme($theme,$current=false)
   {
		$themes_dir=$this->themes_dir;   
		$notes="$themes_dir/$theme/notes.txt";
		$image="$themes_dir/$theme/images/ts_theme.png";
		echo "<div class=\"toolbar\">\n";
		$this->createThemesList();
		echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\">\n<div>\n";
		if($current) {
			echo "<input type=\"button\" name=\"upload\" value=\"Manage files\" title=\"Manage the files in this theme\" onclick=\"tsu.go('theme_files.php')\" />\n";
			} else {
			echo "<input type=\"hidden\" name=\"new_theme\" value=\"$theme\" />\n";
			echo "<input type=\"submit\" title=\"Use this theme for your site\" value=\"Apply\" />\n</form>";
			echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\" class=\"themeop\" onsubmit=\"return confirmdel('$theme');\">\n";
			echo "<input type=\"hidden\" name=\"delete_theme\" value=\"$theme\" />\n";
			echo "<input type=\"submit\" title=\"Delete this theme\" value=\"Delete\" />\n</form>\n";
			echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"post\" class=\"themeop\">\n";
		}
		echo "<input type=\"hidden\" name=\"copy_theme\" value=\"$theme\" />\n";
		echo "<input type=\"submit\" title=\"Make a new theme, based upon this one\" value=\"Copy as..\" />\n";
		echo "<input type=\"text\" title=\"Enter the name of your new theme\" size=\"12\" maxlength=\"24\" name=\"theme_name\" value=\"new theme name\" onclick=\"tsu.clearField(this);\" onblur=\"tsu.restoreField(this);\" />";
		echo "</div>\n</form>\n";			
		echo "</div>\n";
		echo "<fieldset class=\"themenotes\"><legend>The $theme theme</legend>";
		if(file_exists($image)) {
			echo "<img src=\"$image\" alt=\"$theme theme\" title=\"$theme theme\" />\n";
			} else {
			echo "<img src=\"./icons/ts_theme_dummy.png\" alt=\"$theme theme\" title=\"$theme theme\" />\n";
		}
		if(file_exists($notes)) {
			echo "<p>".nl2br(file_get_contents($notes))."</p>\n";
			} else {
			echo "<p>No notes are available for this theme.</p>\n";
		}
		if($current) {
			echo "<p><b>This is the current theme.</b></p>";
		}
		echo "</fieldset>";
	}
   
   function displayCurrentTheme()
   {
		$this->displayTheme(CURRENT_THEME,true);
    }
	
	function createThemesList()
		{
		$thms=$this->readThemes();
		echo "<form id=\"option_selector\" method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">\n<div>\n";
		echo "<select title=\"Choose a theme\" name=\"theme_choice\" onchange=\"theme_show();\">\n";
		echo "<option value=\"\" selected=\"selected\">Themes ...</option>\n";
		echo "<optgroup label=\"Current theme\">\n";
		echo '<option value="'.CURRENT_THEME.'" >'.CURRENT_THEME.'</option>'."\n";
		echo "</optgroup>\n";
		echo "<optgroup label=\"Alternative themes\">\n";
			foreach($thms as $thm) {
				if($thm <> CURRENT_THEME) {
				echo "<option value=\"$thm\" >$thm</option>\n";
				}
			} 
		echo"</optgroup>\n</select>\n</div>\n</form>\n";
		}
		
}
?>