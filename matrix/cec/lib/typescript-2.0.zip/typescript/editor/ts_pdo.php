<?php
// 2009.10.22
class TS_PDO {

	// table names
	private $tbl_sections;
	private $tbl_pages;
	private $tbl_config;
	private $tbl_login;
	// database handle  - type
	private $dbh;
	private $dbt;
	// error reporting
	private $errorDetail = false;
	
	private function reportError($e, $sql) {
	
		echo '<h3>Typescript Database error.</h3>';
		echo '<b>Message</b>: ' , $e->getMessage() , '<br />';
		if($this->errorDetail) {
			echo "<b>SQL Query</b>:  $sql <br />";
			echo '<b>In File</b>:  ' , $e->getFile() , '<br />';
			echo '<b>At Line</b>:  ' , $e->getLine() , '<br />';
			echo '<b>Trace</b>:<br />' , nl2br($e->getTraceAsString()) , '<br />';
		}
		exit;
	}
	
	public function __construct() {
		if(func_num_args() == 1) {
			// SQLite
			$this->sqliteConnect(func_get_arg(0));
		} else {
			// MySQL
			$args=func_get_args();
			$this->mysqlConnect($args);
		}
		$this->dbt = $this->dbh->getAttribute(PDO::ATTR_DRIVER_NAME);
	}
	
	private function sqliteConnect($sqlitedb) {
		$db_path=dirname(dirname(__FILE__))."/nucleus/$sqlitedb";
		$dsn="sqlite:$db_path";
		try {		
		$this->dbh=new PDO($dsn);
		$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
		$this->tbl_sections='sections';
		$this->tbl_pages='pages';
		$this->tbl_config='config';
		$this->tbl_login='login';
		} 
		catch (PDOException $e) {
			$this->reportError($e, 'Unable to connect to the database');
		}
	}
	
	private function mysqlConnect($args) {
		try {
		$this->dbh=new PDO($args[0],$args[1],$args[2]);
		$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
		$this->tbl_sections=$args[3].'sections';
		$this->tbl_pages=$args[3].'pages';
		$this->tbl_config=$args[3].'config';
		$this->tbl_login=$args[3].'login';
		} 
		catch (PDOException $e) {
			$this->reportError($e, 'Connection failed to MySQL database');
		}
	}
	
	// execute a query
	private function doQuery($sql) {
		try {
		return $this->dbh->query($sql);
		} 
		catch (PDOException $e) {
			$this->reportError($e, $sql);
		}
	}
	
	// check that a page exists
	public function pageExists($section,$page) {
			$sql="SELECT COUNT(*) FROM {$this->tbl_pages}, {$this->tbl_sections} 
				WHERE {$this->tbl_pages}.name LIKE '$page' 
				AND {$this->tbl_sections}.name LIKE '$section' AND {$this->tbl_sections}.sect_id={$this->tbl_pages}.sect_id";
		$result=$this->doQuery($sql);
		return($result->fetchColumn() > 0)?true:false;
	}
	
	// find the first page in the first section or a named section (the 'index' page)
	public function getIndexPage($section='') {
		if(!$section) {
			$sql="SELECT name FROM {$this->tbl_sections} WHERE {$this->tbl_sections}.posn=0 LIMIT 1";
			$res=$this->doQuery($sql);
			$result=($res->fetch(PDO::FETCH_OBJ));
			$section=$result->name;
		}
		$sql=sprintf("SELECT {$this->tbl_pages}.name AS name FROM {$this->tbl_pages}, {$this->tbl_sections} 
			WHERE {$this->tbl_pages}.sect_id={$this->tbl_sections}.sect_id 
			AND {$this->tbl_sections}.name LIKE '%s' AND {$this->tbl_pages}.posn=0", $section);
		$res=$this->doQuery($sql);
		$result=($res->fetch(PDO::FETCH_OBJ));
		$page=$result->name;
		return array('section'=>$section, 'page'=>$page);
	}
	
	// return the configuration table as an array
	public function getConfig() {
		$sql = "SELECT * FROM {$this->tbl_config}";
		$result=$this->doQuery($sql);
		return $result->fetch(PDO::FETCH_ASSOC);
	}
	
	// update the configuration table (page titles only)
	public function updatePageTitles($title,$header,$footer) {
		$sql="UPDATE {$this->tbl_config} SET title = :title, header = :header, footer = :footer";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':title', $title);
		$stmt->bindParam(':header', $header);		
		$stmt->bindParam(':footer', $footer);
		$stmt->execute();		
	}
	
	// update the configuration table (theme only)
	public function updateTheme($theme) {
		$sql="UPDATE {$this->tbl_config} SET theme = :theme";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':theme', $theme);		
		$stmt->execute();
		return true;
	}
	
	// return the site map as an array
	public function getStructure() {
		$smap=array();
		$sql="SELECT {$this->tbl_sections}.name AS section, {$this->tbl_pages}.name AS page 
			FROM {$this->tbl_sections}, {$this->tbl_pages}
			WHERE {$this->tbl_pages}.sect_id={$this->tbl_sections}.sect_id 
			ORDER BY {$this->tbl_sections}.posn, {$this->tbl_pages}.posn";
		$result=$this->doQuery($sql);
		while($row=$result->fetch(PDO::FETCH_ASSOC)) {
			$smap[$row['section']][]=$row['page'];
		}
		return $smap;
	}
	
	// fetch the page contents
	public function getContent($section,$page) {
		if($section=='ts_preview') {
			$sql="SELECT content FROM {$this->tbl_pages} WHERE sect_id = 0 AND name = '_temp'";
		} else {
			$sect_id=$this->fetchSectionID($section);
			$sql="SELECT content FROM {$this->tbl_pages} WHERE {$this->tbl_pages}.name LIKE '$page' AND sect_id = $sect_id";
		}
		$result=$this->doQuery($sql);
		$res=$result->fetch(PDO::FETCH_ASSOC);
		return $res['content'];
	}
	
	// rename a section (section names are unique)
	public function renameSection($old,$new) {
		$sql="UPDATE {$this->tbl_sections} SET name = :new WHERE name LIKE :old";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':new', $new);
		$stmt->bindParam(':old', $old);
		$stmt->execute();
		return true;
	}
	
	// make a new section
	public function newSection($name) {
		$sql="INSERT INTO {$this->tbl_sections} (name, posn) VALUES (:name, 0)";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':name', $name);
		$stmt->execute();
		return true;
	}
	
	// delete a section and all of its pages
	public function dropSection($name) {
		try {
		$sect_id=$this->fetchSectionID($name);
		$sql=sprintf("DELETE FROM {$this->tbl_pages} WHERE sect_id = %s", $sect_id);
		$this->doQuery($sql);
		$sql=sprintf("DELETE FROM {$this->tbl_sections} WHERE sect_id = %s", $sect_id);
		$this->doQuery($sql);
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}		
	}
	
	// rename a page
	public function renamePage($section,$old,$new) {
		try {
		$sect_id=$this->fetchSectionID($section);
		$sql="UPDATE {$this->tbl_pages} SET name = :new 
			WHERE name LIKE :old 
			AND sect_id = :sect_id ";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':new', $new);
		$stmt->bindParam(':old', $old);
		$stmt->bindParam(':sect_id', $sect_id);
		$stmt->execute();
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}
	}
	
	// make a new page
	public function newPage($section,$name) {
		try {
		$sect_id=$this->fetchSectionID($section);
		$sql="INSERT INTO {$this->tbl_pages} (sect_id, name, content, posn) VALUES(:sect_id, :name, ' ', 0)";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':sect_id', $sect_id, PDO::PARAM_INT);
		$stmt->bindParam(':name', $name);
		$stmt->execute();
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}
	}
	
	// delete a page
	public function deletePage($section,$name) {
		try {
		$sect_id=$this->fetchSectionID($section);
		$sql="DELETE FROM {$this->tbl_pages} WHERE name LIKE :name AND sect_id = :sect_id";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':sect_id', $sect_id, PDO::PARAM_INT);
		$stmt->bindParam(':name', $name);
		$stmt->execute();
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}		
	}
	
	// re-order a section
	public function repositionSection($sect_id,$posn) {
		$sql="UPDATE {$this->tbl_sections} SET posn = :posn WHERE sect_id = :sect_id";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':posn', $posn);
		$stmt->bindParam(':sect_id', $sect_id);
		$stmt->execute();
		return true;
	}
	
	// return a section's id
	public function fetchSectionID($section) {
		$sql = "SELECT sect_id FROM {$this->tbl_sections} WHERE {$this->tbl_sections}.name LIKE :section";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':section', $section);
		$stmt->execute();
		$result=$stmt->fetch(PDO::FETCH_OBJ);
		return $result->sect_id;	
	}
	
	// return a section's name
	public function fetchSectionFromID($sect_id) {
		try {
		$sql = "SELECT name FROM {$this->tbl_sections} WHERE sect_id = :sect_id";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':sect_id', $sect_id, PDO::PARAM_INT);
		$stmt->execute();
		$result=$stmt->fetch(PDO::FETCH_OBJ);
		if(is_object($result)) {
		return $result->name;
		} else {
		return '';
		}
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}			
	}
	
	// reorder a page
	public function repositionPage($sect_id,$name,$posn) {
		$sql="UPDATE {$this->tbl_pages} SET posn = :posn WHERE {$this->tbl_pages}.name LIKE :name AND sect_id = :sectid";
		$stmt=$this->dbh->prepare($sql);
		$stmt->bindParam(':posn', $posn);
		$stmt->bindParam(':sectid', $sect_id);
		$stmt->bindParam(':name', $name);
		$stmt->execute();
		return true;
	}
	
	// test user login
	public function validateUser($name, $login) {
		$sql="SELECT user, access FROM {$this->tbl_login} WHERE user LIKE :name AND password = :login";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':name', $name);
		$stmt->bindParam(':login', $login);
		$stmt->execute(); 
		$user=$stmt->fetch(PDO::FETCH_ASSOC);
		return (isset($user['user']))?$user['access']:false;
	}
	
	// return the users/access level/preferred editor as an array
	public function getUsers() {
		$sql = "SELECT user, access, editor FROM {$this->tbl_login}";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		while($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
			$users[$row['user']]=array('access'=>$row['access'],'editor'=>$row['editor']);
		}
		return $users;
	}
		
	// add a user
	public function addUser($user, $password, $access, $editor) {
		$sql="INSERT INTO {$this->tbl_login} (user, password, access, editor) VALUES(:user, :password, :access, :editor)";
		$password = hash(TS_HASHALGO,$password);
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':user', $user);
		$stmt->bindParam(':password', $password);
		$stmt->bindParam(':access', $access);
		$stmt->bindParam(':editor', $editor);
		$stmt->execute();
	}
	
	// delete a user
	public function dropUser($user) {
		$sql="DELETE FROM {$this->tbl_login} WHERE user = :user";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':user', $user);
		$stmt->execute();		
	}
	
	// save a page
	public function updatePage($section,$page,$content) {
		try {
		$sect_id=$this->fetchSectionID($section);
		$sql="UPDATE {$this->tbl_pages} SET content = :content WHERE name LIKE :page AND sect_id = :sect_id";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':content', $content);
		$stmt->bindParam(':page', $page);
		$stmt->bindParam(':sect_id', $sect_id);
		$stmt->execute();
		$this->vacuum();
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}			
	}
	
	// store a page preview
	public function preparePreview($content) {
		try {
		$sql="UPDATE {$this->tbl_pages} SET content = :content WHERE name = '_temp' AND sect_id = 0";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(':content', $content);
		$stmt->execute();
		return true;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}		
	}
	
	// return and tag page matches from an array of search terms
	public function find($terms) {
	$sql="SELECT content, name AS page, sect_id FROM {$this->tbl_pages} ";	
		$constraint="WHERE";
		foreach ($terms as $term)
		{
			$term=str_replace('"','',$term);
			$sql.=" $constraint content LIKE '%".$term."%'";
			$constraint="AND";
		}
		try {
			$result=$this->doQuery($sql);
			while($row=$result->fetch(PDO::FETCH_ASSOC)) {
			$section=$this->fetchSectionFromID($row['sect_id']);
			$content=str_replace('>', '> ', $row['content']);
			$content=strip_tags($content);
			$count=1;
				foreach($terms as $term){ 
					$term=str_replace('"','',$term);
					$content=preg_replace("/($term)/i", "<$count'>$1<", $content );
					$count=($count<6)?$count+1:1;
				}		
			$results[$section][$row['page']]=$content;
		}			
		return $results;
		} catch (PDOException $e)  {
			$this->reportError($e, $sql);
			return false;
		}
	}
	
	// clean up & compact the database (sqilte & sqlite2 only)
	private function vacuum() {
		if(stripos($this->dbt, 'sqlite')!==false) {
			$this->doQuery("VACUUM");
		}
	}
}
