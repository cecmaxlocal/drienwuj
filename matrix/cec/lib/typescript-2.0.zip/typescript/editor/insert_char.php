<?php 
// 2009.11.22
define('TS_EDIT',true);
require "reality_check.php";
$ts_utils->no_cache();
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Insert a character</title>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
<script type="text/javascript">
// <![CDATA[
function InsChar(char) {
 if(window.name != 'rawcharacters') {
 window.opener.tse.insertHTML(char); 
 } else {
 window.opener.rawtse.replaceSelection(char);
 }
 window.close();
}
// ]]>
</script>
</head>
<body id="inschar">
<table>
<?php
$charList = './../nucleus/corefiles/unicode.txt';
if(!file_exists($charList)) {
	die("<tr><td>I cannot find the file 'unicode.txt'</td></tr></table></body></html>");
}
$contents=file($charList);
$column=0;
$width=10;
foreach ($contents as $x) {
$char=explode(";",$x);
// ignore lines that don't begin with '&'
if (substr($char[0],0,1)=="&") {
  if ($column==0) print"<tr>\n";
  $column++;
  $title = (isset($char[1]))?trim($char[1]):'';
  print " <td title=\"".$title."\" onclick=\"InsChar('".htmlentities($char[0]).";');\">$char[0];</td>\n";
  if ($column==$width) {
  $column=0;
  print"</tr>\n";
}
}
}
// finish off table markup if we need empty cells
if ($column!=0) {
 do {
 print"<td>&nbsp;</td>\n";
 $column++;
 }
 while($column<$width);
 print"</tr>\n";
}
?> 
</table>
</body>
</html>
