<?php
// 2010.04.09
define('TS_EDIT',true);
require "reality_check.php";
$ts_utils->no_cache();
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<title>Insert a link</title>
  
<link rel="stylesheet" type="text/css" href="ts_styles.css" />

<script type="text/javascript">
// <![CDATA[
function insertLink(text) {
  if(window.name != 'rawlinks' ) {
    opener.tse.execCmd("createlink",text);
  } else {
    opener.rawtse.encloseSelection('<a href="'+text+'">','</a>');
  }
  window.close();
}
function returnSelected() {
  var obj=document.getElementById("textPulldown");
  var idx=obj.selectedIndex;
  var text=obj.options[idx].value;
  insertLink(text);
}
function returnExtlink() {
  var text=document.getElementById("extlink").value;
  insertLink(text);
}
// ]]>
</script>
</head>
<body id="dialog">
<form style="margin:8px 0 0 11px;" action="">
<span unselectable="on" style="font-size:small;-moz-user-select:none;-webkit-user-select:none;">Link to a page in this website</span><br />
<select name="textPulldown" id="textPulldown">
<?php
  //pages..
	$structure=$tsql->getStructure();

  foreach($structure as $section => $page) {
    foreach($page as $p) {
		$lp=strtolower($p);
		$s=strtolower($section);
		$url=(TS_TIDYURL)?str_replace(" ","-",$s)."/".str_replace(" ","-",$lp):"index.php?section=".str_replace(" ","+",$s)."&amp;page=".str_replace(" ","+",$lp);
		echo "<option value=\"$url\">$section/$p</option>\n";
    }
  }
  // resources..
  $d = opendir("./../resources") or die($e_nocon);
  while (false !== ($f = readdir($d))) {
    if (($f<>".") and ($f<>"..")) {
      echo "<option value=\"resources/$f\">resources/".$f."</option>\n";
    }
  }
  closedir($d);
?>
</select><input type="button" value=" Insert local link " onclick="returnSelected();" />
<hr />
<span unselectable="on" style="font-size:small;-moz-user-select:none;-webkit-user-select:none;">... or link to an external website</span><br />
<input type="text" size="40" name="extlink" id="extlink" value="http://www.example.com" />
<input type="button" value=" Insert external link" onclick="returnExtlink();" />
</form>
</body></html>