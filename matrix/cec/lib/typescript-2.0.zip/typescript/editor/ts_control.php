<?php
if(stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) {
	include 'index.php';
	exit;
}
require_once(dirname(__FILE__).'/reality_check.php');
if(TS_EMPTY){
	require_once(dirname(__FILE__).'/ts_empty.php');
	return;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title><?php echo TS_TITLE; ?></title>
<base href="<?php echo TS_BASE; ?>" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="Generator" content="Typescript 2.0" />
<?php
@include 'nucleus/corefiles/head.inc';
$template->link_stylesheet('themestyles.css');
if(TS_PAGESTYLES) {
	$template->link_stylesheet('pagestyles.css','all',false);
}
$template->link_stylesheet('printstyles.css','print');
@include TS_THEMEPATH.'theme.inc.php';
?>
</head>
<body class="<?php echo TS_BODYCLASS; ?>">
<?php @include TS_THEMEPATH.'template.php'; ?>
</body>
</html>