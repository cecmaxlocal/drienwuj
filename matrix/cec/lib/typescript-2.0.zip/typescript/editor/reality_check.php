<?php
	if(stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) {
		include 'index.php';
		exit;
	}
	
	DEFINE('TS_HASHALGO','sha256');

	require_once dirname(dirname(__FILE__)) . '/nucleus/ts_settings.php';
	require_once dirname(__FILE__) .  '/ts_pdo.php'; 
	
	if(TS_DBTYPE == 'mysql') {
	$tsql = new TS_PDO('mysql:host='.TS_DBHOST.';dbname='.TS_DBNAME,TS_DBUSER,TS_DBPASSWORD,TS_DBPREFIX);
	} else {
	$tsql = new TS_PDO(TS_DBSQLITE);
	}
	
	if(defined('TS_EDIT')) {
		require 'ts_utils.php';
		$access = $ts_utils->userLevel();
			if (!$access) {
				include 'index.php';
				exit;
		}

		$config = $tsql->getConfig();
		define('TS_THEME',$config['theme']);

		$usr = $_SESSION['user'];
		$usrs = $tsql->getUsers();
		$rawEdit = ($usrs[$usr]['editor'] == '2');
		define('TS_RAWEDIT',$rawEdit);

// Fix 'Magic Quotes'
	function fixMagicQuotes($array) {
		if (!is_array($array)) {
		return stripslashes($array);
	}	 else {
		return array_map('fixMagicQuotes', $array);
		}
	}

	if (get_magic_quotes_gpc()) {
		$_GET  = fixMagicQuotes($_GET);
		$_POST = fixMagicQuotes($_POST);
	}

} else {

	require_once dirname(__FILE__).'/ts_template.php'; 
}
