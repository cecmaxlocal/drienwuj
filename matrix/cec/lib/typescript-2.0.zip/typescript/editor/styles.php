<?php
// 2009.08.03
define('TS_EDIT',true); 
require 'reality_check.php';
$ts_utils->access($access>1);
error_reporting(E_ERROR);
$file="./../pagestyles.css";
$readOnly=!is_writable($file);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Page Styles Editor'); ?>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/typescript.js"></script>
<link rel="stylesheet" type="text/css" href="ts_styles.css" />
</head>
<body id="styles">
<div class="page">
<?php $ts_utils->buildMenu("styles",$access); ?>
<div class="content">
<div class="toolbar">
<?php if($readOnly) {
echo '<img src="icons/readonly.png" title="Read only file" alt="Read only file" />[<small>This file is not writable.</small>]';
} else {
echo '<img src="icons/ed_save.png" title="Save styles" alt="Save Styles" id="savebutton"  />';
} ?>
&nbsp; pagestyles.css<span id="saved_status"></span></div>
<textarea id="file_content" cols="90" rows="60" name="file_content" <?php if($readOnly) echo 'disabled="disabled"'; ?> >
<?php readfile($file); ?>
</textarea> 
</div>
<?php include("footer.inc.php"); ?>
</div>
</body>
</html>