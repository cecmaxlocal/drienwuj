<?php
// 2010.04.17
if((stripos($_SERVER['REQUEST_URI'],basename(__FILE__)) !== false) || !defined('TS_EDIT')) {
		include 'index.php';
		exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<?php $ts_utils->writeHTMLTitle('Editing: '.$pagepath); ?>
	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/typescript.js"></script>
	<link rel="stylesheet" type="text/css" href="ts_styles.css" />
</head>
<body id="raw-editor">
<div class="page">
<?php $ts_utils->buildMenu("none",$access); ?>
<div id="pagemarker"><?php echo "<a href=\"./../index.php?section=$section&amp;page=$page\">".$pagepath."</a>"; ?><span id="saved_status"></span></div>
<div class="content">
<div class="toolbar">
<img  id="btn_prev" src="icons/ed_preview.png" alt="Preview this page" title="Preview this page" width="25" height="25" /><img  id="savebutton" src="icons/ed_save.png" alt="Save" title="Save this page" width="25" height="25" /><span id="buttonblock">
<select name="imgformat" title="Image formatting" id="imgformat" style="display:none;">
<option class="opttop" value="" selected="selected">&mdash; Image Styles &mdash;</option>
<optgroup label="&nbsp; Image styles" title="Image styles">
<option value="">None</option>
<?php if(isset($styles['img'])){foreach($styles['img'] as $style) {if (strpos($style, 'cp-') !== 0) echo "<option value=\"$style\">img.$style</option>\n";}} ?>
</optgroup>
</select><select  name="format" title="Text formatting" id="format">
<option class="opttop" value="" selected="selected">&mdash; Text Styles &mdash;</option>
<optgroup label="&nbsp; Headings" title="Headings">
<option value="h1">heading 1</option>
<option value="h2">heading 2</option>
<option value="h3">heading 3</option>
<option value="h4">heading 4</option>
<option value="h5">heading 5</option>
<option value="h6">heading 6</option>
<?php if(isset($styles['h'])){foreach($styles['h'] as $style) {echo "<option value=\"$style\">$style</option>\n";}} ?>
</optgroup>
<optgroup label="&nbsp; Block elements" title="Block elements">
<option value="p">paragraph</option>
<?php if(isset($styles['p'])){foreach($styles['p'] as $style) {echo "<option value=\"p.$style\">p.$style</option>\n";}} ?>
<option value="blockquote">blockquote</option>
<option value="div">div</option>
<?php if(isset($styles['div'])){foreach($styles['div'] as $style) {echo "<option value=\"div.$style\">div.$style</option>\n";}} ?>
</optgroup>
<optgroup label="&nbsp; Inline elements" title="Inline elements">
<option value="u">underline</option>
<option value="strike">strike</option>
<?php if(isset($styles['span'])){foreach($styles['span'] as $style) {if (strpos($style, 'ts-') !== 0) echo "<option value=\"span.$style\">span.$style</option>\n";}} ?>
</optgroup>
</select><img id="btn_undo" src="icons/ed_undo_off.png" alt="Undo" title="Undo the last action - not available" width="25" height="25" /><img id="btn_bold" src="icons/ed_bold.png" alt="Bold" title="Bold text" width="25" height="25" /><img  id="btn_italic" src="icons/ed_italic.png" alt="Italic" title="Italic text" width="25" height="25" /><img  id="btn_tcol" src="icons/ed_fcolour.png" alt="Text colour" title="Text colour" width="25" height="25" /><img  id="btn_sub" src="icons/ed_sub.png" alt="Subscript text" title="Subscript text" width="25" height="25" /><img  id="btn_sup" src="icons/ed_super.png" alt="Superscript text" title="Superscript text" width="25" height="25" /><img  id="btn_hr" src="icons/ed_hrule.png" alt="Insert a horizontal rule" title="Insert a horizontal rule" width="25" height="25" /><img  id="btn_ul" src="icons/ed_ulist.png" alt="Make a bulleted list" title="Make a bulleted list" width="25" height="25" /><img  id="btn_ol" src="icons/ed_olist.png" alt="Make a numbered list" title="Make a numbered list" width="25" height="25" /><img  id="btn_link" src="icons/ed_link.png" alt="Insert a link" title="Insert a link" width="25" height="25" /><img  id="btn_char" src="icons/ed_char.png" alt="Insert a special character" title="Insert a special character" width="25" height="25" /><img  id="btn_inc" src="icons/ed_include.png" alt="Insert a script" title="Insert a script" width="25" height="25" /><img  id="btn_img" src="icons/ed_image.png" alt="Insert an image" title="Insert an image" width="25" height="25" /><img  id="btn_tools" src="icons/ed_tools.png" alt="Styles" title="Show styles" width="25" height="25" /><img  id="btn_avm" src="icons/ed_avm.png" alt="Audio/video" title="Insert audio or video" width="25" height="25" />
</span>
</div>
<textarea id="edit_frame" rows="80" cols="80">
<?php echo htmlspecialchars( $tsql->getContent($_GET['section'],$_GET['page']) ); ?>
</textarea>
<input type="hidden" id="section" name="section" value="<?php print $section; ?>" />
<input type="hidden" id="page" name="page" value="<?php print $page; ?>" />
<input type="hidden" id="theme" name="theme" value="<?php print TS_THEME; ?>" />
<input type="hidden" id="pagestyles" name="pagestyles" value="<?php echo (TS_PAGESTYLES)?'on':'off'; ?>" />
<input type="hidden" id="body_class" name="body_class" value="<?php print 'tp-'.str_replace(" ","-",strtolower($page)).' ts-'.str_replace(" ","-",strtolower($section)); ?>" />
</div>
<?php include("./footer.inc.php"); ?>
</div>
</body></html>