<?php
// 2009.11.11
define('TS_EDIT',true);
require 'reality_check.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<title>Typescript: Page preview</title>
<script type="text/javascript">
// <![CDATA[
function fillBuffer() {
	var buffer=document.getElementById("buffer");
	var body_class=document.getElementById("body_class");
	var content=opener.tse.doc.body;
		if(opener.tse.viewSource) {
			try {
			var html = content.ownerDocument.createRange();
			html.selectNodeContents(content);
			buffer.value=html.toString();
			} catch(e) { // IE
			buffer.value=content.innerText;
			}
		} else {
			buffer.value=content.innerHTML;
		}
	buffer.value=opener.tse.tidyHTML(buffer.value);
	body_class.value=opener.document.getElementById("body_class").value;
	document.getElementById("form").submit();
}
// ]]>
</script>
</head>
<body onload="fillBuffer();">
<form id="form" action="showpreview.php" method="post">
<textarea id="buffer" name="buffer" style="visibility:hidden;"></textarea>
<input type="hidden" id="body_class" name="body_class" value="" />
</form>
<hr /><h2 style="color:gray;">Typescript:<br />Constructing the preview...</h2><hr />
</body>
</html>