<?php
// 2009.11.22
define('TS_EDIT',true);
require "reality_check.php"; 
$styles=$ts_utils->readStyles(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="shortcut icon" href="icons/ts_icon.ico"/>
<link rel="icon" type="image/png" href="icons/ts_icon.png" />
<link rel="stylesheet" type="text/css" href="<?php echo "../themes/".TS_THEME."/themestyles.css"; ?>" />
<link rel="stylesheet" type="text/css" href="../pagestyles.css" />
<title>Styles viewer</title>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/effects.js"></script>
<script type="text/javascript">
// <![CDATA[
var sp = {
	init: function() {
		sp.scrollTo(window.name);
	},
	scrollTo: function(id) {
		if (document.getElementById(id)) {
			new Effect.ScrollTo(id);
		}
	}
}
Event.observe(window,'load',sp.init);
// ]]>
</script>
<style type="text/css">
h1.ts_styles_pane {
	font:italic small-caps 24px georgia, "palatino linotype", "times new roman", serif;
	color:gray;
	background:white;
	border-width:0;
	border-bottom:1px dotted gray;
	padding:10px 0 0 0;
	margin:0;
}
h1.ts_styles_pane span {
	position:absolute;
	right:35px;
	cursor:pointer;
}
h2.ts_styles_pane {
	font:normal 14px georgia, "palatino linotype", "times new roman", serif;
	color:white;
	background:gray;
	border-width:0;
	padding:2px;
	margin:10px 0 0 0;
	clear:both;
}
div.ts_styles_pane {
	border-width:0;
	padding:0;
	margin:10px 0 0 0;
	width:100%;
	clear:both;
}
</style>
</head>
<body id="content" style="width:800px;padding:10px;overflow:scroll">
<h1 class="ts_styles_pane" id="sp_headings">Headings<span><img src="icons/down.gif" alt="down" title="down to Block styles" onclick="sp.scrollTo('sp_paras');" /></span></h1>
<?php
if(!isset($styles['h'])) $styles['h'] = array(); 
array_unshift($styles['h'],'h1','h2','h3','h4','h5','h6');
foreach($styles['h'] as $heading) {
	$part = explode(".",$heading);
	$tag = @trim($part[0]);
	$att = @trim($part[1]);
	$class = ($att)?" class=\"$att\"":"";
	$text = ($class)?" $tag.$att":" $tag"; 
	echo "<h2 class=\"ts_styles_pane\">$tag.$att ...</h2><$tag$class>Typescript Content Management</$tag>\n";
}
?>
<h1 class="ts_styles_pane" id="sp_paras">Block styles<span><img src="icons/down.gif" alt="down" title="down to Inline styles" onclick="sp.scrollTo('sp_inline');" /><img src="icons/up.gif" alt="up" title="up to Heading styles" onclick="sp.scrollTo('sp_headings');" /></span></h1>
<?php
$gobbledegook="The only reason for time is so that everything doesn't happen at once. The only source of knowledge is experience. The pursuit of truth and beauty is a sphere of activity in which we are permitted to remain children all our lives.Gravitation is not responsible for people falling in love. The true sign of intelligence is not knowledge but imagination. Things should be made as simple as possible, but not any simpler. I have come to believe that the whole world is an enigma, a harmless enigma that is made terrible by our own mad attempt to interpret it as though it had an underlying truth. Strive not to be a success, but rather to be of value. Technological progress is like an axe in the hands of a pathological criminal. The difference between stupidity and genius is that genius has its limits. The distinction between the past, present and future is only a stubbornly persistent illusion. The most incomprehensible thing about the world is that it is comprehensible. Peace cannot be kept by force; it can only be achieved by understanding. Insanity: doing the same thing over and over again and expecting different results. 
";
echo "<h2 class=\"ts_styles_pane\">paragraph ...</h2><p>$gobbledegook</p>\n";
if(isset($styles['p'])) {
	foreach($styles['p'] as $style) { 
		echo '<h2 class="ts_styles_pane">p.'.$style." ...</h2><p class=\"$style\">$gobbledegook</p>\n";
	}
}
echo "<h2 class=\"ts_styles_pane\">blockquote ...</h2><blockquote>$gobbledegook</blockquote>\n";
echo "<h2 class=\"ts_styles_pane\">div ...</h2><p class=\"ts_styles_pane\"><div>$gobbledegook</div></p>\n";
if(isset($styles['div'])) {
	foreach($styles['div'] as $style) { 
		if (strpos($style, 'cp-') === false) {
		echo '<h2 class="ts_styles_pane">div.'.$style." ...</h2><p class=\"ts_styles_pane\"><div class=\"$style\">$gobbledegook</div></p>\n";
		}
	}
}
?>
<h1 class="ts_styles_pane" id="sp_inline">Inline styles<span><img src="icons/down.gif" alt="down" title="down to Image styles" onclick="sp.scrollTo('sp_images');" /><img src="icons/up.gif" alt="up" title="up to Paragraph styles" onclick="sp.scrollTo('sp_paras');" /></span></h1>
<h2 class="ts_styles_pane">underline ...</h2>
<div class="ts_styles_pane">Fashions fade, <span style="text-decoration: underline;">styles are eternal</span>. ...</div>
<h2 class="ts_styles_pane">strikethrough ...</h2>
<div class="ts_styles_pane">Fashions fade, <span style="text-decoration: line-through;">styles are eternal</span>. ...</div>
<?php
if(isset($styles['span'])) {
	foreach($styles['span'] as $style) {
		echo "<h2 class=\"ts_styles_pane\">span.$style ...</h2>";
		echo "<div class=\"ts_styles_pane\">Fashions fade, <span class=\"$style\">style is eternal</span>. ...</div>\n";
	}
}
?>
<h1 class="ts_styles_pane" id="sp_images">Image styles<span><img src="icons/down.gif" alt="down" title="down to Table styles" onclick="sp.scrollTo('sp_tables');" /><img src="icons/up.gif" alt="up" title="up to Inline styles" onclick="sp.scrollTo('sp_inline');" /></span></h1>
<?php
echo "<h2 class=\"ts_styles_pane\">default ...</h2><div class=\"ts_styles_pane\"><img src=\"sample_img.jpg\" alt=\"sample image\" title=\"sample image\" />$gobbledegook</div>";
if (isset($styles['img'])) {
	foreach($styles['img'] as $style) {
		if (strpos($style, 'cp-') === 0) {
		echo "<h2 class=\"ts_styles_pane\">img.$style ...</h2><div class=\"ts_styles_pane\"><div class=\"$style\"><img src=\"sample_img.jpg\" alt=\"sample image\" title=\"sample image\" /><p>Caption for image</p></div>$gobbledegook</div>";
		} else {
		echo "<h2 class=\"ts_styles_pane\">img.$style ...</h2><div class=\"ts_styles_pane\"><img class=\"$style\" src=\"sample_img.jpg\" alt=\"sample image\" title=\"sample image\" />$gobbledegook</div>";
		}
	}
}
?>
<h1 class="ts_styles_pane" id="sp_tables">Table styles<span><img src="icons/up.gif" alt="up" title="up to Image styles" onclick="sp.scrollTo('sp_images');" /></span></h1>
<?php
$table='
<caption>- Twinkle, twinkle little stars -</caption>
<thead>
<tr><th> </th><th>constellation</th><th>colour</th><th>magnitude</th><th>distance</th></tr>
</thead> 
<tfoot>
<tr><td colspan="5">&copy; Typescript Astronomical Society MMIX</td></tr>
</tfoot>
<tbody>
<tr><th>Betelgeuse</th><td>Orion</td><td>red</td><td>0.00</td><td>425</td></tr>
<tr><th>Arcturus</th><td>Bootes</td><td>red-orange</td><td>-0.04</td><td>36</td></tr>
<tr><th>Cappella</th><td>Auriga</td><td>orange</td><td>0.08</td><td>46</td></tr>
<tr><th>Rigel</th><td>Orion</td><td>blue-white</td><td>0.10</td><td>1050</td></tr>
</tbody>
</table>';
echo "<h2 class=\"ts_styles_pane\">default ...</h2><div class=\"ts_styles_pane\"><table>$table</div>\n";
if(isset($styles['table'])) {
	foreach($styles['table'] as $style) { 
		echo '<h2 class="ts_styles_pane">table.'.$style." ...</h2><div class=\"ts_styles_pane\"><table class=\"$style\">$table</div>\n";
	}
}
?>
</body>
</html>