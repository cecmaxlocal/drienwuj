<?php require "editor/ts_control.php" ?>
