<? //template for the 'order' theme ?>

<div id="pagecontainer">

<div id="header">
<?php $template->header(); ?>
</div>

<div id="menucontainer">
<?php $template->menu(2); ?>
</div>

<?php $template->content(); ?>

<div id="footer">
<?php $template->footer();
$template->editLink();
?>
</div>
 
</div>
