<!--[if lt IE 7]>
<link rel="stylesheet" href="<? echo TS_THEMEPATH; ?>ie6.css" type="text/css" />
<![endif]-->
