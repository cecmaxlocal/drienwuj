<div id="content">
<div class="wrap">
<?php $template->header(); ?>
<?php $template->content(); ?>
</div>
</div>

<div id="supplementary">
<div class="wrap">
<h4>Navigate</h4>
<?php $template->menu(3);?>
<?php $template->footer(); ?>
<?php $template->editLink(); ?>
</div>
</div>