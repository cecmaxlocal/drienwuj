<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo TS_THEMEPATH ?>ieold.css" type="text/css" media="all" />
<![endif]-->
