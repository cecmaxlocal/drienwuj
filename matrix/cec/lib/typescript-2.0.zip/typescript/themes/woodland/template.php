<div id="introductionouter">
<div id="introduction">
<?php $template->header(); ?>
<?php $template->menu(0); ?>
</div>
</div>
<div id="contentouter">
<?php $template->content(); ?>
<div id="secondarynav">
<?php $template->menu(4); ?>
<?php $template->editLink(); ?>
</div>
</div>
<div id="copyright">
<?php $template->footer(); ?>
</div>