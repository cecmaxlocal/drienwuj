<div id="navigation">
<?php
$template->menu(2);
?>
</div>
<div class="columns">
<div id="introduction">
<?php $template->header(); ?>
<hr />
<?php $template->footer(); ?>
</div>
<div id="contentouter">
<?php $template->content(); ?>
</div>
</div>
<?php $template->editLink(); ?>