<!--[if lt IE 8]>
<link rel="stylesheet" href="<?php echo TS_THEMEPATH ?>ieold.css" type="text/css" media="all" />
<![endif]-->
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php echo TS_THEMEPATH ?>iehover.js"></script>
<![endif]-->


