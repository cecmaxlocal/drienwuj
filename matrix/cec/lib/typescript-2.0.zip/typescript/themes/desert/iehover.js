/* Enables hovering on the "li" elements in the main menu for IE < 7 */
	
window.onload=function() {
	var menu_items=document.getElementById("navigation").getElementsByTagName("li");
	var num_items=menu_items.length;
	for(var n=0;n<num_items;n++) {
		menu_items[n].onmouseover=function() {this.className+=" iehover";}
		menu_items[n].onmouseout=function() {this.className=this.className.replace(" iehover", "");}
	}	
}