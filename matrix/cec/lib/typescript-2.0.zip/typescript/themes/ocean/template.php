<div class="columns">
<div id="introduction">
<?php
$template->header();
$template->menu(3); 
$template->editLink();
?>
</div>
<div id="contentouter">
<?php $template->content(); 
$template->footer();
?>
</div>
</div>