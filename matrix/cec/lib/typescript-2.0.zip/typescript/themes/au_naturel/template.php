<?php //template for the 'au_naturel' theme ?>

<div id="header">
<?php $template->header(); ?>
</div>

<div id="topmenu">
<?php $template->menu(0); ?>
</div>

<div id="submenu">
<?php $template->menu(4); ?>
</div>

<?php $template->content(); ?>

<div id="footer">
<?php $template->footer();
$template->editLink();
?>
</div> 