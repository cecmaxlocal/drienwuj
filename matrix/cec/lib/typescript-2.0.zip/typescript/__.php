<?php
// 2009.12.13
if(!isset($_GET['section']) || !isset($_GET['page'])) {
	exit;
}
define('TS_EDIT',false);
require './editor/reality_check.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<style type="text/css">
html {
	margin: 0;
	overflow:auto;
	border: none;
}
/* body {margin: 0;} */
ins.ts_include {
	border:1px dashed orange;
	white-space:nowrap;
	background:#fff;
	text-decoration:none;
	padding:3px 6px;
	color:#c60;
	font-size:11px;
	opacity:0.7;
}
ins.ts_include:before {
	vertical-align:middle;
	content: url(editor/icons/included.png); 
}
#ts-content {margin:1%;}
</style>
<title></title>
</head>
<body id="ts-content" contenteditable="true">
<?php echo $tsql->getContent($_GET['section'],$_GET['page']); ?>
</body>
</html>