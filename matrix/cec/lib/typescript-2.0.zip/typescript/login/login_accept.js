// 2009.10.27
function displayMsg(msg) {
	var oLogin=document.getElementById("login");
	msg = '<div class="page"><div class="head_nav"></div><div class="content report"><p>User Authentification</p>' + msg;
	msg += '</div></div></div>';
	oLogin.innerHTML=msg;
}
window.onload=function() {
// Prohibitions...
// adequate DOM support
	if (document.getElementById && document.createElement) {
	// cookies needed
		if (navigator.cookieEnabled) {
		// designMode preferred
			if (!document.designMode) alert ('WARNING:\nThis particular browser does not support the editing of web pages in WYSIWYG mode.');
			document.getElementById("form").style.display="block";
			document.getElementById('username').focus();
		} else {
			displayMsg('<strong>Note</strong>: You must have cookies enabled to log in');
		}
	} else {
		alert ('Your browser has insufficient support for this application.\nTry an alternative or more recent web browser');
	}
}