<?php
// 2009.08.03
if(!isset($_POST['username']) || !isset($_POST['password'])) {
	$host  = $_SERVER['HTTP_HOST'];
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	header("Location: http://$host$uri/");
	exit;
}
require_once( './editor/reality_check.php');
require './editor/ts_utils.php';
$axs=array('','Revisional','Editorial','Administrative');
$php_self=$_SERVER['PHP_SELF'];
$username='';
$password='';
$username=strtolower($_POST['username']);
$password=hash(TS_HASHALGO,$_POST['password']);
if ($access = $ts_utils->loginUser($username, $password))
{
	$message = "<div class=\"warning\"><p><b>Welcome ".$_POST['username']."</b></p><p><img src=\"editor/icons/allowed.png\"  alt=\"access allowed\" /> ".$axs[$access]." access granted.</p><form action=\"index.php\" method=\"post\"><input type=\"submit\" class=\"submit\" style=\"margin-left:12px;\" value=\"Continue\" /></form></div> \n";
}
else
{
	$message = '<div class="warning"><b>Access denied</b><p><img src="editor/icons/refused.png" alt="access denied" /> Invalid username or password</p>Please remember, your password is case sensitive.</div>';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Ray Middleton" />
<link rel="Stylesheet" href="editor/ts_styles.css" type="text/css" media="screen" />
<!--[if IE 6]>
 <link rel="stylesheet" type="text/css" href="editor/ie6_styles.css" />
 <script defer type="text/javascript" src="editor/icons/ie6pngfix.js"></script>
 <style type="text/css">
 .head_nav h1 {filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='./editor/ts_logo.png')}
 </style>
<![endif]-->
<title>Typescript 2.0 &nbsp; &middot;&middot;&middot; &nbsp; Log in &nbsp; &middot;&middot;&middot; &nbsp;</title>
<script type="text/javascript">
// <![CDATA[
window.onload=function() {
if(document.forms.length>0) {
 document.forms[0].elements[0].focus();
 }
}
// ]]>
</script>
</head>
<body>
<div class="page">
<div class="head_nav"></div>
<div class="content">
<?php
print $message;
?>
</div>
</div>
</body>
</html>