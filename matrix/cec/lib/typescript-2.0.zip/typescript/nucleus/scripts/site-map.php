<?php
if(!isset($template)) return;
$template->menu();
?>