<?php 
if(!isset($template)) return;

// email contact form (IMPORTANT: requires PHP >= 5.2.0)

// REPLACE mail@example.com WITH YOUR OWN EMAIL ADDRESS:
DEFINE('MAIL_TO','mail@example.com');

// MAKE 'active'=>false FOR ANY FIELD WHICH IS NOT NEEDED:

$mailFields = array(

  'name'=>array(
      'active'=>true,
      'caption'=>'Name',
      'type'=>'text',
      'description'=>'Enter your name'
     ),

  'email'=>array(
      'active'=>true,
      'caption'=>'Email',
      'type'=>'from',
      'description'=>'Enter your email address'
    ),
	
      'website'=>array(
      'active'=>false,
      'caption'=>'Your Website <em>www.example.com</em>',
      'type'=>'text',
      'description'=>'Your website URL if any'
    ),

  'subject'=>array(
      'active'=>false,
      'caption'=>'Subject',
      'type'=>'subject',
      'description'=>'Enter a heading for this message'
    ),

  'msg'=>array(
      'active'=>true, // this is a required field: active MUST be true
      'caption'=>'Message',
      'type'=>'message',
      'description'=>'Write your comment here'
    )
);


function makeFields($fields) {

 foreach($fields as $name=>$f) {
   if($f['active']) {
     echo "<div>\n<label for='$name'>{$f['caption']}</label>\n";
       if($f['type']=='message') {
         echo "<textarea id='$name' name='$name' rows='7' cols='50' title='{$f['description']}' ></textarea>\n";
       } else {
         echo "<input value='' size='60' maxlength='80' id='$name' name='$name' type='text' title='{$f['description']}' />\n";
       }
      echo "</div>\n";
   }
 }
}

if(isset($_POST['msg'])):

// filter fields for security
$clean = array('filter'=>FILTER_SANITIZE_STRING,'flags'=>FILTER_FLAG_NO_ENCODE_QUOTES);
$sanitise = array(
    'filter'=> FILTER_SANITIZE_STRING,
    'flags'=>FILTER_FLAG_STRIP_LOW|FILTER_FLAG_NO_ENCODE_QUOTES
);
$filter_list = array();
foreach($mailFields as $name=>$f) {
  if($f['type']=='from') {
    $filter_list[$name]=FILTER_SANITIZE_EMAIL;
  } elseif($f['type']=='subject') {
    $filter_list[$name]=$sanitise;
  } else {
    $filter_list[$name]=$clean;
  }
}

$mail_inputs = filter_input_array(INPUT_POST, $filter_list);

// don't allow 'http://' or an empty 'msg' field
$junk = stripos($mail_inputs['msg'], 'http://') || (strlen($mail_inputs['msg'])<=1);

// allow an empty but not invalid email field 
$validMail = ($mail_inputs['email']==='')||(filter_var($mail_inputs['email'], FILTER_VALIDATE_EMAIL));

echo '<div id="ts-email-response">';
if(($junk === false) && $validMail) {

  echo "Thank you for sending the following message:<br />\n<dl>";

  foreach($mailFields as $name=>$f) {
    if($f['active']) {
       echo "<dt>{$f['description']}:</dt>\n<dd>{$mail_inputs[$name]}</dd>\n";
    }
  }

  echo "</dl>\n";

  $message="
    Name: {$mail_inputs['name']}
    Website: {$mail_inputs['website']}
    Message: {$mail_inputs['msg']}";

  mail(MAIL_TO, $mail_inputs['subject'], $message, "From:{$mail_inputs['email']}");

} else {

  echo '<b>Sorry your message could not be sent</b><br />
    <a href="' . TS_PAGEREF . '"> PLEASE TRY AGAIN</a>:';
  echo ($validMail)?' Do not leave the message field empty. Use only plain text.':' The email address you supplied appears to be invalid.';
  echo '</a>';

}

echo '</div>';
return;
endif;
?>

<form action="" method="post" id="ts-contact-form">
<fieldset>
<legend>Contact us</legend>
<?php makeFields($mailFields); ?>
<input value="Submit" onclick="this.disabled=true;this.form.submit();" type="button"/>
</fieldset>
</form>


