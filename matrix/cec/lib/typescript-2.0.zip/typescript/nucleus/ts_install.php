﻿<?php
// 2009.10.04
function ins_report($msg) {

if(empty($msg)) {
	return;
}

echo <<<EOH
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Typescript install check</title>
</head>
<body>
<div style="width:80%;margin-left:auto;margin-right:auto;border:1px solid #f00;background:#eef;padding:20px">
<h2>Typescript Installation Check</h2>
EOH;

foreach($msg as $message) {
	echo '<p style="font-size:1.2em;text-indent:1em">' . $message . '</p>';
}

echo <<<EOT
</div>
</body>
</html>
EOT;

exit;
}

$ins_php_min_vers = '5.1.0';
$ins_msg = array(); 
$sqlite_datafile = '/nucleus/typescript.sqlite';
$sqlite_datapath = dirname(__FILE__) . '/typescript.sqlite';

// check PHP version
if(!function_exists( 'version_compare' )) {
	// version_compare was introduced in 4.0.7
	$ins_msg[] = 'Typescript will not work on this server because your PHP version is too old.';
	$ins_msg[] = 'You need PHP version ' . $ins_php_min_vers . '  or later.';
} elseif(version_compare(PHP_VERSION, $ins_php_min_vers) === -1) {
	$ins_msg[] = 'Typescript will not work on this server because your version of PHP (' . PHP_VERSION .') is too old.';
	$ins_msg[] = 'You need PHP version ' . $ins_php_min_vers . '  or later.';
}

ins_report($ins_msg);

// Check PDO class available
if( !class_exists('PDO') ) {
	$ins_msg[] = 'The PDO class in not available.';
	$ins_msg[] = 'Check your PHP configuration. See www.php.net/manual/en/pdo.installation.php';
}

// check database type
if( (TS_DBTYPE !='sqlite') && (TS_DBTYPE !='mysql') ) {
	$ins_msg[] = 'Invalid database type "' . TS_DBTYPE . '" in the file nucleus/ts_settings.php';
	$ins_msg[] = 'Please use either "sqlite" or "mysql" (lower case).';
} 

ins_report($ins_msg);

// check availability of PDO driver
if(!in_array(TS_DBTYPE, PDO::getAvailableDrivers())) {
	$ins_msg[] = 'A PDO driver for "' . TS_DBTYPE . '" is not available.';
	$ins_msg[] = 'Check your PHP configuration. See www.php.net/manual/en/pdo.installation.php';   
}


// check database connectivity through PDO
if(TS_DBTYPE == 'mysql') {
	try {
			$ins_dbh = new PDO('mysql:host='.TS_DBHOST.';dbname='.TS_DBNAME,TS_DBUSER,TS_DBPASSWORD);
		} catch (PDOException $e) {
			$ins_msg[] = 'Unable to connect to the MySQL database "' . TS_DBNAME .'".';
		}
} else {
	try {
			$ins_dsn = 'sqlite:' . $sqlite_datapath;
			$ins_dbh = new PDO($ins_dsn);
		} catch (PDOException $e) {
			$ins_msg[] = 'Unable to connect to an SQLite database.';
		}
		if(!is_writable($sqlite_datapath)) {
			$ins_msg[] = "The file '$sqlite_datafile' needs to be both readable and writable"; 
		}
	}

ins_report($ins_msg);

if(TS_DBTYPE !== 'mysql') {
    return;
}

// build the MySQL database if necessary
$ins_prefix = TS_DBPREFIX;
$ins_schema = <<<EOS
CREATE TABLE IF NOT EXISTS {$ins_prefix}config (
	theme CHAR(64) NOT NULL PRIMARY KEY, 
	title TEXT,
	header TEXT, 
	footer TEXT
);
CREATE TABLE IF NOT EXISTS {$ins_prefix}login (
	user CHAR(20) NOT NULL PRIMARY KEY,
	password CHAR(128) NOT NULL,
	access CHAR(1) NOT NULL,
	editor CHAR(1) NOT NULL
);
CREATE TABLE IF NOT EXISTS {$ins_prefix}pages (
	page_id MEDIUMINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
	sect_id SMALLINT UNSIGNED NOT NULL,
	name VARCHAR(20) NOT NULL,
	content LONGTEXT,
	posn SMALLINT NOT NULL
);
CREATE TABLE IF NOT EXISTS {$ins_prefix}sections (
	sect_id SMALLINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(20) NOT NULL,
	posn SMALLINT NOT NULL
)
EOS;
	try {
	$ins_dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$ins_dbh->query($ins_schema);
	} catch (PDOException $e) {
		$ins_msg[] = 'Unable to create the MySQL tables';
	}

ins_report($ins_msg);

// close then reopen the connection
$ins_dbh = null;
if(TS_DBTYPE == 'mysql') {
$ins_dbh = new PDO('mysql:host='.TS_DBHOST.';dbname='.TS_DBNAME,TS_DBUSER,TS_DBPASSWORD);
} else {
$ins_dbh = new PDO($ins_dsn);
}

	try {
	$ins_sth = $ins_dbh->query('SELECT * FROM ' . TS_DBPREFIX . 'config');
	$ins_rows = count($ins_sth->fetchAll());
	} catch (PDOException $e) {
		// do nothing
	}
	
	if($ins_rows > 0 ) {
		// the 'config' table already contains data - so return
		$ins_dbh = null;
		return;
	}

// insert default data
$ins_data = <<<EOD
INSERT INTO {$ins_prefix}config (theme, title, header, footer) VALUES(
	'desert',
	'Typescript',
	'<h1>Typescript</h1><p>Easy Content Management</p>',
	'<p>Built and maintained using <a href="http://www.typescript.org">Typescript</a>.</p>'
);
INSERT INTO {$ins_prefix}login (user , password , access, editor ) VALUES(
	'admin',
	'5f0d07d97851e7da604b8e60387246ee11b04ebdb0e3a55ef6123c3ab96e6312',
	3,
	1
);
INSERT INTO {$ins_prefix}sections (name, posn) VALUES('Introduction', 0);
INSERT INTO {$ins_prefix}pages (sect_id, name, content, posn) VALUES(
	1,
	'Welcome',
	'
<h1>Welcome to Typescript.</h1> 
<p>Great! If you’re reading this message you have installed Typescript successfully. If you’re not logged in already, simply navigate to the&nbsp;<a href="login/">login</a> page. Log in with the username <strong>admin</strong> and the password <strong>admax</strong>. Ensure that you create a new administrative user and delete the default one to make sure that your site is safe.</p>
<p>We hope that your site is a huge success. Thank you for choosing Typescript.</p>',
	0
);
EOD;
	try {
	$ins_dbh->query($ins_data);
	} catch (PDOException $e) {
		// do nothing
	}



