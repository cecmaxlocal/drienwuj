<?php

/* === LOCAL TIMEZONE ===
   If necessary set the following line to match your local time zone.
   See http://php.net/manual/en/timezones.php for a list of zones 
*/
date_default_timezone_set('UTC'); 

/* === MAX MENU CHARACTERS ===
   Sets the maximum number of characters for the text in Typescript's automatically generated menus.   
   Permitted values are between 16 and 128:  else defaults to 20
*/
define('TS_MENUCHARS',20);


/* === TIDY URLs  ===
   Set to 'true' if you want nice urls like "www.example.com/home/info"
   Set to 'false' for urls like "www.example.com/index.php?section=home&page=info"
*/
define('TS_TIDYURL',false); 


/* === USE PAGESTYLES ===
   Set to 'false' if you have no use for the file 'pagestyles.css'
*/
define('TS_PAGESTYLES',true);


/* === DATABASE TYPE ===
    Either 'sqlite' or 'mysql'
*/	
define('TS_DBTYPE', 'sqlite'); 

/* === SQLite DATABASE FILE ==
    The name of the SQLite database file. This can be ignored by MySQL users.
*/
define('TS_DBSQLITE', 'typescript.sqlite');


/* === MySQL DATABASE SETTINGS ===
    The following values are only required for MySQL and can be ignored by SQLite users.
*/	
define('TS_DBNAME', 'typescript'); // The name of the  database 
define('TS_DBUSER', 'root'); // Your MySQL username 
define('TS_DBPASSWORD', ''); // Your MySQL password 
define('TS_DBHOST', 'localhost'); // The host name of the database server (This can often be left as 'localhost')
define('TS_DBPREFIX', 'TS_'); // Add a prefix (e.g. "TS_") to each table name if you need to avoid clashes with existing tables 

/* === INSTALL / CHECK ===
    Enable the next line TEMPORARILY either to install on MySQL or to diagnose installation problems
*/
# include 'ts_install.php'; 
