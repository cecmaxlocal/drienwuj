
This is Typescript CMS version 2.0.0 (released July 21, 2010)
================================================================
Copyright (2005 - 2010) Ray Middleton and Ben Briggs

Contact
-------
If you have a question about Typescript, please visit http://www.typescript.org

Licence information
-------------------
Typescript CMS is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for details.

You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/

__________________________________________________________________________________

 Now you've read this page use it as a notepad! 
