-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 29, 2010 at 11:10 AM
-- Server version: 5.1.48
-- PHP Version: 5.2.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `typescript`
--

-- --------------------------------------------------------

--
-- Table structure for table `ts_config`
--

CREATE TABLE IF NOT EXISTS `ts_config` (
  `theme` char(64) NOT NULL,
  `title` text,
  `header` text,
  `footer` text,
  PRIMARY KEY (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ts_config`
--

INSERT INTO `ts_config` (`theme`, `title`, `header`, `footer`) VALUES
('desert', 'Typescript', '<h1>Typescript</h1><p>Easy Content Management</p>', '<p>Built and maintained using <a href="http://www.typescript.org">Typescript</a>.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `ts_login`
--

CREATE TABLE IF NOT EXISTS `ts_login` (
  `user` char(20) NOT NULL,
  `password` char(128) NOT NULL,
  `access` char(1) NOT NULL,
  `editor` char(1) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ts_login`
--

INSERT INTO `ts_login` (`user`, `password`, `access`, `editor`) VALUES
('admin', '5f0d07d97851e7da604b8e60387246ee11b04ebdb0e3a55ef6123c3ab96e6312', '3', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ts_pages`
--

CREATE TABLE IF NOT EXISTS `ts_pages` (
  `page_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sect_id` smallint(5) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `content` longtext,
  `posn` smallint(6) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ts_pages`
--

INSERT INTO `ts_pages` (`page_id`, `sect_id`, `name`, `content`, `posn`) VALUES
(1, 1, 'Welcome', '\r\n<h1>Welcome to Typescript.</h1> \r\n<p>Great! If youâ€™re reading this message you have installed Typescript successfully. If youâ€™re not logged in already, simply navigate to the&nbsp;<a href="login/">login</a>Â page. Log in with the usernameÂ <strong>admin</strong>Â and the passwordÂ <strong>admax</strong>. Ensure that you create a new administrative user and delete the default one to make sure that your site is safe.</p>\r\n<p>We hope that your site is a huge success. Thank you for choosing Typescript.</p>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ts_sections`
--

CREATE TABLE IF NOT EXISTS `ts_sections` (
  `sect_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `posn` smallint(6) NOT NULL,
  PRIMARY KEY (`sect_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ts_sections`
--

INSERT INTO `ts_sections` (`sect_id`, `name`, `posn`) VALUES
(1, 'Introduction', 0);
